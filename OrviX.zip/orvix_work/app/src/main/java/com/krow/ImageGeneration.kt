package com.krow

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.krow.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException

/** OpenRouter's dedicated image API client. Uses a separate OpenRouter key so any chat provider can call it. */
object ImageGeneration {
    const val BASE_URL = "https://openrouter.ai/api/v1"
    const val MODEL = "recraft/recraft-v4.1-flash-v2:free"
    private val json = Json { ignoreUnknownKeys = true }

    data class Result(val files: List<File>, val attachmentNames: List<String>)

    private fun extension(bytes: ByteArray): String = when {
        bytes.size >= 8 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "png"
        bytes.size >= 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte() -> "jpg"
        bytes.size >= 12 && String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF" && String(bytes, 8, 4, Charsets.US_ASCII) == "WEBP" -> "webp"
        else -> "png"
    }

    fun savedKey(core: Core): String? = core.secrets.get(Secrets.apiKeyName(BASE_URL))

    suspend fun generate(
        core: Core,
        project: Project,
        prompt: String,
        aspectRatio: String = "1:1",
        count: Int = 1,
        progress: (String) -> Unit = {},
    ): Result = withContext(Dispatchers.IO) {
        val key = savedKey(core)?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Add an OpenRouter API key in Image Generator settings first.")
        val cleanPrompt = prompt.trim().take(5000)
        require(cleanPrompt.isNotBlank()) { "Image prompt cannot be empty." }
        val ratios = setOf("1:1", "4:3", "3:4", "16:9", "9:16", "auto")
        require(aspectRatio in ratios) { "Unsupported aspect ratio." }
        val n = count.coerceIn(1, 6)
        progress("Sending prompt to Recraft…")
        val body = buildJsonObject {
            put("model", MODEL)
            put("prompt", cleanPrompt)
            put("aspect_ratio", aspectRatio)
            put("n", n)
        }.toString().toRequestBody(JSON_MT)
        val request = Request.Builder()
            .url("$BASE_URL/images")
            .header("Authorization", "Bearer $key")
            .header("Content-Type", "application/json")
            .header("HTTP-Referer", "https://openrouter.ai/")
            .header("X-Title", "OrviX Image Generator")
            .post(body)
            .build()
        val response = core.http.newCall(request).execute()
        val payload = response.use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val detail = runCatching { json.parseToJsonElement(raw).jsonObject.let { it["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content ?: it["message"]?.jsonPrimitive?.content } }.getOrNull()
                throw IOException("OpenRouter image API HTTP ${r.code}: ${(detail ?: raw).take(700)}")
            }
            runCatching { json.parseToJsonElement(raw).jsonObject }.getOrElse { throw IOException("Image API returned invalid JSON: ${raw.take(300)}") }
        }
        val data = payload["data"]?.jsonArray ?: throw IOException("Image API response did not contain a data array.")
        if (data.isEmpty()) throw IOException("Image API returned no images.")
        val outDir = File(core.projectDir(project), "images/generated").also { it.mkdirs() }
        val made = ArrayList<File>()
        val attachments = ArrayList<String>()
        try {
            data.take(n).forEachIndexed { index, item ->
                progress("Saving image ${index + 1} of ${minOf(data.size, n)}…")
                val obj = item.jsonObject
                val b64 = obj["b64_json"]?.jsonPrimitive?.contentOrNull
                val bytes = if (!b64.isNullOrBlank()) {
                    runCatching { Base64.decode(b64, Base64.DEFAULT) }.getOrElse { throw IOException("Image ${index + 1} contained invalid base64 data.") }
                } else {
                    val url = obj["url"]?.jsonPrimitive?.contentOrNull ?: throw IOException("Image ${index + 1} had neither b64_json nor url.")
                    val imageReq = Request.Builder().url(url).get().build()
                    core.http.newCall(imageReq).execute().use { img ->
                        if (!img.isSuccessful) throw IOException("Could not download generated image ${index + 1} (HTTP ${img.code}).")
                        img.body?.bytes() ?: throw IOException("Generated image ${index + 1} was empty.")
                    }
                }
                if (bytes.isEmpty() || bytes.size > 30 * 1024 * 1024) throw IOException("Generated image ${index + 1} is empty or exceeds the 30 MB safety limit.")
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Generated image ${index + 1} is not a valid image.")
                val ext = extension(bytes)
                val file = File(outDir, "orvix_${uid()}_${index + 1}.$ext")
                file.writeBytes(bytes)
                made += file
                val attachment = "generated_${uid()}.$ext"
                Attachments.file(attachment).writeBytes(bytes)
                attachments += attachment
            }
        } catch (e: Throwable) {
            made.forEach { runCatching { it.delete() } }
            attachments.forEach { Attachments.delete(it) }
            throw e
        }
        Result(made, attachments)
    }
}

/** Tool exposed to every connected chat model. The calling model writes the visual prompt. */
class GenerateImageTool : Tool {
    override val spec = ToolSpec(
        "generate_image",
        "Generate images from a detailed text prompt using OrviX Image Generator (OpenRouter Recraft V4.1 Flash V2 free). You are the prompt director: turn the user's request into a precise, production-quality visual prompt with subject, composition, camera/viewpoint, lighting, materials, palette, atmosphere, style, background and any exact text. Do not mention unsupported image inputs or reference images. The generated images are saved in the project and displayed in chat. Requires an OpenRouter API key saved in OrviX → Image Generator.",
        schema(listOf("prompt"),
            "prompt" to prop("string", "Detailed final image-generation prompt; be concrete and visually specific, up to 5000 characters"),
            "aspect_ratio" to prop("string", "1:1, 4:3, 3:4, 16:9, 9:16 or auto; default 1:1"),
            "count" to prop("integer", "Number of images, 1 to 6; default 1"),
        ),
    )
    override val kind = "image"
    override val mutating = true
    override fun title(a: JsonObject) = "Generate image"
    override fun cmd(a: JsonObject) = "${ImageGeneration.MODEL} · ${a.str("aspect_ratio") ?: "1:1"}"
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val prompt = a.str("prompt") ?: return ToolOut("Missing image prompt.", false)
        val result = ImageGeneration.generate(c.core, c.project, prompt, a.str("aspect_ratio") ?: "1:1", a.int("count") ?: 1, c.progress)
        val lines = result.files.mapIndexed { i, f -> "${i + 1}. ${relTo(c.dir, f)} · ${humanSize(f.length())}" }
        return ToolOut("Generated ${result.files.size} image(s) with ${ImageGeneration.MODEL}.\nSaved to project:\n${lines.joinToString("\n")}", images = result.attachmentNames)
    }
}

private data class GeneratedPreview(val file: File, val attachment: String)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImageGeneratorScreen(core: Core, project: Project, onBack: () -> Unit) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var prompt by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("1:1") }
    var count by remember { mutableIntStateOf(1) }
    var keyInput by remember { mutableStateOf("") }
    var keyRevision by remember { mutableIntStateOf(0) }
    var showKey by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val key = remember(keyRevision) { ImageGeneration.savedKey(core) }
    val generated = remember { mutableStateListOf<GeneratedPreview>() }
    var viewing by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(p.bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.Outlined.ArrowBack, "Back", onClick = onBack)
            T("Image Generator", 17, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Pill("Recraft V4.1", small = true, mono = true, selected = true)
        }
        HLine()
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(26.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(p.accentSoft), Alignment.Center) { Ic(Icons.Outlined.AutoAwesome, 22, p.accent) }
                    Column(Modifier.weight(1f)) {
                        T("Create something striking", 18, weight = FontWeight.SemiBold)
                        T("Text-to-image · Recraft V4.1 Flash V2", 12, p.muted)
                    }
                }
                T("Describe the image", 13, p.muted, FontWeight.Medium)
                Field(prompt, { prompt = it }, "A cinematic scene with…", singleLine = false)
                T("Aspect ratio", 13, p.muted, FontWeight.Medium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("1:1", "4:3", "3:4", "16:9", "9:16", "auto").forEach { r -> Pill(r, selected = ratio == r, small = true) { ratio = r } }
                }
                T("Images", 13, p.muted, FontWeight.Medium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) { (1..6).forEach { n -> Pill("$n", selected = count == n, small = true) { count = n } } }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        T("OpenRouter connection", 14, weight = FontWeight.Medium)
                        T(if (key != null) "API key saved securely on this device" else "Add your OpenRouter API key to generate images", 12, if (key != null) p.ok else p.muted)
                    }
                    Pill(if (showKey) "Hide" else "API key", small = true, onClick = { showKey = !showKey })
                }
                if (showKey) {
                    Field(keyInput, { keyInput = it }, if (key != null) "Paste a new key to replace saved key" else "sk-or-v1-…", password = true, mono = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Save key", filled = true) {
                            if (keyInput.trim().isNotEmpty()) {
                                core.secrets.put(Secrets.apiKeyName(ImageGeneration.BASE_URL), keyInput.trim())
                                keyInput = ""; keyRevision++; showKey = false; core.say("OpenRouter image key saved securely")
                            }
                        }
                        if (key != null) Pill("Remove key", color = p.bad) { core.secrets.remove(Secrets.apiKeyName(ImageGeneration.BASE_URL)); keyRevision++; core.say("Image key removed") }
                    }
                }
                if (error != null) T(error!!, 13, p.bad)
                if (working) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircularProgressIndicator(Modifier.size(18.dp), color = p.accent, strokeWidth = 2.dp)
                        T(status.ifBlank { "Generating…" }, 13, p.muted)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    T("Free model · provider availability may vary", 11, p.faint, modifier = Modifier.weight(1f))
                    Pill(if (working) "Generating…" else "Generate", filled = true, icon = Icons.Outlined.AutoAwesome, onClick = {
                        if (!working) {
                            error = null
                            scope.launch {
                                working = true; status = "Preparing prompt…"
                                try {
                                    val result = ImageGeneration.generate(core, project, prompt, ratio, count) { message -> core.scope.launch { status = message } }
                                    result.files.zip(result.attachmentNames).forEach { (f, a) -> generated.add(0, GeneratedPreview(f, a)) }
                                    status = "Done · ${result.files.size} image(s)"
                                    core.say("Generated ${result.files.size} image(s)")
                                } catch (e: Exception) {
                                    error = e.message ?: "Image generation failed."
                                } finally { working = false }
                            }
                        }
                    })
                }
            }
            if (generated.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("Your images", 17, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    T("${generated.size} generated", 12, p.faint)
                }
                generated.forEach { item ->
                    val bitmap by produceState<android.graphics.Bitmap?>(null, item.file.absolutePath) { value = withContext(Dispatchers.IO) { BitmapFactory.decodeFile(item.file.absolutePath) } }
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(20.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (bitmap != null) androidx.compose.foundation.Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 420.dp).clip(RoundedCornerShape(14.dp)).clickable { viewing = item.attachment }, contentScale = ContentScale.Fit)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            T(item.file.name, 12, p.muted, modifier = Modifier.weight(1f), maxLines = 1)
                            IconBtn(Icons.Outlined.Share, "Share image", 36) { shareGenerated(ctx, item.file) }
                        }
                    }
                }
            }
        }
    }
    viewing?.let { ImageViewer(it) { viewing = null } }
}

private fun shareGenerated(ctx: Context, file: File) {
    runCatching {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = when (file.extension.lowercase()) { "jpg", "jpeg" -> "image/jpeg"; "webp" -> "image/webp"; else -> "image/png" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Share image").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { android.widget.Toast.makeText(ctx, "Could not share image: ${it.message}", android.widget.Toast.LENGTH_LONG).show() }
}
