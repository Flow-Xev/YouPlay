package com.krow

/**
 * Token router: decides, once per request, which of your models answers, so everyday asks run on the quick cheap model and only
 * hard, long or code-heavy ones reach the strong model. Also enforces an optional daily token budget.
 *
 * The choice is made once per turn and kept for every tool step of that turn (switching models in the middle of a tool conversation
 * breaks provider-specific state such as Gemini thought signatures).
 */
object Router {
    class Pick(val model: String, val tier: String, val why: String) // tier: manual | fast | smart | stop

    private val hard = Regex(
        "\\b(debug|refactor|implement|architect\\w*|design|root cause|optimi[sz]e|migrate|migration|build|apk|compile|compiler|exception|stack ?trace|" +
            "analy[sz]e|compare|review|security|algorithm|prove|derive|step by step|why (does|is|isn't|doesn't)|fix|bug|crash|workflow|pipeline|deploy)\\b",
        RegexOption.IGNORE_CASE,
    )

    fun enabled(st: Settings) = st.routerOn && (st.routerFast.isNotBlank() || st.routerSmart.isNotBlank())

    fun fastModel(st: Settings) = st.routerFast.ifBlank { st.model }
    fun smartModel(st: Settings) = st.routerSmart.ifBlank { st.model }

    /** Cheap model for chat titles when the router is on. */
    fun titleModel(st: Settings): String = if (enabled(st)) fastModel(st) else st.model

    fun pick(st: Settings, text: String, attachments: Boolean, repoWork: Boolean, historySize: Int, spentToday: Int, lastModel: String?): Pick {
        if (!enabled(st)) return Pick(st.model, "manual", "")
        val fast = fastModel(st); val smart = smartModel(st)
        if (st.routerBudget > 0 && spentToday >= st.routerBudget) {
            return if (st.routerOver == "stop") Pick(fast, "stop", "daily budget used")
            else Pick(fast, "fast", "daily budget used")
        }
        if (fast == smart) return Pick(fast, "fast", "one model")
        var score = 0
        val why = ArrayList<String>()
        if (text.length > 500) { score += 2; why += "long ask" }
        if (text.contains("```") || Regex("\\bat [\\w.$]+\\(.*:\\d+\\)").containsMatchIn(text)) { score += 2; why += "code or trace" }
        if (hard.containsMatchIn(text)) { score += 2; why += "needs reasoning" }
        if (attachments) { score += 2; why += "attachments" }
        if (text.count { it == '\n' } > 8) { score += 1; why += "multi-line" }
        if (repoWork && Regex("\\b(push|commit|ship|release|pull request|workflow)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) { score += 1; why += "repo work" }
        if (historySize > 30) score += 1
        // "yes", "continue", "do it": stay on whatever model was already working on this thread
        if (score < 2 && text.length < 60 && lastModel == smart && historySize > 2) { score = 2; why += "follow-up" }
        return if (score >= 2) Pick(smart, "smart", why.joinToString(", ")) else Pick(fast, "fast", "simple ask")
    }

    /** Old tool output is the biggest silent input cost: keep the head and tail, drop the middle. */
    fun trimOld(m: Msg): Msg =
        if (m.role == "tool" && m.text.length > 1500) m.copy(text = m.text.take(900) + "\n…[older output trimmed to save tokens]…\n" + m.text.takeLast(400)) else m
}
