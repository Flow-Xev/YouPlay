package com.krow.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.krow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Home, in ClipSot's design language: lowercase wordmark header, a big two-tone headline that changes every visit (tap for another),
 * quick numbers that double as shortcuts, one light "featured" card, a horizontal row of recent chats, and soft action cards.
 */
@Composable
fun Home(
    core: Core, project: Project, onMenu: () -> Unit, onSettings: (String) -> Unit, onSearch: () -> Unit,
    onPrompt: (String) -> Unit, onAttach: (String) -> Unit, onShip: () -> Unit,
) {
    val p = LocalPal.current
    val s by core.state.collectAsState()
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    var seed by rememberSaveable { mutableIntStateOf((System.currentTimeMillis() / 1000L % 1000L).toInt()) }
    val repo = project.takeIf { it.kind == "repo" }
    val withMsgs = remember(s.chats) { s.chats.filter { c -> c.msgs.any { it.role == "user" } }.sortedByDescending { it.updated } }
    val hero = withMsgs.firstOrNull()
    val recent = withMsgs.drop(1).take(8)
    val (lead, tail) = remember(seed, repo?.repo, hour) { headline(hour, repo?.repo, withMsgs.size, seed) }
    var changes by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(repo?.id, s.chats.size, s.tokens) {
        changes = if (repo == null) null else withContext(Dispatchers.IO) {
            runCatching { val d = core.projectDir(repo); GitOps.status(d, GitOps.loadBase(d) ?: error("none")).size }.getOrNull()
        }
    }

    Column(Modifier.fillMaxSize().hapticScroll().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        // header
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            HomeRound(Icons.Outlined.Menu, "Menu", onMenu)
            Spacer(Modifier.width(12.dp))
            OrviXMark(34.dp)
            Spacer(Modifier.width(8.dp))
            Wordmark(28)
            Spacer(Modifier.weight(1f))
            HomeRound(Icons.Outlined.Search, "Search", onSearch)
            Spacer(Modifier.width(6.dp))
            HomeRound(Icons.Outlined.Tune, "Settings") { onSettings("home") }
        }
        // headline
        Crossfade(seed, label = "headline", modifier = Modifier.padding(top = 18.dp, bottom = 18.dp).clip(RoundedCornerShape(12.dp)).pressable(onClick = { seed += 1 })) { sd ->
            val (l, t) = if (sd == seed) lead to tail else headline(hour, repo?.repo, withMsgs.size, sd)
            androidx.compose.material3.Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = p.ink)) { append(l + "\n") }
                    withStyle(SpanStyle(color = if (sd % 3 == 0) p.accent else p.muted)) { append(t) }
                },
                fontSize = 36.sp, lineHeight = 38.sp, letterSpacing = (-1.4).sp, fontFamily = Sans, fontWeight = FontWeight.Normal,
            )
        }
        // quick numbers
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat(Modifier.weight(1f), "${s.chats.size}", "Chats", onClick = onMenu)
            Stat(Modifier.weight(1f), kfmt(core.tokensToday(s)), if (s.settings.routerBudget > 0) "of ${kfmt(s.settings.routerBudget)} today" else "Tokens today") { onSettings("router") }
            Stat(Modifier.weight(1f), repo?.repo?.take(10) ?: s.settings.model.substringAfterLast('/').take(10).ifBlank { "—" }, if (repo != null) "Linked repo" else "Model", dot = repo != null && (changes ?: 0) > 0) { if (repo != null) onShip() else onSettings("model") }
        }
        Spacer(Modifier.height(16.dp))
        // featured
        if (hero != null) HeroCard(hero.let { c -> project.name.let { c } }, core)
        else Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(p.card).pressable { onPrompt("Help me plan what to build first.") }.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            T("START HERE", 11, p.cardMuted, FontWeight.Medium, ls = 1f)
            T("Tell OrviX what you want to make", 22, p.cardInk, FontWeight.Medium, ls = -0.6f, lh = 1.15f)
            T("It can write files, run commands in its sandbox and push to GitHub for you.", 14, p.cardMuted)
        }
        if (repo != null && (changes ?: 0) > 0) {
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.accentSoft).pressable(onClick = onShip).padding(start = 18.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Ic(Icons.Outlined.AccountTree, 20, p.accent)
                Column(Modifier.weight(1f)) {
                    T("${changes} change${if (changes == 1) "" else "s"} ready", 15, p.ink, FontWeight.Medium)
                    T("${repo.owner}/${repo.repo} · ${repo.branch}", 12, p.muted, maxLines = 1)
                }
                Pill("Push", filled = true, icon = Icons.Outlined.ArrowUpward, onClick = onShip)
            }
        }
        // recent
        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            SectionHead("Recent", "${withMsgs.size}")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                recent.forEach { c -> RecentCard(core, c, s.projects.firstOrNull { it.id == c.projectId }) }
            }
        }
        // actions
        Spacer(Modifier.height(22.dp))
        SectionHead("Start something", null)
        val acts = buildList<Triple<ImageVector, String, () -> Unit>> {
            add(Triple(Icons.Outlined.Edit, "Write or edit") { onPrompt("Help me write or edit this:\n\n") })
            add(Triple(Icons.Outlined.Code, "Review my code") { onPrompt("Review this code and point out bugs and improvements:\n\n") })
            add(Triple(Icons.Outlined.Description, "Summarize a file") { onAttach("file") })
            add(Triple(Icons.Outlined.Terminal, "Try the sandbox") { onPrompt("Show me what the terminal sandbox on this phone can do: inspect it, then run a few useful commands in this project.") })
            if (repo != null) {
                add(Triple(Icons.Outlined.Android, "Build APK") { onPrompt("Build a debug APK of this repository and give me the file.") })
                add(Triple(Icons.Outlined.AccountTree, "Explain this repo") { onPrompt("Explain this repository: map the folders and entry points.") })
            } else add(Triple(Icons.Outlined.AccountTree, "Connect GitHub") { onShip() })
        }
        acts.chunked(2).forEach { row ->
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (ic, label, act) -> ActionCard(Modifier.weight(1f), ic, label, act) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

private fun headline(hour: Int, repo: String?, chats: Int, seed: Int): Pair<String, String> {
    val part = when { hour < 5 -> "night"; hour < 12 -> "morning"; hour < 18 -> "afternoon"; else -> "evening" }
    val pool = mutableListOf(
        "Good $part." to "What are we building?",
        "Ask once." to "Get it done properly.",
        "Describe it." to "OrviX does the rest.",
        "Small ask," to "big result.",
        "Ideas in." to "Code out.",
        "Think less" to "about the busywork.",
    )
    if (repo != null) { pool += "$repo," to "what's next?"; pool += "Your repo," to "one tap from live." }
    if (hour >= 22 || hour < 5) pool += "Late night?" to "Let's make it count."
    if (chats == 0) pool += "Welcome." to "Say hello to OrviX."
    return pool[seed.mod(pool.size)]
}

fun kfmt(n: Int): String = when {
    n < 1000 -> "$n"
    n < 100_000 -> String.format("%.1fk", n / 1000.0).replace(".0k", "k")
    n < 1_000_000 -> "${n / 1000}k"
    else -> String.format("%.1fM", n / 1_000_000.0)
}

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when {
        m < 1 -> "just now"
        m < 60 -> "${m}m ago"
        m < 1440 -> "${m / 60}h ago"
        m < 2880 -> "yesterday"
        else -> "${m / 1440}d ago"
    }
}

private fun snippet(c: Chat): String {
    val t = c.msgs.lastOrNull { it.role == "assistant" && it.text.isNotBlank() && it.status != "fail" }?.text
        ?: c.msgs.lastOrNull { it.role == "user" }?.text.orEmpty()
    return t.replace(Regex("[`*#>_\\[\\]]"), "").replace(Regex("\\s+"), " ").trim().take(140)
}

@Composable
private fun HomeRound(icon: ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.size(42.dp).clip(CircleShape).background(p.surface).pressable(onClick = onClick), Alignment.Center) { Ic(icon, 20, p.ink) }
}

@Composable
private fun Stat(modifier: Modifier, value: String, label: String, dot: Boolean = false, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(p.surface).pressable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            T(value, 20, p.ink, FontWeight.Medium, maxLines = 1, ls = -0.5f, lh = 1.1f)
            if (dot) Box(Modifier.size(7.dp).clip(CircleShape).background(p.accent))
        }
        T(label, 12, p.faint, maxLines = 1)
    }
}

@Composable
private fun HeroCard(c: Chat, core: Core) {
    val p = LocalPal.current
    val running = core.busy.collectAsState().value == c.id
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(p.card).pressable { core.openChat(c.id) }.padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            T(if (running) "RUNNING NOW" else "PICK UP WHERE YOU LEFT OFF", 11, p.cardMuted, FontWeight.Medium, ls = 1f)
            if (running) Box(Modifier.size(7.dp).clip(CircleShape).background(p.accent))
        }
        T(c.title, 24, p.cardInk, FontWeight.Medium, maxLines = 2, ls = -0.7f, lh = 1.12f)
        val sn = snippet(c)
        if (sn.isNotBlank()) T(sn, 14, p.cardMuted, maxLines = 3)
        T(ago(c.updated), 12, p.cardMuted)
    }
}

@Composable
private fun RecentCard(core: Core, c: Chat, pr: Project?) {
    val p = LocalPal.current
    Column(
        Modifier.width(210.dp).height(128.dp).clip(RoundedCornerShape(22.dp)).background(p.surface).pressable { core.openChat(c.id) }.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (pr != null) Box(Modifier.size(8.dp).clip(CircleShape).background(Color(pr.color)))
            T(ago(c.updated), 11, p.faint, maxLines = 1)
        }
        T(c.title, 16, p.ink, FontWeight.Medium, maxLines = 2, ls = -0.3f, lh = 1.2f)
        T(snippet(c), 12, p.muted, maxLines = 2)
    }
}

@Composable
private fun SectionHead(title: String, count: String?) {
    val p = LocalPal.current
    Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        T(title, 18, p.ink, FontWeight.Medium, ls = -0.3f)
        if (count != null) T(count, 13, p.muted)
    }
}

@Composable
private fun ActionCard(modifier: Modifier, icon: ImageVector, label: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(p.surface).pressable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(p.accentSoft), Alignment.Center) { Ic(icon, 17, p.accent) }
        T(label, 14, p.ink, FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
    }
}
