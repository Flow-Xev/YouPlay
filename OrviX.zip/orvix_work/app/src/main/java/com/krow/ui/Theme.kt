package com.krow.ui

import android.app.Activity
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import com.krow.R
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

/**
 * Krow palette — clean Google-style neutrals with a blue accent.
 */
@Immutable
class Pal(
    val dark: Boolean, val bg: Color, val side: Color, val surface: Color, val raised: Color, val sunk: Color,
    val ink: Color, val muted: Color, val faint: Color, val line: Color, val line2: Color,
    val accent: Color, val accentInk: Color, val ok: Color, val bad: Color,
    val shadow: Color,
    val accent2: Color = accent,
) {
    val accentSoft get() = accent.copy(alpha = if (dark) .14f else .10f)
    val okBg get() = ok.copy(alpha = .14f)
    val badBg get() = bad.copy(alpha = .12f)
    val threadMax: Dp get() = 780.dp
}

/** ClipSot palette: warm near-black / warm paper, one muted gold accent. */
val DarkPal = Pal(
    dark = true,
    bg = Color(0xFF101010), side = Color(0xFF101010), surface = Color(0xFF1B1B1B),
    raised = Color(0xFF242424), sunk = Color(0xFF0A0A0A),
    ink = Color(0xFFF4F3F0), muted = Color(0xFF92918E), faint = Color(0xFF666562),
    line = Color(0xFF242424), line2 = Color(0xFF303030),
    accent = Color(0xFFC9A574), accentInk = Color(0xFF1A1408),
    ok = Color(0xFF7CC08F), bad = Color(0xFFE2685D),
    shadow = Color(0xB3000000),
    accent2 = Color(0xFFDDBF93),
)

val LightPal = Pal(
    dark = false,
    bg = Color(0xFFF4F3EF), side = Color(0xFFF4F3EF), surface = Color(0xFFFFFFFF),
    raised = Color(0xFFFFFFFF), sunk = Color(0xFFE8E7E2),
    ink = Color(0xFF171717), muted = Color(0xFF777671), faint = Color(0xFFA3A29D),
    line = Color(0xFFE6E5DF), line2 = Color(0xFFD9D8D1),
    accent = Color(0xFFA98250), accentInk = Color(0xFFFFFFFF),
    ok = Color(0xFF2E8B57), bad = Color(0xFFB3392F),
    shadow = Color(0x1F171717),
    accent2 = Color(0xFFC09A68),
)

/** Composer / input surface and the user's message bubble. */
val Pal.field: Color get() = if (dark) Color(0xFF1B1B1B) else Color(0xFFFFFFFF)
val Pal.bubble: Color get() = if (dark) Color(0xFF292929) else Color(0xFFE8E7E2)

/** ClipSot signature: the featured card is light paper even in dark mode. */
val Pal.card: Color get() = if (dark) Color(0xFFE8E7E2) else Color(0xFFFFFFFF)
val Pal.cardInk: Color get() = Color(0xFF171717)
val Pal.cardMuted: Color get() = Color(0xFF6B6A66)

/** Inline-code chip: warm, quiet. */
val Pal.codeInk: Color get() = if (dark) Color(0xFFDDBF93) else Color(0xFF7A5A2E)
val Pal.codeBg: Color get() = if (dark) Color(0xFF1F1F1F) else Color(0xFFEDECE6)

/** Subtle gold sheen used for the primary button and the send button. */
val Pal.brand: Brush get() = Brush.linearGradient(listOf(accent, accent2))

val LocalPal = staticCompositionLocalOf { DarkPal }
/** Interface type: the device's own sans (Roboto / Google Sans) — the closest thing Android has to SF. */
val Sans: FontFamily = FontFamily.SansSerif
/** Answers use the same sans as the rest of the UI. */
val Read: FontFamily = Sans
val Mono = FontFamily(
    Font(R.font.krow_mono_regular, FontWeight.Normal),
    Font(R.font.krow_mono_regular, FontWeight.Medium),
    Font(R.font.krow_mono_bold, FontWeight.SemiBold),
    Font(R.font.krow_mono_bold, FontWeight.Bold),
)

/** Soft spring for UI entrances / send button — ChatGPT-like, not bouncy neon. */
fun <T> krowSpring() = spring<T>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow)

@Composable
fun KrowTheme(mode: String, accent: String = "", content: @Composable () -> Unit) {
    val dark = when (mode) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) darkColorScheme(
        primary = p.accent, onPrimary = p.accentInk, background = p.bg, surface = p.surface,
        onSurface = p.ink, onBackground = p.ink, secondary = p.muted, tertiary = p.ok,
    ) else lightColorScheme(
        primary = p.accent, onPrimary = p.accentInk, background = p.bg, surface = p.surface,
        onSurface = p.ink, onBackground = p.ink, secondary = p.muted, tertiary = p.ok,
    )
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = p.bg.toArgb()
        w.navigationBarColor = p.bg.toArgb()
        WindowCompat.getInsetsController(w, view).let {
            it.isAppearanceLightStatusBars = !dark
            it.isAppearanceLightNavigationBars = !dark
        }
    }
    // Keep layouts stable: follow the system text size, but only within a sane range.
    val d = LocalDensity.current
    val density = Density(d.density, fontScale = d.fontScale.coerceIn(0.9f, 1.15f))
    CompositionLocalProvider(LocalPal provides p, LocalDensity provides density) { MaterialTheme(colorScheme = cs, content = content) }
}
