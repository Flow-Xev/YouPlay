package com.krow

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.os.Handler
import android.os.Looper

/**
 * Every vibration in Krow lives here (ported from ClipSot).
 *
 * Android 11+ plays real haptic primitives (tick / click / thud) on the phone's motor, which feel crisp instead of
 * buzzy. Older phones get short amplitude-shaped pulses. It never throws, and it honours the system
 * "Touch feedback" switch. Strength is the user's choice: off / soft / medium / strong.
 */
object Haptics {
    private var appCtx: Context? = null
    private var vib: Vibrator? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastScroll = 0L

    /** off | soft | medium | strong */
    @Volatile var level: String = "medium"

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        vib = vibrator(ctx.applicationContext)
    }

    private val gain: Float
        get() = when (level) { "off" -> 0f; "soft" -> .6f; "strong" -> 1.35f; else -> 1f }

    // ---- the vocabulary ------------------------------------------------------
    /** Any button press. Barely there. */
    fun tap() = fire("tick", .45f)
    /** Choosing a chip, tab or option. */
    fun select() = fire("click", .5f)
    /** Switch flipped. On feels firmer than off. */
    fun toggle(on: Boolean) = if (on) fire("click", .8f) else fire("lowtick", .6f)
    fun longPress() = fire("heavy", .75f)
    /** Reached the end of a scroll. */
    fun edge() = fire("thud", .35f)
    /** Something finished well. */
    fun success() = fire("success", .85f)
    /** A destructive or approval-needed action. */
    fun warning() = fire("warning", .7f)
    fun thud() = fire("thud", 1f)
    fun lid() = fire("click", .7f)
    /** A message left, a model started working. */
    fun send() = fire("click", .75f)

    /** One detent of a scroll; [pxPerMs] is how fast the content moves, so a flick feels sharper than a drag. */
    fun scrollTick(pxPerMs: Float) {
        val t = System.currentTimeMillis()
        if (t - lastScroll < 24) return
        lastScroll = t
        fire("tick", (.3f + pxPerMs * .11f).coerceIn(.3f, .85f))
    }

    /** Rising run of ticks, like paper slowly tearing away (~530 ms). */
    fun peel() {
        if (gain <= 0f) return
        val v = vib ?: return
        if (!touchOn()) return
        val a = gain.coerceAtMost(1f)
        val e = (if (Build.VERSION.SDK_INT >= 30) peelComposition(v, a) else null) ?: peelLegacy(v, a) ?: return
        send(v, e)
    }

    /** A short sampler for Settings so the person can feel the level they picked. */
    fun preview() {
        fire("tick", .6f)
        main.postDelayed({ fire("click", .7f) }, 130)
        main.postDelayed({ fire("success", .9f) }, 300)
    }

    // ---- internals -----------------------------------------------------------
    private class Pulse(val gap: Long, val ms: Long, val a: Float)

    private fun pulses(kind: String): List<Pulse> = when (kind) {
        "tick" -> listOf(Pulse(0, 6, .35f))
        "lowtick" -> listOf(Pulse(0, 9, .3f))
        "click" -> listOf(Pulse(0, 12, .6f))
        "heavy" -> listOf(Pulse(0, 18, .85f))
        "thud" -> listOf(Pulse(0, 28, 1f))
        "success" -> listOf(Pulse(0, 11, .5f), Pulse(55, 16, .95f))
        "warning" -> listOf(Pulse(0, 22, .9f), Pulse(75, 22, .9f))
        else -> listOf(Pulse(0, 8, .4f))
    }

    @Suppress("DEPRECATION")
    private fun vibrator(ctx: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    private fun touchOn(): Boolean {
        val c = appCtx ?: return false
        return try { Settings.System.getInt(c.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) != 0 } catch (_: Exception) { true }
    }

    private fun fire(kind: String, base: Float) {
        val amp = (base * gain).coerceIn(0f, 1f)
        if (amp <= 0f) return
        val v = vib ?: return
        if (!v.hasVibrator() || !touchOn()) return
        val e = (if (Build.VERSION.SDK_INT >= 30) composition(v, kind, amp) else null) ?: legacy(v, kind, amp) ?: return
        send(v, e)
    }

    @SuppressLint("NewApi")
    private fun send(v: Vibrator, e: VibrationEffect) {
        try {
            if (Build.VERSION.SDK_INT >= 33) v.vibrate(e, VibrationAttributes.createForUsage(VibrationAttributes.USAGE_TOUCH))
            else v.vibrate(e)
        } catch (_: Exception) { }
    }

    @SuppressLint("NewApi")
    private fun composition(v: Vibrator, kind: String, a: Float): VibrationEffect? {
        val tick = VibrationEffect.Composition.PRIMITIVE_TICK
        val click = VibrationEffect.Composition.PRIMITIVE_CLICK
        val thud = VibrationEffect.Composition.PRIMITIVE_THUD
        val lowTick = if (Build.VERSION.SDK_INT >= 31) VibrationEffect.Composition.PRIMITIVE_LOW_TICK else tick
        fun ok(vararg p: Int) = v.areAllPrimitivesSupported(*p)
        return try {
            val c = VibrationEffect.startComposition()
            when (kind) {
                "tick" -> { if (!ok(tick)) return null; c.addPrimitive(tick, a) }
                "lowtick" -> { if (!ok(lowTick)) return null; c.addPrimitive(lowTick, a) }
                "click", "heavy" -> { if (!ok(click)) return null; c.addPrimitive(click, a) }
                "thud" -> { if (!ok(thud)) return null; c.addPrimitive(thud, a) }
                "success" -> { if (!ok(tick, click)) return null; c.addPrimitive(tick, a * .6f); c.addPrimitive(click, a, 55) }
                "warning" -> { if (!ok(thud)) return null; c.addPrimitive(thud, a * .9f); c.addPrimitive(thud, a * .9f, 80) }
                else -> { if (!ok(tick)) return null; c.addPrimitive(tick, a) }
            }
            c.compose()
        } catch (_: Exception) { null }
    }

    @SuppressLint("NewApi")
    private fun peelComposition(v: Vibrator, a: Float): VibrationEffect? {
        val tick = VibrationEffect.Composition.PRIMITIVE_TICK
        if (!v.areAllPrimitivesSupported(tick)) return null
        return try {
            val c = VibrationEffect.startComposition()
            for (i in 0 until 9) c.addPrimitive(tick, ((.18f + i * .085f) * a).coerceIn(.05f, 1f), if (i == 0) 0 else 90 - i * 7)
            c.compose()
        } catch (_: Exception) { null }
    }

    private fun peelLegacy(v: Vibrator, a: Float): VibrationEffect? = try {
        val t = ArrayList<Long>(); val amps = ArrayList<Int>()
        for (i in 0 until 9) {
            t.add(if (i == 0) 0L else (90 - i * 7).toLong()); amps.add(0)
            t.add(7L + i); amps.add(amplitude((.22f + i * .085f) * a, v))
        }
        VibrationEffect.createWaveform(t.toLongArray(), amps.toIntArray(), -1)
    } catch (_: Exception) { null }

    private fun legacy(v: Vibrator, kind: String, a: Float): VibrationEffect? {
        val list = pulses(kind)
        return try {
            if (list.size == 1) VibrationEffect.createOneShot(list[0].ms, amplitude(list[0].a * a, v))
            else {
                val t = ArrayList<Long>(); val amps = ArrayList<Int>()
                for (p in list) { t.add(p.gap); amps.add(0); t.add(p.ms); amps.add(amplitude(p.a * a, v)) }
                VibrationEffect.createWaveform(t.toLongArray(), amps.toIntArray(), -1)
            }
        } catch (_: Exception) { null }
    }

    private fun amplitude(f: Float, v: Vibrator): Int {
        if (!v.hasAmplitudeControl()) return VibrationEffect.DEFAULT_AMPLITUDE
        return (f * 255).toInt().coerceIn(1, 255)
    }
}
