package com.krow.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.krow.*
import kotlinx.coroutines.launch

private class Preset(val name: String, val provider: String, val url: String, val models: List<String>)

private val PRESETS = listOf(
    Preset("OpenAI", "openai", "https://api.openai.com/v1", listOf("gpt-4o-mini", "gpt-4o")),
    Preset("Google AI Studio", "openai", "https://generativelanguage.googleapis.com/v1beta/openai", listOf("gemini-2.5-flash", "gemini-2.5-pro")),
    Preset("OpenRouter", "openai", "https://openrouter.ai/api/v1", listOf("openai/gpt-4o-mini")),
    Preset("TokenRouter", "openai", "https://api.tokenrouter.com/v1", listOf("deepseek/deepseek-v4.1-flash-1017-free")),
    Preset("Groq", "openai", "https://api.groq.com/openai/v1", listOf("llama-3.3-70b-versatile")),
    Preset("Anthropic", "anthropic", "https://api.anthropic.com", listOf("claude-sonnet-5-5")),
    Preset("Custom", "openai", "", emptyList()),
)

/** Page titles. The home page is a short grouped list (like iOS Settings); every other page is one small topic. */
private val PAGE_TITLES = mapOf(
    "home" to "Settings", "model" to "Model", "router" to "Token router", "personal" to "Personalize", "voice" to "Voice input", "web" to "Search & images",
    "memory" to "Memory", "connectors" to "Connectors", "github" to "GitHub", "runs" to "Activity",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(core: Core, startPage: String = "home", onBack: () -> Unit, onSearch: () -> Unit = {}, extra: @Composable ColumnScope.() -> Unit = {}) {
    val p = LocalPal.current
    val s by core.state.collectAsState()
    val st = s.settings
    var confirmClear by remember { mutableStateOf(false) }
    var page by rememberSaveable { mutableStateOf(if (startPage in PAGE_TITLES) startPage else "home") }
    val back: () -> Unit = { if (page == "home") onBack() else page = "home" }
    androidx.activity.compose.BackHandler(enabled = page != "home") { page = "home" }

    Column(Modifier.fillMaxSize().background(p.bg)) {
        LargeTitle(PAGE_TITLES[page] ?: "Settings", back)
        Column(Modifier.weight(1f).hapticScroll().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
            when (page) {
                "home" -> {
                    Group {
                        GRow("Model", st.model.substringAfterLast('/').ifBlank { "Not set" }, Icons.Outlined.AutoAwesome, chevron = true) { page = "model" }
                        GRow("GitHub", core.linkedRepo()?.let { it.repo } ?: if (core.githubToken() != null) "Pick a repo" else "Not connected", Icons.Outlined.AccountTree, chevron = true, last = true) { page = "github" }
                    }
                    Group(title = "Chat") {
                        GRow("Search the web", icon = Icons.Outlined.Language, subtitle = "Lets OrviX look things up and read pages", trailing = {
                            KSwitch(st.webSearch) { v -> core.setSettings { it.copy(webSearch = v) } }
                        })
                        GRow("Token router", if (st.routerOn) "On" else "Off", Icons.Outlined.AltRoute, chevron = true) { page = "router" }
                        GRow("Memory", when (st.memory) { "off" -> "Off"; "ask" -> "Ask first"; else -> "Automatic" }, Icons.Outlined.Bookmark, chevron = true, last = true) { page = "memory" }
                    }
                    Group(title = "Appearance") {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                T("Theme", 15)
                                Segmented(listOf("system" to "Auto", "light" to "Light", "dark" to "Dark"), st.theme) { v -> core.setSettings { it.copy(theme = v) } }
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                T("Haptics", 15)
                                Segmented(listOf("off" to "Off", "soft" to "Soft", "medium" to "Medium", "strong" to "Strong"), st.haptics) { v ->
                                    Haptics.level = v
                                    core.setSettings { it.copy(haptics = v) }
                                    Haptics.preview()
                                }
                            }
                        }
                    }
                    Group(title = "More") {
                        GRow("Personalize", st.userName.ifBlank { null }, Icons.Outlined.Person, chevron = true) { page = "personal" }
                        GRow("Search the web now", icon = Icons.Outlined.Search, chevron = true) { onSearch() }
                        GRow("Connectors", if (st.connectors.isEmpty()) null else "${st.connectors.size}", Icons.Outlined.Extension, chevron = true) { page = "connectors" }
                        GRow("Voice input", icon = Icons.Outlined.Mic, chevron = true) { page = "voice" }
                        GRow("Search & images", icon = Icons.Outlined.Image, chevron = true) { page = "web" }
                        GRow("Activity", icon = Icons.Outlined.History, chevron = true, last = true) { page = "runs" }
                    }
                    Group(footer = "Everything stays on this device. Nothing leaves it except what you send to your AI provider and, if you use it, GitHub.") {
                        GRow("Delete all chats", icon = Icons.Outlined.Delete, danger = true, last = true) { Haptics.warning(); confirmClear = true }
                    }
                }
                "model" -> ModelPage(core)
                "router" -> RouterPage(core)
                "personal" -> PersonalPage(core)
                "voice" -> VoiceSection(core)
                "web" -> { WebSearchSection(core); ImageSettingsSection(core) }
                "memory" -> MemorySection(core)
                "connectors" -> ConnectorsSection(core)
                "runs" -> RunsSection(core, onOpen = onBack)
                "github" -> extra()
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirmClear) ConfirmDialog("Delete all chats?", "Project folders and files are kept.", "Delete", { confirmClear = false }) { core.clearAllChats(); confirmClear = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ModelPage(core: Core) {
    val p = LocalPal.current
    val s by core.state.collectAsState()
    val st = s.settings
    val scope = rememberCoroutineScope()
    var keyIn by rememberSaveable { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var modelIn by rememberSaveable { mutableStateOf("") }
    var fetching by remember { mutableStateOf(false) }
    var urlIn by remember(st.baseUrl) { mutableStateOf(st.baseUrl) }
    val saved = remember(tick, st.baseUrl) { core.apiKey() }
    val preset = PRESETS.firstOrNull { it.url.isNotEmpty() && it.url == st.baseUrl }

    Group(title = "Provider") {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PRESETS.forEach { pr ->
                    Pill(pr.name, selected = if (pr.url.isEmpty()) preset == null else pr.url == st.baseUrl) {
                        core.setSettings { it.copy(provider = pr.provider, baseUrl = pr.url, models = pr.models, model = pr.models.firstOrNull() ?: "") }
                    }
                }
            }
            if (preset == null) {
                Label("Base URL")
                Field(urlIn, { urlIn = it }, "https://…/v1", mono = true)
                Segmented(listOf("openai" to "OpenAI-compatible", "anthropic" to "Anthropic"), st.provider) { v -> core.setSettings { it.copy(provider = v) } }
                Pill("Save URL", filled = true) { core.setSettings { it.copy(baseUrl = urlIn.trim()) }; core.say("Base URL saved") }
            }
        }
    }
    Group(title = "API key", footer = "Stored encrypted on this device and only ever sent to this provider.") {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (saved != null) T("Saved  ·  ····${saved.takeLast(4)}", 13, p.ok)
            Field(keyIn, { keyIn = it }, if (saved != null) "Paste a new key to replace it" else "Paste your key", mono = true, password = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Save key", filled = true) {
                    if (keyIn.isNotBlank()) { core.secrets.put(Secrets.apiKeyName(st.baseUrl), keyIn.trim()); keyIn = ""; tick++; Haptics.success(); core.say("Key saved (encrypted)") }
                }
                if (saved != null) Pill("Remove", color = p.bad) { core.secrets.remove(Secrets.apiKeyName(st.baseUrl)); tick++ }
            }
        }
    }
    Group(title = "Models") {
        st.models.forEachIndexed { i, m ->
            GRow(
                m.substringAfterLast('/'), subtitle = if (m.contains('/')) m else null, last = false,
                trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        if (m == st.model) Ic(Icons.Outlined.Check, 20, p.accent)
                        IconBtn(Icons.Outlined.Close, "Remove", 32, p.faint) {
                            core.setSettings { c -> val l = c.models - m; c.copy(models = l, model = if (c.model == m) l.firstOrNull() ?: "" else c.model) }
                        }
                    }
                },
            ) { core.setSettings { it.copy(model = m) } }
        }
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(modelIn, { modelIn = it }, "Add a model id, e.g. gpt-4o", mono = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Add", filled = true) {
                    val m = modelIn.trim()
                    if (m.isNotEmpty()) { core.setSettings { it.copy(models = (it.models + m).distinct(), model = m) }; modelIn = "" }
                }
                Pill(if (fetching) "Fetching…" else "Fetch from API") {
                    if (!fetching) scope.launch {
                        fetching = true
                        try {
                            val ids = core.fetchModels()
                            core.setSettings { it.copy(models = ids, model = if (it.model in ids) it.model else ids.firstOrNull() ?: it.model) }
                            core.say("${ids.size} models loaded")
                        } catch (e: Throwable) { core.say("Could not fetch models: ${e.message?.take(160)}") }
                        fetching = false
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonalPage(core: Core) {
    val s by core.state.collectAsState()
    val st = s.settings
    Group(title = "Your name", footer = "Shown as initials in the sidebar.") {
        var nm by remember(st.userName) { mutableStateOf(st.userName) }
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(nm, { nm = it }, "e.g. Mohit Z")
            Pill("Save", filled = true) { core.setSettings { it.copy(userName = nm.trim()) }; Haptics.success(); core.say("Saved") }
        }
    }
    Group(title = "Custom instructions", footer = "Added to every chat. Keep it short: tone, language, things OrviX should always or never do.") {
        var ins by remember(st.instructions) { mutableStateOf(st.instructions) }
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(ins, { ins = it }, "e.g. Answer briefly. Prefer Kotlin.", singleLine = false)
            Pill("Save", filled = true) { core.setSettings { it.copy(instructions = ins) }; Haptics.success(); core.say("Saved") }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        T(title.uppercase(), 12, p.faint, FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, bottom = 7.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
    }
}

@Composable
fun Label(t: String) { T(t, 13, LocalPal.current.muted) }
