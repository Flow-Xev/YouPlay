package com.krow.ui

import android.graphics.BlurMaskFilter
import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.graphics.layer.*
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.krow.Haptics
import kotlinx.coroutines.CompletableDeferred
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * The peel: a row curls off its corner like a sheet of paper, balls up and drops into a little bin
 * (ported from ClipSot's PeelItem). Used whenever something is deleted.
 *
 *   val peel = rememberPeelState()
 *   Row(Modifier.peelable(peel)) { … }
 *   scope.launch { peel.play(LocalPeel.current) { core.deleteChat(id) } }   // the lambda runs when the row has "left"
 */

class PeelAnim(val image: ImageBitmap, val rect: Rect, val onCollapse: () -> Unit, val onDone: () -> Unit)

class PeelController { var anim by mutableStateOf<PeelAnim?>(null) }

val LocalPeel = staticCompositionLocalOf<PeelController?> { null }

class PeelState(val layer: GraphicsLayer) {
    var bounds by mutableStateOf(Rect.Zero)
    var hidden by mutableStateOf(false)

    /** Plays the peel. [onRemove] runs once the paper is off its corner (the row should disappear then). */
    suspend fun play(ctl: PeelController?, reducedMotion: Boolean, onRemove: () -> Unit) {
        if (ctl == null || reducedMotion || bounds.width < 2f || bounds.height < 2f) { onRemove(); return }
        val img = try { layer.toImageBitmap() } catch (_: Throwable) { onRemove(); return }
        hidden = true
        val done = CompletableDeferred<Unit>()
        ctl.anim = PeelAnim(img, bounds, onRemove) { ctl.anim = null; done.complete(Unit) }
        done.await()
    }
}

@Composable
fun rememberPeelState(): PeelState {
    val layer = rememberGraphicsLayer()
    return remember { PeelState(layer) }
}

/** Records the content into a layer (so it can be photographed) and draws it, unless it has been peeled away. */
fun Modifier.peelable(s: PeelState): Modifier = this
    .onGloballyPositioned { s.bounds = it.boundsInRoot() }
    .drawWithContent {
        s.layer.record { this@drawWithContent.drawContent() }
        if (!s.hidden) drawLayer(s.layer)
    }

@Composable
fun reducedMotion(): Boolean {
    val ctx = LocalContext.current
    return remember {
        try { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (_: Exception) { false }
    }
}

// --------------------------------------------------------------------------- overlay (hosted once, in Root)

private const val PEEL_MS = 1400
private const val T_PEEL_END = .42f
private const val T_LAND = .80f
private const val T_LID = .92f

private val easeInOutCubic = CubicBezierEasing(.645f, .045f, .355f, 1f)
private val easeOutBack = CubicBezierEasing(.175f, .885f, .32f, 1.275f)
private val easeOutCubic = CubicBezierEasing(.215f, .61f, .355f, 1f)
private val easeInCubic = CubicBezierEasing(.55f, .055f, .675f, .19f)
private val easeIn = CubicBezierEasing(.42f, 0f, 1f, 1f)

private fun seg(t: Float, a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)
private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

@Composable
fun PeelOverlay(ctl: PeelController) {
    val a = ctl.anim ?: return
    val pal = LocalPal.current
    val prog = remember(a) { Animatable(0f) }
    val safeBottom = WindowInsets.navigationBars.getBottom(LocalDensity.current).toFloat()
    LaunchedEffect(a) {
        var collapsed = false; var landed = false; var shut = false
        Haptics.peel()
        prog.animateTo(1f, tween(PEEL_MS, easing = LinearEasing)) {
            val t = value
            if (!collapsed && t >= T_PEEL_END) { collapsed = true; a.onCollapse() }
            if (!landed && t >= T_LAND) { landed = true; Haptics.thud() }
            if (!shut && t >= T_LID) { shut = true; Haptics.lid() }
        }
        a.onDone()
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawIntoCanvas { c -> paintPeel(c, size, a, prog.value, pal, safeBottom, density) }
        }
    }
}

private fun reflection(d: Offset, corner: Offset, s: Float): Matrix {
    val a = 1 - 2 * d.x * d.x
    val b = -2 * d.x * d.y
    val dd = 1 - 2 * d.y * d.y
    val k = 2 * ((corner.x * d.x + corner.y * d.y) + s)
    return Matrix(floatArrayOf(
        a, b, 0f, 0f,
        b, dd, 0f, 0f,
        0f, 0f, 1f, 0f,
        k * d.x, k * d.y, 0f, 1f,
    ))
}

private val PAPER = Color(0xFFEFEBE2)

private fun imgPaint(tinted: Boolean): Paint = Paint().apply {
    filterQuality = FilterQuality.Medium
    if (tinted) colorFilter = ColorFilter.tint(PAPER.copy(alpha = 215f / 255f), BlendMode.SrcAtop)
}

private fun paintPeel(c: GfxCanvas, size: Size, a: PeelAnim, t: Float, pal: Pal, safeBottom: Float, u: Float) {
    val rect = a.rect
    val w = rect.width; val h = rect.height
    val diag = sqrt(w * w + h * h)
    val img = a.image
    val src = IntSize(img.width, img.height)
    val dstSize = IntSize(w.roundToInt().coerceAtLeast(1), h.roundToInt().coerceAtLeast(1))

    // the bin, bottom centre
    val binBase = Offset(size.width / 2, size.height - safeBottom - 26 * u)
    val binH = 70 * u
    val binIn = easeOutBack.transform(seg(t, .10f, .34f))
    val binOut = easeIn.transform(seg(t, .93f, 1f))
    val binDy = (1 - binIn) * 150 * u + binOut * 150 * u
    val lidOpen = easeOutCubic.transform(seg(t, .30f, .52f)) * (1 - easeInCubic.transform(seg(t, .84f, T_LID)))
    val mouth = Offset(binBase.x, binBase.y + binDy - binH)

    // peel runs from the top-right corner toward the bottom-left
    val d = Offset(-w, h) / diag
    val corner = Offset(w, 0f)

    if (t < T_PEEL_END) {
        val p = easeInOutCubic.transform(t / T_PEEL_END)
        val s = diag * p
        c.save()
        c.translate(rect.left, rect.top)
        peelPass(c, img, src, dstSize, w, h, d, corner, s, diag, p, u)
        c.restore()
    } else {
        val q = seg(t, T_PEEL_END, T_LAND)
        val e = easeInOutCubic.transform(q)
        val center = Offset(w / 2, h / 2)
        val proj = (center.x - corner.x) * d.x + (center.y - corner.y) * d.y
        val c0 = center - d * (2 * (proj - diag))
        val c0s = rect.topLeft + c0
        val target = Offset(mouth.x, mouth.y + 6 * u + 22 * u * seg(q, .82f, 1f))
        val pos = Offset(lerp(c0s.x, target.x, e), lerp(c0s.y, target.y, e) - sin(PI.toFloat() * e) * 70 * u)
        val ball = 50 * u * (1 - .15f * e)
        val sx = lerp(1f, ball / w, easeIn.transform(e))
        val sy = lerp(1f, ball / h, easeIn.transform(e))
        val crumple = easeIn.transform(seg(q, .12f, .85f))
        val angle = -e * 1.4f

        c.save()
        c.translate(pos.x, pos.y)
        c.rotate(angle * 180f / PI.toFloat())
        c.scale(sx, sy)
        c.translate(-c0.x, -c0.y)
        c.concat(reflection(d, corner, diag))

        val rx = w / 2 * crumple; val ry = h / 2 * crumple
        val shadow = Paint().apply {
            color = Color(0x40000000)
            asFrameworkPaint().maskFilter = BlurMaskFilter(10f * u, BlurMaskFilter.Blur.NORMAL)
        }
        val sh = 8 * u / max(sy, .05f)
        c.drawRoundRect(0f, sh, w, h + sh, rx, ry, shadow)
        val clip = Path().apply { addRoundRect(RoundRect(Rect(0f, 0f, w, h), CornerRadius(rx, ry))) }
        c.save()
        c.clipPath(clip)
        c.drawImageRect(img, IntOffset.Zero, src, IntOffset.Zero, dstSize, imgPaint(true))
        if (crumple > 0f) {
            val shade = Paint().apply {
                shader = RadialGradientShader(
                    Offset(w / 2, h / 2), max(w, h) / 2,
                    listOf(Color(0x00000000), Color.Black.copy(alpha = .38f * crumple)), listOf(.45f, 1f),
                )
            }
            c.drawRoundRect(0f, 0f, w, h, rx, ry, shade)
        }
        c.restore()
        c.restore()
    }

    // the bin is drawn after the paper so the paper drops *into* it
    if (t > .08f && binOut < 1f) {
        paintBin(c, Offset(binBase.x, binBase.y + binDy), binH, lidOpen, pal.accent, 1f - binOut)
    }
}

private fun peelPass(c: GfxCanvas, img: ImageBitmap, src: IntSize, dst: IntSize, w: Float, h: Float, d: Offset, corner: Offset, s: Float, diag: Float, p: Float, u: Float) {
    val n = Offset(-d.y, d.x)
    val fold = corner + d * s
    val big = diag * 3
    fun half(side: Float) = Path().apply {
        moveTo(fold.x + n.x * big, fold.y + n.y * big)
        lineTo(fold.x - n.x * big, fold.y - n.y * big)
        lineTo(fold.x - n.x * big + d.x * big * side, fold.y - n.y * big + d.y * big * side)
        lineTo(fold.x + n.x * big + d.x * big * side, fold.y + n.y * big + d.y * big * side)
        close()
    }
    val front = half(1f)   // still attached
    val gone = half(-1f)   // lifted
    val deg = atan2(d.y, d.x) * 180f / PI.toFloat()
    val edge = 38 * u

    // attached part + shadow cast by the lifted paper
    c.save()
    c.clipPath(front)
    c.drawImageRect(img, IntOffset.Zero, src, IntOffset.Zero, dst, imgPaint(false))
    c.save()
    c.translate(fold.x, fold.y)
    c.rotate(deg)
    c.drawRect(0f, -big, edge, big, Paint().apply {
        shader = LinearGradientShader(Offset.Zero, Offset(edge, 0f), listOf(Color.Black.copy(alpha = .42f * (1 - p * .4f)), Color(0x00000000)))
    })
    c.restore()
    c.restore()

    if (s < 1f) return
    // the lifted flap: the removed part mirrored over the fold, showing the paper's back
    c.save()
    c.clipPath(front)
    c.concat(reflection(d, corner, s))
    c.clipPath(gone)
    c.clipRect(0f, 0f, w, h)
    c.drawImageRect(img, IntOffset.Zero, src, IntOffset.Zero, dst, imgPaint(true))
    c.translate(fold.x, fold.y)
    c.rotate(deg)
    val curl = 46 * u
    c.drawRect(-curl, -big, 0f, big, Paint().apply {
        shader = LinearGradientShader(Offset(-curl, 0f), Offset.Zero, listOf(Color(0x00FFFFFF), Color(0x66FFFFFF)))
    })
    c.restore()
}

/** The little bin; [base] is its bottom-centre. */
private fun paintBin(c: GfxCanvas, base: Offset, height: Float, lid: Float, body: Color, opacity: Float) {
    val k = height / 70f
    val topW = 62 * k; val botW = 50 * k
    val top = base.y - height
    fun col(x: Color, f: Float = 1f) = x.copy(alpha = (f * opacity).coerceIn(0f, 1f))

    // ground shadow
    c.drawOval(base.x - botW * .75f, base.y - 2 * k, base.x + botW * .75f, base.y + 6 * k, Paint().apply {
        color = col(Color.Black, .22f)
        asFrameworkPaint().maskFilter = BlurMaskFilter(5 * k, BlurMaskFilter.Blur.NORMAL)
    })

    val path = Path().apply {
        moveTo(base.x - topW / 2, top); lineTo(base.x + topW / 2, top)
        lineTo(base.x + botW / 2, base.y); lineTo(base.x - botW / 2, base.y); close()
    }
    c.drawPath(path, Paint().apply { color = col(body) })
    val ridge = Paint().apply {
        color = col(Color.Black, .22f); strokeWidth = 2.2f * k; strokeCap = StrokeCap.Round; style = PaintingStyle.Stroke
    }
    for (f in floatArrayOf(-.28f, 0f, .28f)) {
        c.drawLine(Offset(base.x + topW * f, top + 12 * k), Offset(base.x + botW * f, base.y - 8 * k), ridge)
    }

    // lid hinged on its left end, swings up and back
    c.save()
    c.translate(base.x - topW / 2 - 3 * k, top)
    c.rotate(-lid * 1.25f * 180f / PI.toFloat())
    val lidW = topW + 6 * k
    val lidPaint = Paint().apply { color = col(lerpColor(body, Color.Black, .12f)) }
    c.drawRoundRect(0f, -8 * k, lidW, 0f, 4 * k, 4 * k, lidPaint)
    c.drawRoundRect(lidW / 2 - 11 * k, -13 * k, lidW / 2 + 11 * k, -7 * k, 3 * k, 3 * k, lidPaint)
    c.restore()
}

private fun lerpColor(a: Color, b: Color, t: Float) = androidx.compose.ui.graphics.lerp(a, b, t)
