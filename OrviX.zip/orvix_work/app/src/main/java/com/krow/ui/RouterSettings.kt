package com.krow.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.krow.*

/** Settings → Token router. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouterPage(core: Core) {
    val p = LocalPal.current
    val s by core.state.collectAsState()
    val st = s.settings
    val used = core.tokensToday(s)

    Group(footer = "Each request goes to your fast model unless it looks hard (long, code, errors, attachments, repo work), then it goes to your strong model. The choice is made once per request and kept for all its tool steps.") {
        GRow("Token router", icon = Icons.Outlined.AltRoute, subtitle = if (st.routerOn) "On · picks a model for every request" else "Off · always uses ${st.model.substringAfterLast('/').ifBlank { "your default model" }}", last = true, trailing = {
            KSwitch(st.routerOn) { v -> core.setSettings { it.copy(routerOn = v, routerFast = if (v && it.routerFast.isBlank()) it.model else it.routerFast, routerSmart = if (v && it.routerSmart.isBlank()) it.model else it.routerSmart) } }
        })
    }
    if (!st.routerOn) {
        Group(title = "Today") { UsageRow(used, st.routerBudget) }
        return
    }
    Group(title = "Fast model", footer = "Quick, cheap: greetings, short questions, small edits. Also names your chats.") {
        Column(Modifier.padding(14.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                st.models.forEach { m -> Pill(m.substringAfterLast('/'), selected = m == st.routerFast) { core.setSettings { it.copy(routerFast = m) } } }
            }
        }
    }
    Group(title = "Strong model", footer = "Used for debugging, builds, long or code-heavy asks, attachments and git work. Add more models under Model.") {
        Column(Modifier.padding(14.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                st.models.forEach { m -> Pill(m.substringAfterLast('/'), selected = m == st.routerSmart) { core.setSettings { it.copy(routerSmart = m) } } }
            }
        }
    }
    Group(title = "Daily budget") {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            UsageBar(used, st.routerBudget)
            Segmented(listOf("0" to "No limit", "50000" to "50k", "200000" to "200k", "1000000" to "1M"), st.routerBudget.toString()) { v -> core.setSettings { it.copy(routerBudget = v.toInt()) } }
            if (st.routerBudget > 0) {
                T("When the budget is used up", 14, p.muted)
                Segmented(listOf("fast" to "Use fast model", "stop" to "Stop and ask"), st.routerOver) { v -> core.setSettings { it.copy(routerOver = v) } }
            }
        }
    }
    Group(title = "Save input tokens", footer = "Tool output from earlier steps (file contents, command logs) is the biggest hidden cost. Old results are shortened to their start and end before being sent again; the full text stays in the chat.") {
        GRow("Trim old tool output", icon = Icons.Outlined.ContentCut, last = true, trailing = { KSwitch(st.routerTrim) { v -> core.setSettings { it.copy(routerTrim = v) } } })
    }
    val recent = remember(s.chats) {
        s.chats.flatMap { c -> c.msgs.filter { it.role == "assistant" && it.model != null && (it.inTok + it.outTok) > 0 } }.sortedByDescending { it.at }.take(6)
    }
    if (recent.isNotEmpty()) Group(title = "Recent replies") {
        recent.forEachIndexed { i, m ->
            GRow(m.model!!.substringAfterLast('/'), kfmt(m.inTok + m.outTok), icon = if (m.model == st.routerSmart && st.routerSmart != st.routerFast) Icons.Outlined.Bolt else Icons.Outlined.Speed,
                subtitle = "${kfmt(m.inTok)} in · ${kfmt(m.outTok)} out · ${hhmm(m.at)}", last = i == recent.lastIndex)
        }
    }
}

@Composable
private fun UsageRow(used: Int, budget: Int) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { UsageBar(used, budget) }
}

@Composable
private fun UsageBar(used: Int, budget: Int) {
    val p = LocalPal.current
    Row(verticalAlignment = Alignment.Bottom) {
        T(kfmt(used), 28, p.ink, FontWeight.Medium, ls = -0.8f, lh = 1f)
        T(if (budget > 0) "  of ${kfmt(budget)} tokens today" else "  tokens today", 14, p.muted, modifier = Modifier.padding(bottom = 3.dp))
    }
    if (budget > 0) Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(p.sunk)) {
        Box(Modifier.fillMaxWidth((used.toFloat() / budget).coerceIn(0.01f, 1f)).fillMaxHeight().background(if (used >= budget) p.bad else p.accent))
    }
}
