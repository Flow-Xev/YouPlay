package com.krow.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * The OrviX mark: a ring (the "O") crossed by a bright orbit. Master geometry is brand/orvix-icon.svg (1254 grid); the launcher
 * vectors in res/drawable use the very same numbers. Colours follow the app palette (paper to gold; the orbit is the accent).
 *
 * ring and orbit are 0..1 reveal progress (the splash animates them). gap is the colour of the cut where the orbit crosses the ring.
 */
@Composable
fun OrviXMark(
    size: Dp, modifier: Modifier = Modifier, ring: Float = 1f, orbit: Float = 1f,
    gap: Color = LocalPal.current.bg, dark: Boolean = LocalPal.current.dark,
) {
    val ringPath = remember { PathParser().parsePathString(RING_D).toPath().also { it.fillType = PathFillType.EvenOdd } }
    val orbitPath = remember { PathParser().parsePathString(ORBIT_D).toPath() }
    val ringCols = if (dark) listOf(Color(0xFFF4F3F0), Color(0xFFD9BE92), Color(0xFF8F6F42)) else listOf(Color(0xFF3B2E1B), Color(0xFF7A5A2E), Color(0xFFB08A55))
    val orbitCols = if (dark) listOf(Color(0xFFA98250), Color(0xFFE3C79B), Color(0xFFC9A574)) else listOf(Color(0xFF8A6A3E), Color(0xFFC09A68), Color(0xFFA98250))
    Canvas(modifier.size(size)) {
        val k = minOf(this.size.width / 932f, this.size.height / 623f)
        val ox = (this.size.width - 932f * k) / 2f - 168f * k
        val oy = (this.size.height - 623f * k) / 2f - 292f * k
        withTransform({ translate(ox, oy); scale(k, k, Offset.Zero) }) {
            val r = ring.coerceIn(0f, 1f)
            if (r > 0f) {
                withTransform({ scale(0.82f + 0.18f * r, 0.82f + 0.18f * r, Offset(626f, 604f)) }) {
                    drawPath(ringPath, Brush.linearGradient(ringCols, Offset(330f, 320f), Offset(930f, 900f)), alpha = r)
                }
            }
            val o = orbit.coerceIn(0f, 1f)
            if (o > 0f) {
                // the orbit sweeps in from its lower-left end to its upper-right end
                clipRect(left = 160f, top = 280f, right = 160f + 950f * o, bottom = 930f) {
                    drawPath(orbitPath, gap, style = Stroke(width = 40f, join = StrokeJoin.Round))
                    drawPath(orbitPath, Brush.linearGradient(orbitCols, Offset(170f, 840f), Offset(1090f, 360f)))
                }
            }
        }
    }
}

private const val RING_D = "M296,604 a330,312 0 1,0 660,0 a330,312 0 1,0 -660,0 Z M418,601 a206,218 0 1,0 412,0 a206,218 0 1,0 -412,0 Z"
private const val ORBIT_D = "M295,688 C215,750 165,810 168,840 C172,872 230,862 270,846 C470,770 720,670 955,562 C1060,505 1105,440 1097,380 C1090,335 960,340 893,366 C985,360 1030,372 1010,395 C960,460 800,540 640,610 C520,665 380,735 290,790 C255,800 232,795 237,775 C245,750 270,712 295,688 Z"

/** App icon look: the mark on a rounded dark tile. */
@Composable
fun OrviXTile(size: Dp) {
    Box(Modifier.size(size).background(Color(0xFF101010), RoundedCornerShape(size * 0.24f)), Alignment.Center) {
        OrviXMark(size * 0.66f, gap = Color(0xFF101010), dark = true)
    }
}

/** "orvix." — lowercase, tight, with the full stop in the accent colour. */
@Composable
fun Wordmark(sizeSp: Int = 28, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Row(modifier, verticalAlignment = Alignment.Bottom) {
        T("orvix", sizeSp, p.ink, FontWeight.Medium, ls = -sizeSp * 0.035f, lh = 1f)
        T(".", sizeSp, p.accent, FontWeight.Medium, lh = 1f)
    }
}

private fun easeOutBack(x: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; val t = x - 1f; return 1f + c3 * t * t * t + c1 * t * t }

/** Splash: the ring grows in, the orbit sweeps across it, the wordmark rises letter by letter, then everything fades out. */
@Composable
fun Splash(onDone: () -> Unit) {
    val p = LocalPal.current
    val reduce = reducedMotion()
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (reduce) { t.snapTo(0.9f); delay(450) } else t.animateTo(1f, tween(2100, easing = LinearEasing))
        onDone()
    }
    fun seg(a: Float, b: Float): Float = ((t.value - a) / (b - a)).coerceIn(0f, 1f)
    fun ease(x: Float) = FastOutSlowInEasing.transform(x)
    val halo = ease(seg(0f, .5f))
    val settle = 0.5f - kotlin.math.abs(seg(.55f, .75f) - 0.5f)
    val word = "orvix"
    Box(Modifier.fillMaxSize().background(p.bg).alpha(1f - seg(.93f, 1f)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(250.dp), Alignment.Center) {
                Box(Modifier.size(210.dp).scale(0.55f + 0.45f * halo).alpha(halo).background(p.accent.copy(alpha = 0.10f), CircleShape))
                OrviXMark(190.dp, Modifier.scale(1f + settle * 0.06f), ring = ease(seg(.04f, .34f)), orbit = ease(seg(.28f, .56f)))
            }
            Row(verticalAlignment = Alignment.Bottom) {
                word.forEachIndexed { i, ch ->
                    val a = ease(seg(.52f + i * .03f, .52f + i * .03f + .2f))
                    T(ch.toString(), 56, p.ink, FontWeight.Medium, ls = -2f, lh = 1f, modifier = Modifier.alpha(a).offset(y = (22f * (1f - a)).dp))
                }
                val d = easeOutBack(seg(.78f, .9f)).coerceIn(0f, 1.4f)
                T(".", 56, p.accent, FontWeight.Medium, lh = 1f, modifier = Modifier.alpha(d.coerceIn(0f, 1f)).scale(d))
            }
            Spacer(Modifier.height(10.dp))
            T("Ask. Build. Ship.", 16, p.muted, modifier = Modifier.alpha(ease(seg(.84f, .97f))))
        }
    }
}
