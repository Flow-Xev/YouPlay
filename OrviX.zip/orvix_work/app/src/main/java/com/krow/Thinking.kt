package com.krow

import kotlinx.serialization.json.*

/**
 * Two tools that make any model work the way a careful engineer does:
 *  - `think`: write your reasoning down before acting. It shows up as a collapsible "Thought" in the action timeline,
 *    so models without a native reasoning mode still think visibly.
 *  - `update_plan`: a live checklist for multi-step work (pending / in_progress / done), rendered as a plan card.
 */
class ThinkTool : Tool {
    override val spec = ToolSpec(
        "think",
        "Reason out loud before acting. Use it when the task is non-trivial, before choosing between approaches, after an unexpected result or error, and before any change that is hard to undo. " +
            "Write 2-6 first-person sentences: what you know, what you are unsure about, what you will do next and why. It changes nothing; the user sees it as a collapsed 'Thought'. Skip it for trivial lookups.",
        schema(listOf("thought"), "thought" to prop("string", "Your reasoning, in plain first-person sentences")),
    )
    override val kind = "think"
    override fun title(a: JsonObject) = a.str("step_name")?.trim()?.ifBlank { null } ?: "Thinking it through"
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val t = a.str("thought")?.trim().orEmpty()
        return ToolOut(if (t.isBlank()) "Noted." else t)
    }
}

class UpdatePlan : Tool {
    override val spec = ToolSpec(
        "update_plan",
        "Create or update the checklist for multi-step work (3 or more steps). Send the FULL list every time. Statuses: pending, in_progress, done. Keep exactly one task in_progress while you work, mark tasks done as soon as they are really finished, and finish with every task done. Do not use it for one-step requests.",
        buildJsonObject {
            put("type", "object")
            putJsonObject("properties") {
                putJsonObject("tasks") {
                    put("type", "array")
                    put("description", "The complete task list, in order")
                    putJsonObject("items") {
                        put("type", "object")
                        putJsonObject("properties") {
                            putJsonObject("text") { put("type", "string"); put("description", "Short, concrete task, imperative (e.g. 'Fix the settings crash')") }
                            putJsonObject("status") { put("type", "string"); putJsonArray("enum") { add("pending"); add("in_progress"); add("done") } }
                        }
                        putJsonArray("required") { add("text"); add("status") }
                    }
                }
            }
            putJsonArray("required") { add("tasks") }
        },
    )
    override val kind = "plan"
    override fun title(a: JsonObject) = "Plan"
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val arr = a["tasks"] as? JsonArray ?: return ToolOut("Send a 'tasks' array.", false)
        val lines = arr.mapNotNull { e ->
            val o = e as? JsonObject ?: return@mapNotNull null
            val text = o.str("text")?.trim()?.replace('\n', ' ')?.take(120)?.ifBlank { null } ?: return@mapNotNull null
            val st = when (o.str("status")) { "done" -> "done"; "in_progress" -> "doing"; else -> "todo" }
            "$st|$text"
        }
        if (lines.isEmpty()) return ToolOut("The plan was empty.", false)
        return ToolOut(lines.joinToString("\n"))
    }
}

/** Parsed plan row for the UI. state = todo | doing | done */
data class PlanItem(val state: String, val text: String)

fun parsePlan(text: String): List<PlanItem> = text.lines().mapNotNull { l ->
    val i = l.indexOf('|')
    if (i <= 0) null else PlanItem(l.substring(0, i), l.substring(i + 1))
}
