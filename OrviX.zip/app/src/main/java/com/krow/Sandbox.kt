package com.krow

import android.os.Process as AndroidProcess
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Krow's in-app sandbox.
 *
 * What it really is: a persistent `/system/bin/sh` per project that runs as OrviX's Android app UID and starts in the project folder.
 * It is NOT a kernel filesystem sandbox: the process has the app UID's access to app-private storage. [Guard] blocks known-dangerous
 * command patterns but is only a best-effort text guard, not a security boundary. Never expose secrets to this shell or claim arbitrary
 * shell commands are confined. File tools use canonical project-root checks and are the safe way to manipulate project files.
 *
 * What makes it pleasant for the AI (and for you in the step card):
 *  - state survives between calls: `cd`, `export`, shell functions and variables behave like a real terminal session
 *  - live output streams into the step card while the command runs
 *  - timeouts and Stop kill the command's whole process tree but keep the session alive
 *  - long jobs (dev servers, builds, watchers) run in the background and are read with job_output / stopped with job_stop
 *  - huge output is cleaned (ANSI, progress bars), head+tail trimmed for the model and saved in full to a file
 */
class Sandbox(private val core: Core) {
    private val sessions = ConcurrentHashMap<String, ShellSession>()
    val jobs = ConcurrentHashMap<String, BgJob>()
    private var jobSeq = 0

    fun session(p: Project): ShellSession = sessions.getOrPut(p.id) {
        ShellSession(core.projectDir(p).canonicalFile, File(core.app.cacheDir, "sh/${p.id}"))
    }

    fun reset(p: Project) { sessions.remove(p.id)?.close() }

    fun guard(command: String): String? = Guard.check(command, core.app.filesDir.canonicalPath, core.app.packageName)

    fun env(root: File, cache: File): Map<String, String> = mapOf(
        "HOME" to root.path, "PWD" to root.path, "TMPDIR" to cache.path, "TERM" to "dumb",
        "PATH" to "/system/bin:/system/xbin:/vendor/bin:/product/bin:/apex/com.android.runtime/bin",
        "PAGER" to "cat", "GIT_PAGER" to "cat", "CI" to "1", "LANG" to "C.UTF-8", "KROW_PROJECT" to root.path,
    )

    @Synchronized
    fun startJob(p: Project, command: String): BgJob {
        val root = core.projectDir(p).canonicalFile
        val cache = File(core.app.cacheDir, "sh/${p.id}").also { it.mkdirs() }
        val pb = ProcessBuilder("/system/bin/sh", "-c", command).directory(root).redirectErrorStream(true)
        pb.environment().putAll(env(root, cache))
        val proc = pb.start()
        runCatching { proc.outputStream.close() }
        val id = "j" + (++jobSeq)
        val job = BgJob(id, p.id, command, proc)
        jobs[id] = job
        job.pump()
        return job
    }

    fun jobsFor(p: Project): List<BgJob> = jobs.values.filter { it.projectId == p.id }.sortedBy { it.started }

    fun stopAll() { jobs.values.forEach { it.kill() }; sessions.values.forEach { it.close() } }
}

// ---------------------------------------------------------------------------------------------------- guard
object Guard {
    private val rules: List<Pair<Regex, String>> = listOf(
        Regex("""(^|[;&|(`\s])(sudo|su|reboot|shutdown|poweroff|setenforce|insmod|rmmod|mkfs(\.\w+)?|fdisk|mount|umount|swapon|chroot)(\s|$)""") to "system-level commands (su, mount, reboot, …) are not available in the sandbox",
        Regex("""\bdd\b[^\n]*\bof=/(dev|proc|sys)""") to "writing to devices is blocked",
        Regex("""(^|[\s"'=<>])/(dev/block|dev/mem|proc/sys|sys/)""") to "raw device and kernel paths are blocked",
        Regex("""\b(pm|cmd\s+package)\s+(clear|uninstall|disable|suspend)""") to "changing installed apps is blocked",
        Regex("""shared_prefs|/no_backup|krow_secrets""") to "OrviX's stored secrets are off limits",
        Regex("""(^|[\s/"'])\.krow(/|\s|$|["'])""") to ".krow is reserved for OrviX's own git state",
        Regex("""\b(curl|wget)\b[^|;&\n]*\|\s*(sudo\s+)?(sh|bash|ash|ksh|zsh)\b""") to "piping a download straight into a shell is blocked; download it, read it, then run it",
        Regex("""\brm\s+(-\S+\s+)*(/|/\*|~|~/|~/\*|\$HOME|\$\{HOME\}|\.\.|\.\./\*|/(data|sdcard|storage|system|vendor|apex|proc|sys)(/\S*)?)(\s|$|;|&|\|)""") to "that would delete outside the project (use delete_path for project files)",
    )
    private val appData = Regex("""/data/(?:data|user/\d+|user_de/\d+)/([A-Za-z0-9_.]+)(/[^\s"'`;|&)]*)?""")

    /** Returns a human reason when the command must not run, else null. */
    fun check(command: String, filesDir: String, pkg: String): String? {
        for ((rx, why) in rules) if (rx.containsMatchIn(command)) return why
        for (m in appData.findAll(command)) {
            val owner = m.groupValues[1]
            val full = m.value
            if (owner != pkg) return "other apps' data is not reachable from the sandbox"
            if (!full.startsWith(filesDir + "/projects") && !full.contains("/cache")) return "app internals outside your projects are off limits"
        }
        return null
    }
}

// ---------------------------------------------------------------------------------------------------- output cleanup
object Out {
    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]|\u001B\\][^\u0007]*\u0007")

    /** Removes colour codes and collapses carriage-return progress bars to their final state. */
    fun clean(s: String): String {
        if (s.isEmpty()) return s
        val t = ansi.replace(s, "").replace("\r\n", "\n")
        if (!t.contains('\r')) return t
        return t.split('\n').joinToString("\n") { line -> if (line.contains('\r')) line.substringAfterLast('\r').ifEmpty { line.substringBeforeLast('\r').substringAfterLast('\r') } else line }
    }

    fun dur(ms: Long): String = when {
        ms < 1000 -> "${ms}ms"
        ms < 60_000 -> String.format("%.1fs", ms / 1000.0)
        else -> "${ms / 60000}m ${(ms / 1000) % 60}s"
    }

    /** Keeps the start and the end (where errors and results usually are) of long output. */
    fun headTail(s: String, max: Int, savedTo: String?): String {
        if (s.length <= max) return s
        val head = max * 2 / 5
        val tail = max - head
        val note = "\n… ${s.length - max} characters omitted" + (if (savedTo != null) " — full output saved to $savedTo (use sed -n 'A,Bp' / tail / grep on it)" else "") + " …\n"
        return s.take(head) + note + s.takeLast(tail)
    }
}

class ShellResult(val output: String, val code: Int, val ms: Long, val timedOut: Boolean, val cwd: String, val notes: List<String>)

// ---------------------------------------------------------------------------------------------------- persistent session
class ShellSession(private val root: File, private val cache: File) {
    private var proc: Process? = null
    private var stdin: java.io.OutputStream? = null
    private val buf = StringBuilder()
    private var dropped = 0L
    private var pid = -1
    private var seq = 0
    private val mutex = Mutex()
    @Volatile var cwd: File = root
        private set

    private fun alive() = proc?.isAlive == true

    private fun spawn(env: Map<String, String>) {
        close()
        cache.mkdirs()
        val rc = File(cache, "krowrc.sh")
        rc.writeText(RC)
        val pb = ProcessBuilder("/system/bin/sh").directory(root).redirectErrorStream(true)
        pb.environment().putAll(env)
        val p = pb.start()
        proc = p; stdin = p.outputStream
        synchronized(buf) { buf.setLength(0); dropped = 0 }
        Thread {
            runCatching {
                p.inputStream.bufferedReader().use { r ->
                    val c = CharArray(4096)
                    while (true) {
                        val n = r.read(c); if (n < 0) break
                        synchronized(buf) {
                            buf.append(c, 0, n)
                            if (buf.length > 8_000_000) { buf.delete(0, 4_000_000); dropped += 4_000_000 }
                        }
                    }
                }
            }
        }.also { it.isDaemon = true; it.start() }
        send(". '${rc.path}'\necho \"__KROW_READY__ \$\$\"\n")
        val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 4000) {
            val s = synchronized(buf) { buf.toString() }
            val i = s.indexOf("__KROW_READY__ ")
            if (i >= 0 && s.indexOf('\n', i) > 0) { pid = s.substring(i + 15, s.indexOf('\n', i)).trim().toIntOrNull() ?: -1; break }
            Thread.sleep(20)
        }
        synchronized(buf) { buf.setLength(0) }
        cwd = root
    }

    private fun send(text: String) {
        val o = stdin ?: throw java.io.IOException("shell is not running")
        o.write(text.toByteArray()); o.flush()
    }

    fun close() {
        proc?.let { p -> killTree(pid); runCatching { p.destroyForcibly() } }
        proc = null; stdin = null; pid = -1
    }

    /** Kills every process started by the shell (children, grandchildren) but not the shell itself. */
    private fun killChildren() {
        if (pid <= 0) return
        for (k in descendants(pid)) runCatching { AndroidProcess.killProcess(k) }
    }

    private fun killTree(rootPid: Int) {
        if (rootPid <= 0) return
        for (k in descendants(rootPid)) runCatching { AndroidProcess.killProcess(k) }
    }

    suspend fun run(
        command: String, stdinText: String?, timeoutSec: Int, env: Map<String, String>, reset: Boolean = false, onProgress: (String) -> Unit,
    ): ShellResult = mutex.withLock {
        val notes = ArrayList<String>()
        if (reset && alive()) { close(); notes += "session reset" }
        if (!alive()) { if (proc != null) notes += "the previous shell had exited; started a fresh one"; spawn(env) }
        val token = uid()
        val n = ++seq
        val script = File(cache, "c$n.sh").also { it.writeText(command + "\n") }
        val input = if (stdinText != null) File(cache, "i$n.txt").also { it.writeText(stdinText) } else null
        val marker = "__KROW_END_${token}__:"
        synchronized(buf) { buf.setLength(0); dropped = 0 }
        val t0 = System.currentTimeMillis()
        try {
            send(". '${script.path}' < ${input?.let { "'" + it.path + "'" } ?: "/dev/null"}\n__rc=\$?\nprintf '\\n$marker%s:%s\\n' \"\$__rc\" \"\$PWD\"\n")
        } catch (e: java.io.IOException) {
            spawn(env); notes += "shell restarted"
            send(". '${script.path}' < ${input?.let { "'" + it.path + "'" } ?: "/dev/null"}\n__rc=\$?\nprintf '\\n$marker%s:%s\\n' \"\$__rc\" \"\$PWD\"\n")
        }
        var timedOut = false
        var lastPush = 0L
        var finished = false
        var text = ""
        var code = 0
        var newCwd = ""
        try {
            while (true) {
                currentCoroutineContext().ensureActive()
                val snap = synchronized(buf) { buf.toString() }
                val i = snap.indexOf(marker)
                if (i >= 0 && snap.indexOf('\n', i) > 0) {
                    val rest = snap.substring(i + marker.length, snap.indexOf('\n', i))
                    code = rest.substringBefore(':').toIntOrNull() ?: 0
                    newCwd = rest.substringAfter(':', "")
                    text = snap.substring(0, i)
                    finished = true
                    break
                }
                if (!alive()) { // the command itself ended the shell (exit, crash, killed)
                    val c = runCatching { proc?.exitValue() }.getOrNull() ?: -1
                    text = snap; code = c; finished = true; notes += "the shell exited with code $c; the next command starts a fresh session"
                    proc = null
                    break
                }
                val now = System.currentTimeMillis()
                if (now - lastPush > 300) { lastPush = now; onProgress(Out.clean(snap).takeLast(6000)) }
                if (now - t0 > timeoutSec * 1000L) { timedOut = true; break }
                delay(40)
            }
        } finally {
            // A shell builtin (for example, an infinite while loop) has no child PID to kill.
            // Terminating the shell is the only reliable Stop behavior; the next call respawns it.
            if (!finished && !timedOut) close()
        }
        if (timedOut) {
            killChildren()
            // the shell then prints the end marker itself; read it so the session stays in sync
            val t1 = System.currentTimeMillis()
            var snap = ""
            while (System.currentTimeMillis() - t1 < 2500) {
                snap = synchronized(buf) { buf.toString() }
                val i = snap.indexOf(marker)
                if (i >= 0 && snap.indexOf('\n', i) > 0) { text = snap.substring(0, i); newCwd = snap.substring(i + marker.length, snap.indexOf('\n', i)).substringAfter(':', ""); finished = true; break }
                delay(40)
            }
            if (!finished) { text = snap; close(); notes += "the session did not recover and was restarted" }
            code = 124
        }
        script.delete(); input?.delete()
        var out = Out.clean(text).trimEnd('\n', ' ')
        if (dropped > 0) out = "[earlier output dropped: it was larger than the 8 MB buffer]\n$out"
        // keep the shell inside the project
        if (alive() && newCwd.isNotEmpty()) {
            val f = runCatching { File(newCwd).canonicalFile }.getOrNull()
            val inside = f != null && (f == root || f.path.startsWith(root.path + File.separator) || f.path.startsWith(cache.path))
            if (inside && f != null) cwd = f
            else { runCatching { send("cd '${root.path}'\n") }; cwd = root; notes += "cd outside the project was undone; the shell stays in the project folder" }
        }
        ShellResult(out, code, System.currentTimeMillis() - t0, timedOut, cwd.let { if (it == root) "." else it.relativeTo(root).path }, notes)
    }

    companion object {
        private val RC = """
ll() { ls -la "${'$'}@"; }
la() { ls -A "${'$'}@"; }
mkcd() { mkdir -p "${'$'}1" && cd "${'$'}1"; }
tree() { find "${'$'}{1:-.}" -not -path '*/.krow*' -not -path '*/.git/*' 2>/dev/null | sed -e 's|[^/]*/|  |g' | head -n "${'$'}{2:-300}"; }
count() { find "${'$'}{1:-.}" -type f -not -path '*/.krow/*' 2>/dev/null | wc -l; }
"""

        fun descendants(root: Int): List<Int> {
            val kids = HashMap<Int, MutableList<Int>>()
            File("/proc").listFiles()?.forEach { d ->
                val n = d.name.toIntOrNull() ?: return@forEach
                val st = runCatching { File(d, "stat").readText() }.getOrNull() ?: return@forEach
                val after = st.substringAfterLast(')').trim().split(' ')
                val pp = after.getOrNull(1)?.toIntOrNull() ?: return@forEach
                kids.getOrPut(pp) { ArrayList() }.add(n)
            }
            val out = ArrayList<Int>()
            val stack = ArrayDeque<Int>()
            stack.add(root)
            while (stack.isNotEmpty()) {
                val x = stack.removeLast()
                for (k in kids[x].orEmpty()) { out += k; stack.add(k) }
            }
            return out
        }
    }
}

// ---------------------------------------------------------------------------------------------------- background jobs
class BgJob(val id: String, val projectId: String, val command: String, private val proc: Process) {
    val started = System.currentTimeMillis()
    private val buf = StringBuilder()
    private var offset = 0L        // characters dropped from the front of buf
    private var cursor = 0L        // absolute position the AI has read up to
    private var pid = -1

    val running: Boolean get() = proc.isAlive
    val exit: Int? get() = if (proc.isAlive) null else runCatching { proc.exitValue() }.getOrNull()

    fun pump() {
        Thread {
            runCatching {
                proc.inputStream.bufferedReader().use { r ->
                    val c = CharArray(4096)
                    while (true) {
                        val n = r.read(c); if (n < 0) break
                        synchronized(buf) { buf.append(c, 0, n); if (buf.length > 1_000_000) { buf.delete(0, 500_000); offset += 500_000 } }
                    }
                }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    /** New output since the last read (or the last [tail] lines of everything when [all]). */
    fun read(all: Boolean, tail: Int): String {
        val (s, from) = synchronized(buf) { buf.toString() to offset }
        val start = if (all) 0 else (cursor - from).toInt().coerceIn(0, s.length)
        cursor = from + s.length
        val lines = Out.clean(s.substring(start)).trimEnd('\n').split('\n')
        val shown = if (lines.size > tail) listOf("… ${lines.size - tail} earlier lines not shown …") + lines.takeLast(tail) else lines
        return shown.joinToString("\n").ifBlank { "(no new output)" }
    }

    fun kill() {
        runCatching { proc.destroy() }
        runCatching { proc.destroyForcibly() }
    }

    fun age(): String = Out.dur(System.currentTimeMillis() - started)
}

// ---------------------------------------------------------------------------------------------------- tools
class RunCommand : Tool {
    override val spec = ToolSpec("run_command",
        "Run a shell command in the project's persistent Android shell (Android /system/bin/sh, starts in the project folder). This is not a kernel-enforced filesystem sandbox; use file tools for project-root-confined file access. " +
            "State persists between calls like a real terminal: cd, export and variables carry over. Output streams live; stdout and stderr are combined. " +
            "Only commands that exist on Android work (toybox: ls cat grep sed awk find tar gzip head tail sort uniq wc cut tr diff xargs, plus curl/wget/unzip if the device ships them; no git, python, node or package managers: use the git_* tools for git, and sandbox_info to see what exists). " +
            "Helpers: ll, la, tree [dir] [max], count [dir], mkcd. " +
            "Rules: never run interactive programs (they get no input; pass stdin instead), always use non-interactive flags, pipe noisy output through head/tail/grep, prefer the file tools for reading and editing files, and use background=true for anything that keeps running (servers, watchers, long builds) then read it with job_output. " +
            "Destructive or system-level commands (su, mount, rm -rf on / or ~, curl | sh, other apps' data) are blocked.",
        schema(listOf("command"),
            "command" to prop("string", "Shell command or small script (multi-line is fine)"),
            "timeout_seconds" to prop("integer", "Kill the command after this long. Default 120, max 900."),
            "stdin" to prop("string", "Text fed to the command's standard input"),
            "background" to prop("boolean", "Start it as a background job and return immediately with a job id"),
            "reset_session" to prop("boolean", "Restart the shell first (clears cd, exports and variables)")))
    override val kind = "terminal"
    override val mutating = true
    override fun title(a: JsonObject) = if (a.bool("background") == true) "Start background job" else "Run command"
    override fun cmd(a: JsonObject) = a.str("command") ?: ""
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val command = a.req("command")
        val sb = c.core.sandbox
        sb.guard(command)?.let { return ToolOut("Blocked: $it.", false, 126) }
        if (a.bool("background") == true) {
            val job = sb.startJob(c.project, command)
            delay(1500)
            val first = job.read(false, 40)
            val state = if (job.running) "running" else "already exited with code ${job.exit}"
            return ToolOut("Started job ${job.id} ($state).\n$first\n\nRead more with job_output(id=\"${job.id}\"), stop it with job_stop(id=\"${job.id}\").", job.exit == null || job.exit == 0, job.exit)
        }
        val timeout = (a.int("timeout_seconds") ?: 120).coerceIn(1, 900)
        val session = sb.session(c.project)
        val root = c.core.projectDir(c.project).canonicalFile
        val env = sb.env(root, File(c.core.app.cacheDir, "sh/${c.project.id}"))
        val r = session.run(command, a.str("stdin"), timeout, env, a.bool("reset_session") == true) { live -> c.progress(live) }
        val full = r.output
        var saved: String? = null
        if (full.length > 20_000) {
            val dir = File(c.core.app.cacheDir, "out").also { it.mkdirs() }
            dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(20)?.forEach { it.delete() }
            val f = File(dir, "out-${uid()}.txt"); f.writeText(full); saved = f.path
        }
        val body = Out.headTail(full, 20_000, saved)
        val foot = ArrayList<String>()
        if (r.timedOut) foot += "killed: timed out after ${timeout}s"
        else if (r.code != 0) foot += "exit code ${r.code}"
        if (r.cwd != ".") foot += "cwd: ${r.cwd}"
        foot += r.notes
        val text = (body.ifBlank { if (r.code == 0) "(no output)" else "" } + (if (foot.isEmpty()) "" else "\n[" + foot.joinToString(" · ") + "]")).trim()
        return ToolOut(text, r.code == 0, r.code)
    }
}

class JobOutput : Tool {
    override val spec = ToolSpec("job_output", "Read new output from a background job started with run_command(background=true), optionally waiting for more. Also lists all jobs when no id is given.",
        schema(emptyList(), "id" to prop("string", "Job id like j1. Omit to list jobs."),
            "wait_seconds" to prop("integer", "Wait up to this long (max 30) for new output or for the job to finish. Default 0."),
            "tail_lines" to prop("integer", "Show at most this many lines. Default 80."),
            "all" to prop("boolean", "Show the tail of the whole output instead of only what is new")))
    override val kind = "terminal"
    override fun title(a: JsonObject) = "Check job ${a.str("id") ?: ""}".trim()
    override fun cmd(a: JsonObject) = a.str("id") ?: ""
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val sb = c.core.sandbox
        val id = a.str("id")
        if (id.isNullOrBlank()) {
            val l = sb.jobsFor(c.project)
            if (l.isEmpty()) return ToolOut("No background jobs.")
            return ToolOut(l.joinToString("\n") { "${it.id}  ${if (it.running) "running" else "exited ${it.exit}"}  ${it.age()}  ${it.command.lineSequence().first().take(80)}" })
        }
        val job = sb.jobs[id]?.takeIf { it.projectId == c.project.id } ?: return ToolOut("No such job: $id", false)
        val wait = (a.int("wait_seconds") ?: 0).coerceIn(0, 30)
        var t = 0
        while (t < wait * 10 && job.running) { currentCoroutineContext().ensureActive(); delay(100); t++ }
        val text = job.read(a.bool("all") == true, (a.int("tail_lines") ?: 80).coerceIn(1, 400))
        val state = if (job.running) "[running · ${job.age()}]" else "[exited ${job.exit} · ${job.age()}]"
        return ToolOut(text + "\n" + state, job.exit == null || job.exit == 0, job.exit)
    }
}

class JobStop : Tool {
    override val spec = ToolSpec("job_stop", "Stop a background job.", schema(listOf("id"), "id" to prop("string", "Job id like j1")))
    override val kind = "terminal"
    override val mutating = true
    override fun title(a: JsonObject) = "Stop job ${a.str("id") ?: ""}".trim()
    override fun cmd(a: JsonObject) = a.str("id") ?: ""
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val job = c.core.sandbox.jobs[a.req("id")]?.takeIf { it.projectId == c.project.id } ?: return ToolOut("No such job.", false)
        val was = job.running
        job.kill()
        return ToolOut(if (was) "Stopped ${job.id}." else "${job.id} had already exited with code ${job.exit}.")
    }
}

class SandboxInfo : Tool {
    override val spec = ToolSpec("sandbox_info", "Show what the terminal sandbox can do on this phone: Android version, CPU, free space, the current folder, and which common commands exist. Call it before relying on a command you are unsure about.", schema(emptyList()))
    override val kind = "terminal"
    override fun title(a: JsonObject) = "Inspect sandbox"
    override suspend fun run(c: ToolCtx, a: JsonObject): ToolOut {
        val root = c.core.projectDir(c.project).canonicalFile
        val names = listOf("ls", "cat", "grep", "sed", "awk", "find", "xargs", "tar", "gzip", "unzip", "zip", "curl", "wget", "nc", "ping", "diff", "patch", "sort", "head", "tail", "jq", "python3", "node", "git", "busybox", "toybox", "ssh", "openssl", "sha256sum", "md5sum", "base64", "xxd", "od", "du", "df")
        val have = ArrayList<String>(); val miss = ArrayList<String>()
        val path = "/system/bin:/system/xbin:/vendor/bin:/product/bin"
        for (n in names) if (path.split(':').any { File(it, n).canExecute() }) have += n else miss += n
        val free = runCatching { humanSize(root.usableSpace) }.getOrDefault("?")
        val session = c.core.sandbox.session(c.project)
        val sb = StringBuilder()
        sb.append("Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT}), ${android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "?"}\n")
        sb.append("Shell: /system/bin/sh, persistent per project · folder: ${session.cwd.let { if (it == root) "." else it.relativeTo(root).path }}\n")
        sb.append("Free space: $free · jobs running: ${c.core.sandbox.jobsFor(c.project).count { it.running }}\n")
        sb.append("Available: ${have.joinToString(" ")}\n")
        sb.append("Missing: ${miss.joinToString(" ")}")
        return ToolOut(sb.toString())
    }
}
