package com.krow.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.ui.composed
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import com.krow.Haptics
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun T(
    text: String, size: Int = 14, color: Color = LocalPal.current.ink, weight: FontWeight = FontWeight.Normal,
    family: FontFamily = Sans, maxLines: Int = Int.MAX_VALUE, modifier: Modifier = Modifier, italic: Boolean = false, lh: Float = 1.45f, ls: Float = 0f,
) = Text(
    text, modifier, color = color, fontSize = size.sp, fontWeight = weight, fontFamily = family, maxLines = maxLines, letterSpacing = ls.sp,
    overflow = TextOverflow.Ellipsis, fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal, lineHeight = (size * lh).sp,
)

@Composable
fun Ic(v: ImageVector, size: Int = 16, tint: Color = LocalPal.current.muted, modifier: Modifier = Modifier) =
    Icon(v, null, modifier.size(size.dp), tint = tint)

@Composable
fun Mark(size: Int = 28) = OrviXTile(size.dp)

@Composable
fun IconBtn(
    v: ImageVector, desc: String = "", size: Int = 36, tint: Color = LocalPal.current.muted,
    filled: Boolean = false, onClick: () -> Unit,
) {
    val p = LocalPal.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .88f else 1f, krowSpring(), label = "iconBtn")
    Box(
        Modifier
            .size(size.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(if (filled) p.accent else if (pressed) p.accentSoft else Color.Transparent)
            .clickable(interactionSource = src, indication = null, onClick = { Haptics.tap(); onClick() }),
        Alignment.Center,
    ) { Ic(v, (size * .5f).toInt().coerceAtLeast(18), if (filled) p.accentInk else tint) }
}

/** Press-to-shrink + a tick of haptics: the touch feel used by every row, chip and card. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pressable(onLongClick: (() -> Unit)? = null, haptic: Boolean = true, onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, krowSpring(), label = "press")
    this.scale(scale).combinedClickable(
        interactionSource = src, indication = null,
        onLongClick = onLongClick?.let { l -> { Haptics.longPress(); l() } },
        onClick = { if (haptic) Haptics.tap(); onClick() },
    )
}

@Composable
fun Pill(
    label: String, modifier: Modifier = Modifier, icon: ImageVector? = null, selected: Boolean = false, filled: Boolean = false,
    mono: Boolean = false, small: Boolean = false, color: Color? = null, onClick: (() -> Unit)? = null,
) {
    val p = LocalPal.current
    val bg = when { filled -> p.accent; selected -> p.accentSoft; else -> p.raised }
    val fg = color ?: when { filled -> p.accentInk; selected -> p.accent; else -> p.ink }
    Row(
        modifier
            .clip(CircleShape)
            .background(bg)
            .then(if (onClick != null) Modifier.pressable(onClick = onClick) else Modifier)
            .padding(horizontal = if (small) 11.dp else 16.dp, vertical = if (small) 5.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (icon != null) Ic(icon, 14, fg)
        T(label, if (small) 12 else 14, fg, FontWeight.Medium, if (mono) Mono else Sans, maxLines = 1)
    }
}

/** Soft elevated surface — warm shadow only, never glow. */
@Composable
fun SoftCard(modifier: Modifier = Modifier, elevation: Dp = 6.dp, radius: Dp = 22.dp, borderColor: Color? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(radius)
    Column(
        modifier
            .shadow(elevation, shape, clip = false, ambientColor = p.shadow, spotColor = p.shadow)
            .clip(shape)
            .background(p.surface)
            .border(1.dp, borderColor ?: p.line, shape),
        content = content,
    )
}

fun kindIcon(kind: String): ImageVector = when (kind) {
    "search" -> Icons.Outlined.Search
    "memory" -> Icons.Outlined.Bookmark
    "link" -> Icons.Outlined.Link
    "file" -> Icons.Outlined.Description
    "edit" -> Icons.Outlined.Edit
    "folder" -> Icons.Outlined.Folder
    "zip" -> Icons.Outlined.Archive
    "git" -> Icons.Outlined.AccountTree
    "actions" -> Icons.Outlined.PlayArrow
    "artifact" -> Icons.Outlined.Inventory2
    "think" -> Icons.Outlined.Lightbulb
    "plan" -> Icons.Outlined.FormatListBulleted
    else -> Icons.Outlined.Terminal
}

fun modeLabel(mode: String) = when (mode) {
    "auto" -> "Auto-run"
    "read" -> "Read only"
    else -> "Ask first"
}

fun modeIcon(mode: String) = when (mode) {
    "auto" -> Icons.Outlined.Bolt
    "read" -> Icons.Outlined.Visibility
    else -> Icons.Outlined.Shield
}

fun modeHint(mode: String) = when (mode) {
    "auto" -> "Run tools without asking"
    "read" -> "Search and read only"
    else -> "Approve each change"
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, placeholder: String = "", modifier: Modifier = Modifier,
    mono: Boolean = false, password: Boolean = false, singleLine: Boolean = true,
) {
    val p = LocalPal.current
    BasicTextField(
        value, onChange,
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.sunk).padding(horizontal = 14.dp, vertical = 12.dp),
        textStyle = TextStyle(color = p.ink, fontSize = 15.sp, fontFamily = if (mono) Mono else Sans),
        cursorBrush = SolidColor(p.accent), singleLine = singleLine,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, keyboardType = if (password) KeyboardType.Password else KeyboardType.Text),
        decorationBox = { inner -> Box { if (value.isEmpty()) T(placeholder, 15, p.faint, family = if (mono) Mono else Sans); inner() } },
    )
}

@Composable
fun TextDialog(title: String, initial: String, hint: String, confirm: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    val p = LocalPal.current
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = p.raised, shape = RoundedCornerShape(28.dp),
        title = { T(title, 17, weight = FontWeight.SemiBold) },
        text = { Field(v, { v = it }, hint) },
        confirmButton = { Pill(confirm, filled = true, onClick = { onOk(v) }) },
        dismissButton = { Pill("Cancel", onClick = onDismiss) },
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirm: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    val p = LocalPal.current
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = p.raised, shape = RoundedCornerShape(28.dp),
        title = { T(title, 17, weight = FontWeight.SemiBold) },
        text = { T(body, 14, p.muted) },
        confirmButton = { Pill(confirm, filled = true, onClick = onOk) },
        dismissButton = { Pill("Cancel", onClick = onDismiss) },
    )
}

@Composable
fun HLine() { Box(Modifier.fillMaxWidth().height(1.dp).background(LocalPal.current.line)) }

@Composable
fun ThreadBreak(label: String) {
    val p = LocalPal.current
    if (label.isBlank()) {
        Box(Modifier.fillMaxWidth().padding(vertical = 10.dp).height(1.dp).background(p.line))
        return
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.weight(1f).height(1.dp).background(p.line))
        T(label, 11, p.faint, FontWeight.Medium, Mono)
        Box(Modifier.weight(1f).height(1.dp).background(p.line))
    }
}


// ------------------------------------------------------------------ Apple-style building blocks

/** Detent feel for any scrolling list: a soft tick every ~72dp, sharper on a flick, a bump at the ends. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.hapticScroll(stepDp: Float = 72f): Modifier = composed {
    val step = with(LocalDensity.current) { stepDp.dp.toPx() }
    val conn = remember(step) {
        object : NestedScrollConnection {
            var acc = 0f
            var last = System.currentTimeMillis()
            var bumped = false
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                val c = kotlin.math.abs(consumed.y)
                acc += c
                if (acc >= step) {
                    val now = System.currentTimeMillis()
                    Haptics.scrollTick(acc / kotlin.math.max(1L, now - last))
                    last = now
                    acc %= step
                }
                if (c > 0f) bumped = false
                else if (!bumped && kotlin.math.abs(available.y) > 0f) { bumped = true; Haptics.edge() }
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity { acc = 0f; bumped = false; return Velocity.Zero }
        }
    }
    this.nestedScroll(conn)
}

/** iOS-style switch. */
@Composable
fun KSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    val x by animateFloatAsState(if (checked) 1f else 0f, krowSpring(), label = "sw")
    val track = androidx.compose.ui.graphics.lerp(if (p.dark) Color(0xFF3A3A3A) else Color(0xFFD1D0CA), p.accent, x)
    Box(
        Modifier.size(width = 51.dp, height = 31.dp).clip(CircleShape).background(track)
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { Haptics.toggle(!checked); onChange(!checked) }
            .padding(2.dp),
    ) {
        Box(Modifier.offset(x = (20.dp * x)).size(27.dp).shadow(2.dp, CircleShape).clip(CircleShape).background(Color.White))
    }
}

/** iOS-style segmented control. */
@Composable
fun Segmented(options: List<Pair<String, String>>, selected: String, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    val p = LocalPal.current
    Row(modifier.clip(RoundedCornerShape(12.dp)).background(p.sunk).padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        options.forEach { (k, label) ->
            val on = k == selected
            val bg by androidx.compose.animation.animateColorAsState(if (on) p.raised else Color.Transparent, label = "seg")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(bg)
                    .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { if (!on) { Haptics.select(); onSelect(k) } }
                    .padding(vertical = 8.dp),
                Alignment.Center,
            ) { T(label, 13, if (on) p.ink else p.muted, if (on) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1) }
        }
    }
}

/** Inset grouped list, as in iOS Settings: a rounded card of rows separated by hairlines. */
@Composable
fun Group(title: String? = null, footer: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth()) {
        if (title != null) T(title.uppercase(), 12, p.faint, FontWeight.Medium, modifier = Modifier.padding(start = 16.dp, bottom = 7.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.surface), content = content)
        if (footer != null) T(footer, 12, p.faint, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 7.dp), lh = 1.4f)
    }
}

/** One row of a [Group]. */
@Composable
fun GRow(
    title: String, value: String? = null, icon: ImageVector? = null, subtitle: String? = null, danger: Boolean = false,
    chevron: Boolean = false, last: Boolean = false, trailing: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null,
) {
    val p = LocalPal.current
    Column {
        Row(
            Modifier.fillMaxWidth().then(if (onClick != null) Modifier.pressable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (icon != null) Box(Modifier.size(30.dp).clip(RoundedCornerShape(9.dp)).background(if (danger) p.badBg else p.accentSoft), Alignment.Center) { Ic(icon, 17, if (danger) p.bad else p.accent) }
            Column(Modifier.weight(1f)) {
                T(title, 16, if (danger) p.bad else p.ink, maxLines = 1)
                if (subtitle != null) T(subtitle, 12, p.faint, maxLines = 2)
            }
            if (value != null) T(value, 15, p.faint, maxLines = 1, modifier = Modifier.widthIn(max = 150.dp))
            trailing?.invoke()
            if (chevron) Ic(Icons.Outlined.ChevronRight, 20, p.faint)
        }
        if (!last) Box(Modifier.padding(start = if (icon != null) 60.dp else 16.dp).fillMaxWidth().height(.5.dp).background(p.line))
    }
}

/** Large title used at the top of full screens. */
@Composable
fun LargeTitle(title: String, onBack: (() -> Unit)? = null) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp)) {
        if (onBack != null) IconBtn(Icons.Outlined.ArrowBack, "Back", 44, p.ink, onClick = onBack)
        else Spacer(Modifier.height(10.dp))
        T(title, 32, p.ink, FontWeight.Bold, modifier = Modifier.padding(start = 12.dp, top = 2.dp), lh = 1.15f)
    }
}
