package app.notube.ui.screens.shorts

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.text.style.TextAlign
import app.notube.ui.components.bounceClick
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.WatchLater
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.data.remote.Purpose
import app.notube.data.repository.VideoRepository
import app.notube.domain.StreamInfo
import app.notube.domain.VideoItem
import app.notube.ui.components.ShortsRailButton
import app.notube.ui.components.StateScaffold
import app.notube.ui.components.YpIconTap
import app.notube.ui.player.VideoPlayer
import app.notube.ui.theme.NoTubeBlack
import app.notube.ui.theme.NoTubeRed
import coil.compose.AsyncImage
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@EntryPoint
@InstallIn(SingletonComponent::class)
interface ShortsRepoEntryPoint {
    fun videoRepository(): VideoRepository
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShortsScreen(
    onOpenComments: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    viewModel: ShortsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    StateScaffold(state = state, onRetry = viewModel::refresh, modifier = Modifier.fillMaxSize()) { shorts ->
        if (shorts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No Shorts available right now", color = Color.White)
            }
            return@StateScaffold
        }
        val pagerState = rememberPagerState(pageCount = { shorts.size })
        LaunchedEffect(pagerState.currentPage, shorts.size) { viewModel.onPage(pagerState.currentPage) }
        Box(Modifier.fillMaxSize().background(NoTubeBlack)) {
            VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                val item = shorts[page]
                ShortPage(
                    videoId = item.id,
                    title = item.title,
                    channelName = item.channelName,
                    channelId = item.channelId,
                    thumb = item.thumbnailUrl,
                    active = pagerState.currentPage == page,
                    onOpenComments = { onOpenComments(item.id) },
                )
            }
            if (onBack != null) {
                YpIconTap(
                    Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack,
                    modifier = Modifier.align(Alignment.TopStart).statusBarsPadding().padding(top = 6.dp, start = 8.dp)
                        .background(Color.Black.copy(0.4f), CircleShape),
                )
            }
        }
    }
}

@Composable
private fun ShortPage(
    videoId: String,
    title: String,
    channelName: String,
    channelId: String?,
    thumb: String?,
    active: Boolean,
    onOpenComments: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var stream by remember(videoId) { mutableStateOf<StreamInfo?>(null) }
    var error by remember(videoId) { mutableStateOf<String?>(null) }
    var liked by remember(videoId) { mutableStateOf(false) }
    var disliked by remember(videoId) { mutableStateOf(false) }
    var subscribed by remember(videoId) { mutableStateOf(false) }
    var menu by remember(videoId) { mutableStateOf(false) }
    var reloads by remember(videoId) { mutableStateOf(0) }
    var forceFresh by remember(videoId) { mutableStateOf(false) }

    LaunchedEffect(videoId, active, reloads) {
        if (!active || stream != null) return@LaunchedEffect
        val repo = repoOf(context)
        val fresh = forceFresh
        runCatching {
            withContext(Dispatchers.IO) {
                if (fresh) repo.stream(videoId, 720, record = false, fresh = true, purpose = Purpose.SHORTS)
                else runCatching { repo.stream(videoId, 720, purpose = Purpose.SHORTS) }
                    .recoverCatching { repo.stream(videoId, 720, fresh = true, purpose = Purpose.SHORTS) }
                    .getOrThrow()
            }
        }.onSuccess { stream = it }.onFailure { error = it.message ?: "Playback failed" }
    }

    Box(Modifier.fillMaxSize()) {
        when {
            stream != null && active -> VideoPlayer(
                stream = stream!!, modifier = Modifier.fillMaxSize(),
                playWhenReady = true, resizeModeFill = true,
                onError = {
                    // Expired / rejected URL: resolve a fresh one once, then let the user retry.
                    if (reloads < 1) { forceFresh = true; stream = null; reloads += 1 } else error = it
                },
            )
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error ?: "Error", color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Tap to retry", color = NoTubeRed, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable {
                            error = null; stream = null; forceFresh = true; reloads += 1
                        },
                    )
                }
            }
            else -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                AsyncImage(
                    model = thumb ?: "https://i.ytimg.com/vi/$videoId/hq720.jpg",
                    contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)))
                Text("Loading…", color = Color.White.copy(0.85f))
            }
        }

        // Long-press anywhere on the video -> 3-dots menu (Share, Copy link, Save to Watch later).
        // Drags are not consumed, so vertical swiping between Shorts still works.
        // It sits above the video but below the gradient / meta / rail, so Subscribe and the rail stay tappable.
        if (error == null) {
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(videoId) { detectTapGestures(onLongPress = { menu = true }) },
            )
        }

        Box(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().height(280.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.88f)))),
        )

        // Meta (YouTube Shorts left stack)
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 12.dp, end = 56.dp, bottom = 18.dp),
        ) {
            val name = stream?.channelName?.takeIf { it.isNotBlank() } ?: channelName
            if (name.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("@${name.replace(" ", "")}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShapeCompat)
                            .background(if (subscribed) Color(0xFF3F3F3F) else Color.White)
                            .clickable {
                                val st = stream ?: return@clickable
                                val cid = st.channelId ?: channelId ?: return@clickable
                                scope.launch {
                                    val (on, r) = repoOf(context).toggleSubscribe(
                                        app.notube.domain.ChannelItem(cid, st.channelName.ifBlank { name }),
                                    )
                                    subscribed = on
                                    android.widget.Toast.makeText(context, r.describe(if (on) "Subscribed" else "Unsubscribed"), android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                    ) {
                        Text(
                            if (subscribed) "Subscribed" else "Subscribe",
                            color = if (subscribed) Color.White else Color.Black,
                            fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            Text(title, color = Color.White, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
        }

        // Right action rail: plain icons, tight spacing, sound disc at the bottom
        Column(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 2.dp, bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            RailIcon(
                if (liked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                if (liked) "Liked" else "Like",
                tint = if (liked) NoTubeRed else Color.White,
            ) {
                scope.launch {
                    stream?.let { st ->
                        val (on, r) = repoOf(context).toggleLike(
                            VideoItem(st.videoId, st.title, st.channelName, st.channelId, st.thumbnailUrl),
                        )
                        liked = on; if (on) disliked = false
                        android.widget.Toast.makeText(context, r.describe(if (on) "Liked" else "Like removed"), android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
            RailIcon(
                if (disliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                "Dislike",
                tint = if (disliked) NoTubeRed else Color.White,
            ) {
                scope.launch {
                    stream?.let { st ->
                        val (on, r) = repoOf(context).toggleDislike(st.videoId)
                        disliked = on; if (on) liked = false
                        android.widget.Toast.makeText(context, r.describe(if (on) "Disliked" else "Dislike removed"), android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
            RailIcon(Icons.Outlined.ChatBubbleOutline, "Comments", onClick = onOpenComments)
            Spacer(Modifier.height(6.dp))
            ChannelDisc(stream?.thumbnailUrl ?: thumb, name = stream?.channelName ?: channelName, spinning = active && stream != null)
        }

        if (menu) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(0.55f))
                    .pointerInput(Unit) { detectTapGestures { menu = false } },
            ) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .background(Color(0xFF212121))
                        .pointerInput(Unit) { detectTapGestures { } }
                        .padding(vertical = 8.dp),
                ) {
                    MenuRow(Icons.Outlined.Share, "Share") {
                        menu = false
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(android.content.Intent.EXTRA_TEXT, "https://youtube.com/shorts/$videoId")
                        context.startActivity(android.content.Intent.createChooser(send, "Share"))
                    }
                    MenuRow(Icons.Outlined.Link, "Copy link") {
                        menu = false
                        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("Short", "https://youtube.com/shorts/$videoId"))
                        android.widget.Toast.makeText(context, "Link copied", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    MenuRow(Icons.Outlined.WatchLater, "Save to Watch later") {
                        menu = false
                        scope.launch {
                            val r = repoOf(context).saveToWatchLater(videoId)
                            android.widget.Toast.makeText(context, r.describe("Saved to Watch later"), android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RailIcon(icon: ImageVector, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Column(
        Modifier.bounceClick(pressed = 0.88f, onClick = onClick).padding(horizontal = 4.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(rememberVectorPainter(icon), label, Modifier.size(22.dp), colorFilter = ColorFilter.tint(tint))
        Text(label, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(rememberVectorPainter(icon), label, Modifier.size(24.dp), colorFilter = ColorFilter.tint(Color.White))
        Spacer(Modifier.width(16.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}

private val RoundedCornerShapeCompat = androidx.compose.foundation.shape.RoundedCornerShape(4.dp)

@Composable
private fun ChannelDisc(url: String?, name: String, spinning: Boolean) {
    val spin by rememberInfiniteTransition(label = "disc").animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "r",
    )
    Box(
        Modifier
            .size(32.dp)
            .rotate(if (spinning) spin else 0f)
            .border(1.5.dp, Color.White, CircleShape)
            .clip(CircleShape)
            .background(Color(0xFF222222)),
        contentAlignment = Alignment.Center,
    ) {
        if (!url.isNullOrBlank()) {
            AsyncImage(url, name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(name.firstOrNull()?.uppercase() ?: "·", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

private fun repoOf(context: android.content.Context): VideoRepository =
    EntryPointAccessors.fromApplication(context.applicationContext, ShortsRepoEntryPoint::class.java).videoRepository()
