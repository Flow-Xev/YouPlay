package app.youplay.ui.theme

import androidx.compose.ui.graphics.Color

val YouPlayRedDim = Color(0xFFB20710)
val YouPlayBlack = Color(0xFF0A0A0A)
val YouPlaySurface = Color(0xFF141414)
val YouPlaySurfaceElevated = Color(0xFF1C1C1C)
val YouPlayOutline = Color(0xFF2A2A2A)
val YouPlayOnDark = Color(0xFFF5F5F5)
val YouPlayMuted = Color(0xFFA3A3A3)
val YouPlayAccentSoft = Color(0x33E50914)
