package app.youplay.ui.screens.shorts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.youplay.data.repository.VideoRepository
import app.youplay.domain.UiState
import app.youplay.domain.VideoItem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class ShortsViewModel @Inject constructor(
    savedStateHandle: androidx.lifecycle.SavedStateHandle,
    private val repository: VideoRepository,
) : ViewModel() {
    private val _state = MutableStateFlow<UiState<List<VideoItem>>>(UiState.Loading)
    val state: StateFlow<UiState<List<VideoItem>>> = _state.asStateFlow()

    private val startId: String? = savedStateHandle["videoId"]
    private var next: String? = null
    private var loadingMore = false
    private var exhausted = false

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            exhausted = false
            _state.value = runCatching {
                val page = repository.shortsFeed()
                next = page.next
                if (startId == null) UiState.Success(page.videos)
                else {
                    val q = repository.shortsQueue()
                    val head = q.dropWhile { it.id != startId }.ifEmpty { listOf(VideoItem(startId, "Short", isShort = true)) }
                    UiState.Success((head + page.videos).distinctBy { it.id })
                }
            }.getOrElse { UiState.Error(it.message ?: "Failed to load Shorts", it) }
        }
    }

    /** Called as the user swipes: keeps the feed endless and warms the streams of the next Shorts. */
    fun onPage(index: Int) {
        val list = (_state.value as? UiState.Success)?.data ?: return
        if (index >= list.size - 4) loadMore()
        list.drop(index + 1).take(2).forEach { v ->
            viewModelScope.launch { runCatching { repository.stream(v.id, 720, record = false, purpose = app.youplay.data.remote.Purpose.SHORTS) } }
        }
    }

    private fun loadMore() {
        if (loadingMore || exhausted) return
        loadingMore = true
        viewModelScope.launch {
            runCatching {
                // continuation while there is one; afterwards a fresh recommendation batch from the account
                val page = repository.shortsFeed(next)
                next = page.next
                val cur = (_state.value as? UiState.Success)?.data ?: return@runCatching
                val merged = (cur + page.videos).distinctBy { it.id }
                if (merged.size == cur.size && next == null) exhausted = true
                else _state.value = UiState.Success(merged)
            }
            loadingMore = false
        }
    }
}
