package app.youplay.data.auth

import app.youplay.data.local.RawSession
import app.youplay.data.local.SessionStore
import app.youplay.domain.AccountState
import app.youplay.util.JsonWalk
import com.metrolist.innertubex.InnerTube
import com.metrolist.innertubex.models.YouTubeClient
import io.ktor.client.statement.bodyAsText
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/** Owns the signed-in YouTube session and applies it to the shared [InnerTube] client. */
@Singleton
class AuthManager @Inject constructor(
    private val store: SessionStore,
    private val innerTube: InnerTube,
) {
    val account: Flow<AccountState> = store.account
    private var applied = false

    suspend fun isSignedIn(): Boolean = store.account.first().signedIn

    /** Call before any network request so a saved login is active after app restart. */
    suspend fun ensure() {
        if (applied) return
        store.raw()?.let(::apply)
        applied = true
    }

    private fun apply(r: RawSession) =
        innerTube.replaceSession(r.cookie, r.visitorData, r.dataSyncId?.substringBefore("||"), "0", true)

    suspend fun signIn(cookie: String, visitorData: String?, dataSyncId: String?) {
        val raw = RawSession(cookie, visitorData, dataSyncId)
        store.save(raw)
        apply(raw)
        applied = true
        refreshProfile()
    }

    suspend fun refreshProfile() {
        runCatching {
            val text = innerTube.accountMenu(YouTubeClient.WEB).bodyAsText()
            JsonWalk.profile(JsonWalk.parseObject(text))?.let { store.saveProfile(it) }
        }
    }

    suspend fun signOut() {
        store.clear()
        innerTube.replaceSession(null, null, null, "0", false)
        applied = true
    }
}
