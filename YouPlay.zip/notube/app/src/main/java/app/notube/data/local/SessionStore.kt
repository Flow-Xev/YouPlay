package app.notube.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.notube.domain.AccountState
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.authStore: DataStore<Preferences> by preferencesDataStore("notube_auth")

data class RawSession(val cookie: String, val visitorData: String?, val dataSyncId: String?)

/** Persists the YouTube login session (cookie + ids) and the cached profile. */
@Singleton
class SessionStore @Inject constructor(@ApplicationContext private val context: Context) {
    private object K {
        val cookie = stringPreferencesKey("cookie")
        val visitor = stringPreferencesKey("visitor_data")
        val sync = stringPreferencesKey("data_sync_id")
        val name = stringPreferencesKey("name")
        val email = stringPreferencesKey("email")
        val handle = stringPreferencesKey("handle")
        val avatar = stringPreferencesKey("avatar")
    }

    val account: Flow<AccountState> = context.authStore.data.map {
        AccountState(
            signedIn = !it[K.cookie].isNullOrBlank(),
            name = it[K.name], email = it[K.email], handle = it[K.handle], avatarUrl = it[K.avatar],
        )
    }

    suspend fun raw(): RawSession? {
        val p = context.authStore.data.first()
        val c = p[K.cookie]?.takeIf { it.isNotBlank() } ?: return null
        return RawSession(c, p[K.visitor], p[K.sync])
    }

    suspend fun save(raw: RawSession) = context.authStore.edit {
        it[K.cookie] = raw.cookie
        raw.visitorData?.let { v -> it[K.visitor] = v }
        raw.dataSyncId?.let { v -> it[K.sync] = v }
    }

    suspend fun saveProfile(a: AccountState) = context.authStore.edit {
        a.name?.let { v -> it[K.name] = v }
        a.email?.let { v -> it[K.email] = v }
        a.handle?.let { v -> it[K.handle] = v }
        a.avatarUrl?.let { v -> it[K.avatar] = v }
    }

    suspend fun clear() = context.authStore.edit { it.clear() }
}
