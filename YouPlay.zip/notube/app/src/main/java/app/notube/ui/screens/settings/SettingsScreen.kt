package app.notube.ui.screens.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.ui.theme.AccentTheme
import app.notube.ui.theme.NoTubeRed

private val Qualities = listOf("auto" to "Auto (best up to 1080p)", "1080" to "1080p", "720" to "720p", "480" to "480p", "360" to "360p", "144" to "144p")
private val DlQualities = listOf("1080" to "1080p", "720" to "720p", "480" to "480p", "360" to "360p")
private val AutoMaxOpts = listOf("2160" to "4K (2160p)", "1440" to "1440p", "1080" to "1080p", "720" to "720p")
private val MobileOpts = listOf("1080" to "1080p", "720" to "720p (recommended)", "480" to "480p", "360" to "360p")
private val Speeds = listOf("0.5" to "0.5x", "0.75" to "0.75x", "1.0" to "Normal", "1.25" to "1.25x", "1.5" to "1.5x", "2.0" to "2x")
private val Regions = listOf("US" to "United States", "IN" to "India", "GB" to "United Kingdom", "CA" to "Canada", "AU" to "Australia", "DE" to "Germany", "FR" to "France", "JP" to "Japan", "KR" to "South Korea", "BR" to "Brazil", "MX" to "Mexico", "ID" to "Indonesia")
private val Languages = listOf("en" to "English", "hi" to "हिन्दी", "es" to "Español", "fr" to "Français", "de" to "Deutsch", "pt" to "Português", "ja" to "日本語", "ko" to "한국어", "id" to "Bahasa Indonesia")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenDownloads: () -> Unit = {},
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val s by viewModel.settings.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var picker by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); viewModel.messageShown() } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            // ---------------- Appearance ----------------
            Header("Appearance")
            Text("Theme", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 16.dp))
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AccentTheme.entries.forEach { t ->
                    ThemeCard(t, selected = s.accent == t.id, amoled = s.amoled, modifier = Modifier.weight(1f)) {
                        viewModel.update { it.copy(accent = t.id) }
                    }
                }
            }
            Text("Mode", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 16.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(16.dp)) {
                SegmentedButton(
                    selected = !s.amoled, onClick = { viewModel.update { it.copy(amoled = false) } },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                ) { Text("Dark") }
                SegmentedButton(
                    selected = s.amoled, onClick = { viewModel.update { it.copy(amoled = true) } },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                ) { Text("AMOLED") }
            }
            Text(
                if (s.amoled) "AMOLED: pure black backgrounds, saves battery on OLED screens." else "Dark: soft dark surfaces tinted to your theme.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            SwitchRow("Show Shorts on Home", "Hide the Shorts shelf in your feed", s.showShorts) { v -> viewModel.update { it.copy(showShorts = v) } }

            // ---------------- Playback ----------------
            Header("Playback")
            SwitchRow("Autoplay next video", "Play the first Up next video when one ends", s.autoplay) { v -> viewModel.update { it.copy(autoplay = v) } }
            SwitchRow("Background play", "Keep audio playing when you leave the app", s.backgroundPlay) { v -> viewModel.update { it.copy(backgroundPlay = v) } }
            SwitchRow("SponsorBlock", "Auto-skip sponsors, intros, outros and self-promo", s.sponsorBlock) { v -> viewModel.update { it.copy(sponsorBlock = v) } }
            SwitchRow("Return YouTube Dislike", "Show estimated dislike counts", s.returnDislike) { v -> viewModel.update { it.copy(returnDislike = v) } }
            SwitchRow("Picture-in-picture", "Keep the video in a small window when you leave the app", s.autoPip) { v -> viewModel.update { it.copy(autoPip = v) } }
            ValueRow("Auto quality: maximum", AutoMaxOpts.labelFor(s.autoMax.toString())) { picker = "automax" }
            ValueRow("Auto quality on mobile data", MobileOpts.labelFor(s.mobileCap.toString())) { picker = "mobilecap" }
            SwitchRow("Preload next video", "Get the next video ready early (media is cached on Wi-Fi only)", s.preloadNext) { v -> viewModel.update { it.copy(preloadNext = v) } }
            ValueRow("Default quality", Qualities.labelFor(s.preferredQuality)) { picker = "quality" }
            ValueRow("Default speed", Speeds.labelFor(s.defaultSpeed.toString())) { picker = "speed" }

            // ---------------- Downloads ----------------
            Header("Downloads")
            ValueRow("Download quality", DlQualities.labelFor(s.downloadQuality.toString())) { picker = "dlq" }
            SwitchRow("Wi-Fi only", "Don't download on mobile data", s.wifiOnlyDownloads) { v -> viewModel.update { it.copy(wifiOnlyDownloads = v) } }
            ValueRow("Manage downloads", null, onOpenDownloads)

            // ---------------- Content ----------------
            Header("Content")
            ValueRow("Region", Regions.labelFor(s.regionCode)) { picker = "region" }
            ValueRow("Language", Languages.labelFor(s.language)) { picker = "language" }
            SwitchRow("Restricted mode", "Hide potentially mature content", s.restrictedMode) { v -> viewModel.update { it.copy(restrictedMode = v) } }

            // ---------------- Storage ----------------
            Header("Storage & cache")
            val cacheSize by viewModel.cacheSize.collectAsStateWithLifecycle()
            ValueRow("Clear cache", app.notube.data.cache.formatBytes(cacheSize)) { viewModel.clearCache() }
            ListItem(
                headlineContent = { Text("Auto-clean") },
                supportingContent = { Text("Every 6 hours: removes cached data older than 6 hours, and frees media and images when the phone is low on space") },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            )

            // ---------------- Privacy ----------------
            Header("History & privacy")
            ValueRow("Clear watch history", null) { viewModel.clearWatchHistory() }
            ValueRow("Clear search history", null) { viewModel.clearSearchHistory() }

            // ---------------- About ----------------
            Header("About")
            ListItem(
                headlineContent = { Text("YouPlay") },
                supportingContent = { Text("Native Kotlin · Jetpack Compose · InnerTubeX · Media3") },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            )
        }
    }

    when (picker) {
        "quality" -> Picker("Default quality", Qualities, s.preferredQuality, { picker = null }) { v -> viewModel.update { it.copy(preferredQuality = v) } }
        "automax" -> Picker("Auto quality: maximum", AutoMaxOpts, s.autoMax.toString(), { picker = null }) { v -> viewModel.update { it.copy(autoMax = v.toInt()) } }
        "mobilecap" -> Picker("Auto quality on mobile data", MobileOpts, s.mobileCap.toString(), { picker = null }) { v -> viewModel.update { it.copy(mobileCap = v.toInt()) } }
        "speed" -> Picker("Default speed", Speeds, s.defaultSpeed.toString(), { picker = null }) { v -> viewModel.update { it.copy(defaultSpeed = v.toFloat()) } }
        "dlq" -> Picker("Download quality", DlQualities, s.downloadQuality.toString(), { picker = null }) { v -> viewModel.update { it.copy(downloadQuality = v.toInt()) } }
        "region" -> Picker("Region", Regions, s.regionCode, { picker = null }) { v -> viewModel.update { it.copy(regionCode = v) } }
        "language" -> Picker("Language", Languages, s.language, { picker = null }) { v -> viewModel.update { it.copy(language = v) } }
    }
}

private fun List<Pair<String, String>>.labelFor(key: String) = firstOrNull { it.first == key }?.second ?: key

@Composable
private fun Header(text: String) {
    Column(Modifier.padding(top = 20.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
        Text(
            text.uppercase(), style = MaterialTheme.typography.labelMedium, color = NoTubeRed,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
        )
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable { onChange(!checked) },
    )
}

@Composable
private fun ValueRow(title: String, value: String?, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = value?.let { { Text(it) } },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
    )
}

/** A miniature of the app in the theme's colours: background, a card and an accent chip. */
@Composable
private fun ThemeCard(t: AccentTheme, selected: Boolean, amoled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg = if (amoled) Color.Black else t.bg
    val card = if (amoled) Color(0xFF101010) else t.elev
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(14.dp)).background(bg)
                .border(BorderStroke(if (selected) 2.dp else 1.dp, if (selected) t.accent else MaterialTheme.colorScheme.outline), RoundedCornerShape(14.dp))
                .padding(8.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.width(26.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(t.accent))
                Box(Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp)).background(card))
                Box(Modifier.fillMaxWidth(0.7f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(card))
            }
            if (selected) Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(t.accent),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Check, null, tint = t.onAccent, modifier = Modifier.size(14.dp)) }
        }
        Spacer(Modifier.height(6.dp))
        Text(t.label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
private fun Picker(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                options.forEach { (key, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(key); onDismiss() }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = key == selected, onClick = { onSelect(key); onDismiss() })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
