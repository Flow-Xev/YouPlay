package app.notube.ui.screens.you

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.data.local.DOWNLOAD_DONE
import app.notube.ui.components.BrandBar
import app.notube.ui.components.VideoMiniCard
import app.notube.ui.screens.account.AccountViewModel
import app.notube.ui.screens.downloads.formatSize
import app.notube.ui.screens.library.LibraryViewModel
import app.notube.ui.theme.NoTubeRed
import coil.compose.AsyncImage

/** "You" tab: account + library merged into one page. */
@Composable
fun YouScreen(
    onOpenVideo: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    onOpenDownloads: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenChannels: () -> Unit,
    onSignIn: () -> Unit,
    onSearch: () -> Unit,
    library: LibraryViewModel = hiltViewModel(),
    accountVm: AccountViewModel = hiltViewModel(),
) {
    val data by library.state.collectAsStateWithLifecycle()
    val playlists by library.playlists.collectAsStateWithLifecycle()
    val downloads by library.downloads.collectAsStateWithLifecycle()
    val pending by library.pending.collectAsStateWithLifecycle()
    val account by accountVm.account.collectAsStateWithLifecycle()
    val busy by accountVm.busy.collectAsStateWithLifecycle()
    val message by accountVm.message.collectAsStateWithLifecycle()

    Scaffold(topBar = { BrandBar(onSearch = onSearch) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
            // ---- account header ----
            item {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = account.avatarUrl ?: app.notube.R.drawable.ic_logo, contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(if (account.signedIn) CircleShape else RoundedCornerShape(16.dp)),
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (account.signedIn) account.name ?: "Signed in" else "Guest", style = MaterialTheme.typography.titleLarge, maxLines = 1)
                            val sub = listOfNotNull(account.handle, account.email).joinToString(" · ")
                            Text(
                                if (account.signedIn) sub else "Sign in to sync your YouTube account",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Settings") }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (pending > 0) Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "$pending change${if (pending == 1) "" else "s"} waiting to sync with YouTube",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        if (account.signedIn) TextButton(onClick = library::syncNow) { Text("Sync now", color = NoTubeRed) }
                    }
                    if (account.signedIn) {
                        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 6.dp), color = NoTubeRed)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(onClick = accountVm::pull, enabled = !busy) {
                                Icon(Icons.Filled.CloudDownload, null); Spacer(Modifier.width(6.dp)); Text("Sync")
                            }
                            FilledTonalButton(onClick = accountVm::push, enabled = !busy) {
                                Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(6.dp)); Text("Push")
                            }
                            TextButton(onClick = accountVm::signOut) {
                                Icon(Icons.Filled.Logout, null); Spacer(Modifier.width(6.dp)); Text("Sign out")
                            }
                        }
                        message?.let { Text(it, color = NoTubeRed, style = MaterialTheme.typography.bodySmall) }
                    } else {
                        Button(onClick = onSignIn, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.Login, null); Spacer(Modifier.width(8.dp)); Text("Sign in")
                        }
                    }
                }
            }

            // ---- rows ----
            if (data.history.isNotEmpty()) item("h") {
                RowSection("History", action = "Clear", onAction = library::clearHistory) {
                    items(data.history, key = { "h" + it.videoId }) {
                        VideoMiniCard(it.title, it.channelName, it.thumbnailUrl, { onOpenVideo(it.videoId) })
                    }
                }
            }
            if (playlists.isNotEmpty()) item("p") {
                RowSection("Playlists") {
                    items(playlists, key = { "p" + it.id }) {
                        VideoMiniCard(it.title, it.subtitle, it.thumbnailUrl, { onOpenPlaylist(it.id) })
                    }
                }
            }
            item("d") {
                if (downloads.isEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = onOpenDownloads).padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Download, null); Spacer(Modifier.width(12.dp))
                        Text("Downloads", style = MaterialTheme.typography.titleMedium)
                    }
                } else RowSection("Downloads", action = "See all", onAction = onOpenDownloads) {
                    items(downloads, key = { "d" + it.videoId }) {
                        VideoMiniCard(
                            it.title, it.channelName, it.thumbnailUrl,
                            { if (it.status == DOWNLOAD_DONE) onOpenVideo(it.videoId) else onOpenDownloads() },
                            badge = if (it.status == DOWNLOAD_DONE) formatSize(it.sizeBytes) else "${it.progress}%",
                        )
                    }
                }
            }
            if (data.liked.isNotEmpty()) item("l") {
                RowSection("Liked videos") {
                    items(data.liked, key = { "l" + it.videoId }) {
                        VideoMiniCard(it.title, it.channelName, it.thumbnailUrl, { onOpenVideo(it.videoId) })
                    }
                }
            }
            if (data.subscriptions.isNotEmpty()) item("s") {
                RowSection("Subscriptions", action = "Manage", onAction = onOpenChannels) {
                    items(data.subscriptions, key = { "s" + it.channelId }) { sub ->
                        Column(Modifier.width(76.dp).clickable { onOpenChannel(sub.channelId) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(
                                sub.thumbnailUrl, sub.title, contentScale = ContentScale.Crop,
                                modifier = Modifier.size(60.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                            )
                            Text(sub.title, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
            if (data.history.isEmpty() && data.liked.isEmpty() && playlists.isEmpty()) item("empty") {
                Text(
                    "Watched and liked videos will show up here.",
                    modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun RowSection(
    title: String,
    action: String? = null,
    onAction: () -> Unit = {},
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    Column(Modifier.padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (action != null) TextButton(onClick = onAction) { Text(action, color = NoTubeRed) }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}
