package app.notube.data.repository

import app.notube.data.auth.AuthManager
import app.notube.domain.FeedEntry
import app.notube.domain.SearchFilter
import app.notube.domain.SearchPage
import app.notube.domain.WatchExtras
import app.notube.domain.FeedPage
import app.notube.domain.PlaylistItem
import app.notube.data.local.LikedVideoDao
import app.notube.data.local.LikedVideoEntity
import app.notube.data.local.SearchHistoryDao
import app.notube.data.local.SearchHistoryEntity
import app.notube.data.local.SettingsDataStore
import app.notube.data.local.SubscriptionDao
import app.notube.data.local.SubscriptionEntity
import app.notube.data.local.WatchHistoryDao
import app.notube.data.local.WatchHistoryEntity
import app.notube.data.remote.InnerTubeDataSource
import app.notube.domain.ChannelItem
import app.notube.domain.CommentItem
import app.notube.domain.HomeFeed
import app.notube.domain.StreamInfo
import app.notube.domain.VideoItem
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

@Singleton
class VideoRepository @Inject constructor(
    private val remote: InnerTubeDataSource,
    private val watchHistoryDao: WatchHistoryDao,
    private val likedVideoDao: LikedVideoDao,
    private val subscriptionDao: SubscriptionDao,
    private val searchHistoryDao: SearchHistoryDao,
    private val settingsDataStore: SettingsDataStore,
    private val auth: AuthManager,
    private val sync: app.notube.data.sync.AccountSync,
    private val commentApi: app.notube.data.remote.CommentApi,
    private val dislikedDao: app.notube.data.local.DislikedVideoDao,
) {
    val pendingSync = sync.pending
    suspend fun flushPending(): Int = sync.flush()
    fun observeDisliked(id: String): Flow<Boolean> = dislikedDao.observe(id)

    val watchHistory = watchHistoryDao.observe()
    val likedVideos = likedVideoDao.observe()
    val subscriptions = subscriptionDao.observe()
    val searchHistory = searchHistoryDao.observe()
    val settings = settingsDataStore.settings
    val account = auth.account

    suspend fun isSignedIn() = auth.isSignedIn()
    suspend fun signIn(cookie: String, visitorData: String?, dataSyncId: String?) {
        auth.signIn(cookie, visitorData, dataSyncId)
        remote.onAccountChanged()
        runCatching { sync.flush() }
        runCatching { syncFromAccount() }
    }
    suspend fun signOut() { auth.signOut(); remote.onAccountChanged() }

    // ---- feeds (Home / Subscriptions / History / Liked ...) ----
    suspend fun feed(browseId: String?, continuation: String? = null): FeedPage {
        applyLocale()
        if (browseId == "FEwhat_to_watch") runCatching { sync.flush() }
        return remote.feed(browseId, continuation)
    }
    suspend fun playlists(): List<PlaylistItem> { applyLocale(); return remote.playlists("FEplaylist_aggregation") }
    suspend fun playlistVideos(id: String) = run { applyLocale(); remote.playlistVideos(id) }

    // ---- shorts queue shared between Home shorts row and the Shorts player ----
    private var shortsQueue: List<VideoItem> = emptyList()
    fun setShortsQueue(list: List<VideoItem>) { shortsQueue = list }
    fun shortsQueue(): List<VideoItem> = shortsQueue

    /** Pull subscriptions, liked videos and history from the account into local storage. */
    suspend fun syncFromAccount(): Int {
        if (!isSignedIn()) return 0
        applyLocale()
        var n = 0
        runCatching { remote.subscribedChannels() }.getOrNull()?.forEach {
            subscriptionDao.upsert(SubscriptionEntity(it.id, it.title, it.thumbnailUrl, System.currentTimeMillis())); n++
        }
        runCatching { remote.feed("VLLL") }.getOrNull()?.entries?.filterIsInstance<FeedEntry.Video>()?.forEach {
            val v = it.item
            likedVideoDao.upsert(LikedVideoEntity(v.id, v.title, v.channelName, v.thumbnailUrl, System.currentTimeMillis())); n++
        }
        runCatching { remote.feed("FEhistory") }.getOrNull()?.entries?.filterIsInstance<FeedEntry.Video>()?.forEach {
            val v = it.item
            watchHistoryDao.upsert(WatchHistoryEntity(v.id, v.title, v.channelName, v.thumbnailUrl, System.currentTimeMillis())); n++
        }
        auth.refreshProfile()
        return n
    }

    /** Push local-only likes and subscriptions up to the account. */
    suspend fun pushLocalToAccount(): Int {
        if (!isSignedIn()) return 0
        applyLocale()
        var n = 0
        likedVideoDao.observe().first().forEach { if (runCatching { remote.like(it.videoId, true) }.isSuccess) n++ }
        subscriptionDao.observe().first().forEach { if (runCatching { remote.subscribe(it.channelId, true) }.isSuccess) n++ }
        return n
    }

    suspend fun home(): HomeFeed {
        applyLocale()
        return remote.homeFeed()
    }

    suspend fun search(query: String): List<VideoItem> {
        applyLocale()
        searchHistoryDao.upsert(SearchHistoryEntity(query.trim(), System.currentTimeMillis()))
        return remote.search(query.trim())
    }

    suspend fun searchPage(query: String, filter: SearchFilter, continuation: String? = null): SearchPage {
        applyLocale()
        if (continuation == null) searchHistoryDao.upsert(SearchHistoryEntity(query.trim(), System.currentTimeMillis()))
        return remote.searchPage(query.trim(), filter, continuation)
    }
    suspend fun suggestions(q: String) = remote.suggestions(q)
    suspend fun channelTab(id: String, params: String) = run { applyLocale(); remote.channelTab(id, params) }
    suspend fun watchExtras(id: String): WatchExtras { applyLocale(); return remote.watchExtras(id).first }
    suspend fun addToPlaylist(playlistId: String, videoId: String): Boolean =
        isSignedIn() && runCatching { remote.addToPlaylist(playlistId, videoId) }.isSuccess

    /** Watch later goes through the retry queue. */
    suspend fun saveToWatchLater(videoId: String): app.notube.data.sync.SyncResult =
        sync.send(app.notube.data.sync.AccountSync.WATCH_LATER, videoId, "add")

    suspend fun toggleDislike(videoId: String): Pair<Boolean, app.notube.data.sync.SyncResult> {
        val was = dislikedDao.observe(videoId).first()
        return if (was) {
            dislikedDao.delete(videoId)
            false to sync.send(app.notube.data.sync.AccountSync.REACT, videoId, "none")
        } else {
            dislikedDao.upsert(app.notube.data.local.DislikedVideoEntity(videoId, System.currentTimeMillis()))
            likedVideoDao.delete(videoId)
            true to sync.send(app.notube.data.sync.AccountSync.REACT, videoId, "dislike")
        }
    }

    suspend fun searchChannels(query: String): List<ChannelItem> {
        applyLocale()
        return remote.searchChannels(query.trim())
    }

    /** Account-personalised Shorts when signed in, with already-watched Shorts filtered out. */
    suspend fun shortsFeed(continuation: String? = null): app.notube.domain.ShortsPage {
        applyLocale()
        val page = remote.shortsFeed(isSignedIn(), continuation)
        val unseen = page.videos.filter { watchHistoryDao.get(it.id) == null }
        return page.copy(videos = unseen.ifEmpty { page.videos })
    }

    suspend fun shorts(): List<VideoItem> {
        applyLocale()
        return remote.shorts()
    }

    suspend fun channel(id: String): Pair<ChannelItem?, List<VideoItem>> {
        applyLocale()
        return remote.channel(id)
    }

    suspend fun channelHome(id: String) = run { applyLocale(); remote.channelHome(id) }

    suspend fun comments(videoId: String): List<CommentItem> {
        applyLocale()
        return remote.comments(videoId)
    }

    suspend fun commentsPage(videoId: String, continuation: String? = null): app.notube.domain.CommentsPage {
        applyLocale()
        return remote.commentsPage(videoId, continuation)
    }
    suspend fun postComment(createParams: String, text: String) = run { auth.ensure(); commentApi.post(createParams, text) }
    suspend fun replyToComment(replyParams: String, text: String) = run { auth.ensure(); commentApi.reply(replyParams, text) }
    suspend fun commentAction(token: String) { auth.ensure(); commentApi.action(token) }

    suspend fun related(videoId: String): List<VideoItem> {
        applyLocale()
        return remote.relatedAndComments(videoId).first
    }

    suspend fun stream(videoId: String, maxHeight: Int = 1080, record: Boolean = true, fresh: Boolean = false): StreamInfo {
        applyLocale()
        val info = remote.resolveStream(videoId, maxHeight, fresh)
        if (!record) return info
        val oldProgress = watchHistoryDao.get(videoId)?.progressMs ?: 0L
        watchHistoryDao.upsert(
            WatchHistoryEntity(
                videoId = info.videoId,
                title = info.title,
                channelName = info.channelName,
                thumbnailUrl = info.thumbnailUrl,
                watchedAt = System.currentTimeMillis(),
                progressMs = oldProgress,
            ),
        )
        if (info.playbackUrl != null && info.cpn != null && isSignedIn()) {
            runCatching { remote.reportPlayback(info.playbackUrl, info.cpn) }
        }
        return info
    }

    suspend fun savedProgress(videoId: String): Long = watchHistoryDao.get(videoId)?.progressMs ?: 0L

    fun observeLiked(videoId: String): Flow<Boolean> = likedVideoDao.observeLiked(videoId)

    suspend fun toggleLike(video: VideoItem): Pair<Boolean, app.notube.data.sync.SyncResult> {
        val liked = likedVideoDao.observeLiked(video.id).first()
        return if (liked) {
            likedVideoDao.delete(video.id)
            false to sync.send(app.notube.data.sync.AccountSync.REACT, video.id, "none")
        } else {
            likedVideoDao.upsert(
                LikedVideoEntity(video.id, video.title, video.channelName, video.thumbnailUrl, System.currentTimeMillis()),
            )
            dislikedDao.delete(video.id)
            true to sync.send(app.notube.data.sync.AccountSync.REACT, video.id, "like")
        }
    }

    fun observeSubscribed(channelId: String): Flow<Boolean> = subscriptionDao.observeSubscribed(channelId)

    suspend fun toggleSubscribe(channel: ChannelItem): Pair<Boolean, app.notube.data.sync.SyncResult> {
        val sub = subscriptionDao.observeSubscribed(channel.id).first()
        return if (sub) {
            subscriptionDao.delete(channel.id)
            false to sync.send(app.notube.data.sync.AccountSync.SUB, channel.id, "off")
        } else {
            subscriptionDao.upsert(SubscriptionEntity(channel.id, channel.title, channel.thumbnailUrl, System.currentTimeMillis()))
            true to sync.send(app.notube.data.sync.AccountSync.SUB, channel.id, "on")
        }
    }

    suspend fun clearHistory() = watchHistoryDao.clear()
    suspend fun clearSearchHistory() = searchHistoryDao.clear()
    suspend fun removeSearch(q: String) = searchHistoryDao.delete(q)

    suspend fun updateSettings(transform: (app.notube.data.local.AppSettings) -> app.notube.data.local.AppSettings) =
        settingsDataStore.update(transform)

    private suspend fun applyLocale() {
        auth.ensure()
        val s = settingsDataStore.settings.first()
        remote.configureLocale(s.language, s.regionCode)
    }
}
