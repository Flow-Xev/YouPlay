package app.notube.ui.screens.login

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.notube.data.repository.VideoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONTokener

@HiltViewModel
class LoginViewModel @Inject constructor(private val repo: VideoRepository) : ViewModel() {
    fun signIn(cookie: String, visitor: String?, sync: String?, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.signIn(cookie, visitor, sync)
            onDone()
        }
    }
}

private const val LOGIN_URL =
    "https://accounts.google.com/ServiceLogin?service=youtube&continue=" +
        "https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26next%3D%252F"

// Google blocks the default Android WebView UA for sign-in, so present a desktop browser.
private const val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(
    onDone: () -> Unit,
    onBack: () -> Unit,
    viewModel: LoginViewModel = hiltViewModel(),
) {
    val finished = remember { AtomicBoolean(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sign in to YouTube") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
            )
        },
    ) { padding ->
        AndroidView(
            modifier = Modifier.fillMaxSize().padding(padding),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString = DESKTOP_UA
                    CookieManager.getInstance().apply {
                        setAcceptCookie(true)
                        setAcceptThirdPartyCookies(this@apply, true)
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView, url: String?) {
                            if (finished.get() || url == null) return
                            if (!url.startsWith("https://www.youtube.com") && !url.startsWith("https://m.youtube.com")) return
                            val cookie = CookieManager.getInstance().getCookie("https://www.youtube.com") ?: return
                            if (!cookie.contains("SAPISID")) return
                            val js = "(function(){try{return JSON.stringify([ytcfg.get('VISITOR_DATA')||''," +
                                "ytcfg.get('DATASYNC_ID')||''])}catch(e){return ''}})()"
                            view.evaluateJavascript(js) { raw ->
                                if (!finished.compareAndSet(false, true)) return@evaluateJavascript
                                var visitor: String? = null
                                var sync: String? = null
                                runCatching {
                                    val arr = JSONArray(JSONTokener(raw).nextValue() as String)
                                    visitor = arr.optString(0).ifBlank { null }
                                    sync = arr.optString(1).ifBlank { null }
                                }
                                viewModel.signIn(cookie, visitor, sync, onDone)
                            }
                        }
                    }
                    loadUrl(LOGIN_URL)
                }
            },
            onRelease = { it.destroy() },
        )
    }
}
