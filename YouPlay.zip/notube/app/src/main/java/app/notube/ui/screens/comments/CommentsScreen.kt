package app.notube.ui.screens.comments

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.domain.CommentItem
import app.notube.ui.components.StateScaffold
import app.notube.ui.theme.NoTubeRed
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsScreen(
    onBack: () -> Unit,
    viewModel: CommentsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val signedIn by viewModel.signedIn.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var text by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<CommentItem?>(null) }
    var confirmDelete by remember { mutableStateOf<CommentItem?>(null) }
    val ui = (state as? app.notube.domain.UiState.Success)?.data

    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); viewModel.messageShown() } }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Comments") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(8.dp)) {
                    replyTo?.let { r ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Replying to ${r.author}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f).padding(start = 8.dp))
                            IconButton(onClick = { replyTo = null }, modifier = Modifier.size(28.dp)) { Icon(Icons.Filled.Close, "Cancel reply") }
                        }
                    }
                    if (!signedIn) {
                        Text("Sign in (You tab) to comment", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp))
                    } else if (ui != null && ui.createParams == null && replyTo == null) {
                        Text("Comments are unavailable for this video", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp))
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = text, onValueChange = { text = it },
                                placeholder = { Text(if (replyTo != null) "Add a reply…" else "Add a comment…") },
                                modifier = Modifier.weight(1f), maxLines = 4,
                            )
                            if (ui?.posting == true) CircularProgressIndicator(Modifier.padding(12.dp).size(24.dp), strokeWidth = 2.dp, color = NoTubeRed)
                            else IconButton(
                                onClick = { viewModel.post(text, replyTo) { text = ""; replyTo = null } },
                                enabled = text.isNotBlank(),
                            ) { Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = if (text.isNotBlank()) NoTubeRed else MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
            }
        },
    ) { padding ->
        StateScaffold(state = state, onRetry = viewModel::refresh, modifier = Modifier.fillMaxSize().padding(padding)) { data ->
            if (data.comments.isEmpty()) {
                Text("No comments yet.", modifier = Modifier.padding(24.dp), style = MaterialTheme.typography.bodyLarge)
            } else LazyColumn(contentPadding = PaddingValues(16.dp), modifier = Modifier.fillMaxSize()) {
                items(data.comments, key = { it.id }) { c ->
                    val liked = c.id in data.liked
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                        AsyncImage(c.authorThumbUrl, null, contentScale = ContentScale.Crop, modifier = Modifier.size(40.dp).clip(CircleShape))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                listOfNotNull(c.author, c.publishedText).joinToString(" · "),
                                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(c.text, style = MaterialTheme.typography.bodyLarge)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                if (c.likeToken != null || c.unlikeToken != null) {
                                    IconButton(onClick = { viewModel.toggleLike(c) }, modifier = Modifier.size(32.dp)) {
                                        Icon(if (liked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp, "Like", tint = if (liked) NoTubeRed else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                    }
                                }
                                val likes = c.likeCountText?.takeIf { it.isNotBlank() }
                                if (likes != null) Text(likes, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (signedIn && c.replyParams != null) TextButton(onClick = { replyTo = c }) { Text("Reply") }
                                if (c.replyCount > 0) Text("${c.replyCount} replies", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.weight(1f))
                                if (c.deleteToken != null) IconButton(onClick = { confirmDelete = c }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Filled.Delete, "Delete", modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
                if (data.continuation != null) item {
                    TextButton(onClick = viewModel::loadMore, modifier = Modifier.fillMaxWidth()) {
                        Text(if (data.loadingMore) "Loading…" else "Load more comments")
                    }
                }
            }
        }
    }

    confirmDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete comment?") },
            text = { Text("This removes it from YouTube.") },
            confirmButton = { TextButton(onClick = { viewModel.delete(c); confirmDelete = null }) { Text("Delete", color = NoTubeRed) } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
}
