package app.notube.ui.screens.subscriptions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.notube.data.local.SubscriptionEntity
import app.notube.data.repository.VideoRepository
import app.notube.domain.AccountState
import app.notube.domain.FeedEntry
import app.notube.domain.UiState
import app.notube.domain.VideoItem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SubsUi(val entries: List<FeedEntry>, val continuation: String?, val loadingMore: Boolean = false)

@HiltViewModel
class SubscriptionsViewModel @Inject constructor(
    private val repository: VideoRepository,
) : ViewModel() {
    val account: StateFlow<AccountState> =
        repository.account.stateIn(viewModelScope, SharingStarted.Eagerly, AccountState())
    val channels: StateFlow<List<SubscriptionEntity>> =
        repository.subscriptions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _state = MutableStateFlow<UiState<SubsUi>?>(null)
    val state: StateFlow<UiState<SubsUi>?> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repository.account.map { it.signedIn }.distinctUntilChanged().collect { if (it) load() else _state.value = null }
        }
    }

    fun load() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = runCatching {
                val p = repository.feed("FEsubscriptions")
                UiState.Success(SubsUi(p.entries, p.continuation))
            }.getOrElse { UiState.Error(it.message ?: "Failed to load subscriptions", it) }
        }
    }

    fun loadMore() {
        val cur = (_state.value as? UiState.Success)?.data ?: return
        val token = cur.continuation ?: return
        if (cur.loadingMore) return
        _state.value = UiState.Success(cur.copy(loadingMore = true))
        viewModelScope.launch {
            val p = runCatching { repository.feed(null, token) }.getOrNull()
            val latest = (_state.value as? UiState.Success)?.data ?: return@launch
            if (p == null) { _state.value = UiState.Success(latest.copy(loadingMore = false, continuation = null)); return@launch }
            val have = latest.entries.filterIsInstance<FeedEntry.Video>().map { it.item.id }.toHashSet()
            val fresh = p.entries.filter { it !is FeedEntry.Video || have.add(it.item.id) }
            _state.value = UiState.Success(latest.copy(entries = latest.entries + fresh, continuation = p.continuation, loadingMore = false))
        }
    }

    fun setShortsQueue(list: List<VideoItem>) = repository.setShortsQueue(list)
}
