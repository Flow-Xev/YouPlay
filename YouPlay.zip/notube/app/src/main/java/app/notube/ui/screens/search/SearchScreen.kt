package app.notube.ui.screens.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NorthWest
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.domain.FeedEntry
import app.notube.domain.SearchFilter
import app.notube.domain.SearchType
import app.notube.ui.components.ChannelRow
import app.notube.ui.components.PlaylistRow
import app.notube.ui.components.ShortThumb
import app.notube.ui.components.StateScaffold
import app.notube.ui.components.feedEntries
import app.notube.ui.theme.NoTubeRed

@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenVideo: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
    onOpenShort: (String) -> Unit,
    onOpenPlaylist: (String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val query by viewModel.query.collectAsStateWithLifecycle()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val filter by viewModel.filter.collectAsStateWithLifecycle()
    val suggestions by viewModel.suggestions.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    var showFilters by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                TextField(
                    value = query,
                    onValueChange = viewModel::onQueryChange,
                    placeholder = { Text("Search videos, Shorts, channels") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { viewModel.search() }),
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton(onClick = { viewModel.onQueryChange("") }) { Icon(Icons.Default.Close, "Clear") }
                    },
                    colors = TextFieldDefaults.colors(focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent),
                    modifier = Modifier.weight(1f),
                )
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            val s = state
            if (s == null) {
                LazyColumn(Modifier.fillMaxSize()) {
                    if (query.isNotBlank() && suggestions.isNotEmpty()) {
                        items(suggestions) { sug ->
                            ListItem(
                                headlineContent = { Text(sug) },
                                leadingContent = { Icon(Icons.Default.Search, null) },
                                trailingContent = { IconButton(onClick = { viewModel.onQueryChange(sug) }) { Icon(Icons.Default.NorthWest, "Use suggestion") } },
                                modifier = Modifier.clickable { viewModel.search(sug) },
                            )
                        }
                    } else {
                        if (history.isNotEmpty()) item {
                            Row(Modifier.fillMaxWidth().padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Recent", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                TextButton(onClick = viewModel::clearHistory) { Text("Clear") }
                            }
                        }
                        items(history, key = { it.query }) { h ->
                            ListItem(
                                headlineContent = { Text(h.query) },
                                leadingContent = { Icon(Icons.Default.History, null) },
                                trailingContent = { IconButton(onClick = { viewModel.removeHistory(h.query) }) { Icon(Icons.Default.Close, "Remove") } },
                                modifier = Modifier.clickable { viewModel.search(h.query) },
                            )
                        }
                    }
                }
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    item { AssistChip(onClick = { showFilters = true }, label = { Text("Filters") }, leadingIcon = { Icon(Icons.Default.Tune, null) }) }
                    items(SearchType.entries.toList()) { t ->
                        FilterChip(selected = filter.type == t, onClick = { viewModel.setType(t) }, label = { Text(t.label) })
                    }
                }
                StateScaffold(s, { viewModel.search() }) { ui ->
                    if (filter.type == SearchType.SHORTS) {
                        if (ui.shorts.isEmpty()) Text("No Shorts found", Modifier.padding(16.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            contentPadding = PaddingValues(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            gridItems(ui.shorts, key = { it.id }) { v ->
                                ShortThumb(v) { viewModel.setShortsQueue(ui.shorts); onOpenShort(v.id) }
                            }
                        }
                    } else {
                        val listState = rememberLazyListState()
                        val total = ui.entries.size
                        LaunchedEffect(listState, total) {
                            snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
                                .collect { last -> if (last >= total - 2) viewModel.loadMore() }
                        }
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                            items(ui.channels.take(3), key = { "c" + it.id }) { c ->
                                ChannelRow(c, { onOpenChannel(c.id) }, Modifier.padding(horizontal = 16.dp))
                            }
                            feedEntries(ui.entries, onOpenVideo) { list, v -> viewModel.setShortsQueue(list); onOpenShort(v.id) }
                            items(ui.playlists, key = { "p" + it.id }) { p ->
                                PlaylistRow(p, { onOpenPlaylist(p.id) }, Modifier.padding(horizontal = 16.dp))
                            }
                            if (ui.loadingMore) item(key = "more") {
                                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = NoTubeRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFilters) FilterDialog(filter, { showFilters = false }) { viewModel.setFilter(it); showFilters = false }
}

@Composable
private fun FilterDialog(current: SearchFilter, onDismiss: () -> Unit, onApply: (SearchFilter) -> Unit) {
    var f by remember { mutableStateOf(current) }
    @Composable
    fun group(title: String, options: List<Pair<String, Int?>>, selected: Int?, pick: (Int?) -> Unit) {
        Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(options) { (label, v) ->
                FilterChip(selected = selected == v, onClick = { pick(v) }, label = { Text(label) })
            }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search filters") },
        text = {
            Column {
                group("Upload date", listOf("Any" to null, "Hour" to 1, "Today" to 2, "Week" to 3, "Month" to 4, "Year" to 5), f.date) { f = f.copy(date = it) }
                group("Duration", listOf("Any" to null, "< 4 min" to 1, "4–20 min" to 3, "> 20 min" to 2), f.duration) { f = f.copy(duration = it) }
                group("Sort by", listOf("Relevance" to null, "Upload date" to 2, "Views" to 3, "Rating" to 1), f.sort) { f = f.copy(sort = it) }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(f) }) { Text("Apply", color = NoTubeRed) } },
        dismissButton = { TextButton(onClick = { onApply(SearchFilter(type = current.type)) }) { Text("Reset") } },
    )
}
