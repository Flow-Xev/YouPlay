package app.notube.ui.screens.shorts

import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import app.notube.domain.VideoItem
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.data.repository.VideoRepository
import app.notube.domain.StreamInfo
import app.notube.domain.UiState
import app.notube.ui.components.StateScaffold
import app.notube.ui.player.VideoPlayer
import app.notube.ui.theme.NoTubeBlack
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@EntryPoint
@InstallIn(SingletonComponent::class)
interface ShortsRepoEntryPoint {
    fun videoRepository(): VideoRepository
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShortsScreen(
    onOpenComments: (String) -> Unit,
    onBack: (() -> Unit)? = null,
    viewModel: ShortsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    StateScaffold(state = state, onRetry = viewModel::refresh, modifier = Modifier.fillMaxSize()) { shorts ->
        if (shorts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No Shorts available right now")
            }
            return@StateScaffold
        }
        val pagerState = rememberPagerState(pageCount = { shorts.size })
        LaunchedEffect(pagerState.currentPage, shorts.size) { viewModel.onPage(pagerState.currentPage) }
        Box(Modifier.fillMaxSize()) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxSize()
                .background(NoTubeBlack),
        ) { page ->
            val item = shorts[page]
            ShortPage(
                videoId = item.id,
                title = item.title,
                active = pagerState.currentPage == page,
                onOpenComments = { onOpenComments(item.id) },
            )
        }
        if (onBack != null) androidx.compose.material3.IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).padding(top = 32.dp, start = 8.dp),
        ) {
            androidx.compose.material3.Icon(
                androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White,
            )
        }
        }
    }
}

@Composable
private fun ShortPage(
    videoId: String,
    title: String,
    active: Boolean,
    onOpenComments: () -> Unit,
) {
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var stream by remember(videoId) { mutableStateOf<StreamInfo?>(null) }
    var error by remember(videoId) { mutableStateOf<String?>(null) }

    LaunchedEffect(videoId, active) {
        if (!active || stream != null) return@LaunchedEffect
        val repo = EntryPointAccessors.fromApplication(
            context.applicationContext,
            ShortsRepoEntryPoint::class.java,
        ).videoRepository()
        runCatching {
            withContext(Dispatchers.IO) { repo.stream(videoId, 720) }
        }.onSuccess { stream = it }.onFailure { error = it.message }
    }

    Box(Modifier.fillMaxSize()) {
        when {
            stream != null && active -> VideoPlayer(
                stream = stream!!,
                modifier = Modifier.fillMaxSize(),
                playWhenReady = true,
                resizeModeFill = true,
            )
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error ?: "Error", color = Color.White)
            }
            else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Loading…", color = Color.White)
            }
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(0.8f))))
                .padding(16.dp),
        ) {
            stream?.channelName?.takeIf { it.isNotBlank() }?.let {
                Text(it, style = MaterialTheme.typography.titleMedium, color = Color.White)
            }
            Text(title, style = MaterialTheme.typography.bodyLarge, color = Color.White)
            Row {
                TextButton(onClick = {
                    scope.launch {
                        stream?.let { st ->
                            val (on, r) = repoOf(context).toggleLike(VideoItem(st.videoId, st.title, st.channelName, st.channelId, st.thumbnailUrl))
                            android.widget.Toast.makeText(context, r.describe(if (on) "Liked" else "Like removed"), android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Like") }
                TextButton(onClick = {
                    scope.launch {
                        stream?.let { st ->
                            val (on, r) = repoOf(context).toggleDislike(st.videoId)
                            android.widget.Toast.makeText(context, r.describe(if (on) "Disliked" else "Dislike removed"), android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Dislike") }
                TextButton(onClick = onOpenComments) { Text("Comments") }
                TextButton(onClick = {
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(android.content.Intent.EXTRA_TEXT, "https://youtube.com/shorts/$videoId")
                    context.startActivity(android.content.Intent.createChooser(send, "Share"))
                }) { Text("Share") }
            }
        }
    }
}

private fun repoOf(context: android.content.Context): VideoRepository =
    EntryPointAccessors.fromApplication(context.applicationContext, ShortsRepoEntryPoint::class.java).videoRepository()
