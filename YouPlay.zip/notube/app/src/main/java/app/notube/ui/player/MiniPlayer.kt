package app.notube.ui.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import app.notube.ui.theme.NoTubeRed
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

/**
 * Floating mini player in the style of Flow's / YouTube's: a small video window with its
 * controls drawn on top (play/pause top-left, close top-right, -10s / +10s along the bottom,
 * thin progress line). Drag it anywhere; on release it springs to the nearest corner.
 * Drag it off the left/right edge to dismiss. Tap = expand to the full player.
 * Place it inside a Box that covers the screen content area (above the bottom bar).
 */
@Composable
fun FloatingMiniPlayer(
    controller: PlayerController,
    onExpand: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val stream by controller.current.collectAsState()
    val s = stream ?: return
    val playing by controller.isPlaying.collectAsState()
    val buffering by controller.buffering.collectAsState()
    val (pos, dur) = rememberPlayerProgress(controller).value
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    BoxWithConstraints(modifier.fillMaxSize()) {
        val miniW = 220.dp
        val miniH = miniW * 9 / 16
        val margin = 12.dp
        val wPx = with(density) { miniW.toPx() }
        val hPx = with(density) { miniH.toPx() }
        val mPx = with(density) { margin.toPx() }
        val minX = mPx
        val maxX = with(density) { maxWidth.toPx() } - wPx - mPx
        val minY = mPx
        val maxY = with(density) { maxHeight.toPx() } - hPx - mPx

        val offset = remember { Animatable(Offset(maxX, maxY), Offset.VectorConverter) }
        LaunchedEffect(maxX, maxY) {
            offset.snapTo(Offset(offset.value.x.coerceIn(minX, maxX), offset.value.y.coerceIn(minY, maxY)))
        }

        fun snapTarget(p: Offset): Offset {
            val right = p.x + wPx / 2 > (minX + maxX + wPx) / 2
            val bottom = p.y + hPx / 2 > (minY + maxY + hPx) / 2
            return Offset(if (right) maxX else minX, if (bottom) maxY else minY)
        }

        Box(
            Modifier
                .offset { IntOffset(offset.value.x.roundToInt(), offset.value.y.roundToInt()) }
                .size(miniW, miniH)
                .shadow(12.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black)
                .pointerInput(Unit) { detectTapGestures(onTap = { onExpand(s.videoId) }) }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = {
                            val p = offset.value
                            val off = if (p.x < minX) minX - p.x else if (p.x > maxX) p.x - maxX else 0f
                            if (off > wPx * 0.45f) controller.stop()
                            else scope.launch {
                                offset.animateTo(snapTarget(p), spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow))
                            }
                        },
                        onDrag = { change, d ->
                            change.consume()
                            scope.launch {
                                val n = offset.value + Offset(d.x, d.y)
                                offset.snapTo(Offset(n.x, n.y.coerceIn(minY, maxY)))
                            }
                        },
                    )
                },
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                        setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                        player = controller.player
                        layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    }
                },
                update = { it.player = controller.player },
                onRelease = { it.player = null },
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(0.35f), Color.Transparent, Color.Black.copy(0.45f))),
                ),
            )
            // top-left: play / pause
            IconButton(
                onClick = controller::toggle,
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp).size(36.dp).background(Color.Black.copy(0.45f), CircleShape),
            ) {
                if (buffering) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                else Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            // top-right: close
            IconButton(
                onClick = controller::stop,
                modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(36.dp).background(Color.Black.copy(0.45f), CircleShape),
            ) { Icon(Icons.Filled.Close, "Close", tint = Color.White, modifier = Modifier.size(22.dp)) }
            // bottom: skip back / forward
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                IconButton({ controller.seekBy(-10_000) }, Modifier.size(32.dp).background(Color.Black.copy(0.45f), CircleShape)) {
                    Icon(Icons.Filled.Replay10, "Back 10 seconds", tint = Color.White, modifier = Modifier.size(22.dp))
                }
                IconButton({ controller.seekBy(10_000) }, Modifier.size(32.dp).background(Color.Black.copy(0.45f), CircleShape)) {
                    Icon(Icons.Filled.Forward10, "Forward 10 seconds", tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
            LinearProgressIndicator(
                progress = { if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
                color = NoTubeRed,
                trackColor = Color.Transparent,
            )
        }
    }
}
