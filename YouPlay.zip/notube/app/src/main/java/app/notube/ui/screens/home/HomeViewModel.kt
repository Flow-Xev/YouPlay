package app.notube.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.notube.data.repository.VideoRepository
import app.notube.domain.ChipItem
import app.notube.domain.FeedEntry
import app.notube.domain.UiState
import app.notube.domain.VideoItem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUi(
    val entries: List<FeedEntry> = emptyList(),
    val chips: List<ChipItem> = emptyList(),
    val selected: String = "All",
    val continuation: String? = null,
    val loadingMore: Boolean = false,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: VideoRepository,
) : ViewModel() {
    private val _state = MutableStateFlow<UiState<HomeUi>>(UiState.Loading)
    val state: StateFlow<UiState<HomeUi>> = _state.asStateFlow()
    private var chips: List<ChipItem> = emptyList()
    val continueWatching = repository.watchHistory
        .map { list -> list.filter { it.progressMs > 10_000 }.take(12) }
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000), emptyList())
    val showShorts: StateFlow<Boolean> = repository.settings.map { it.showShorts }
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5_000), true)

    init { refresh() }

    fun refresh() = load(null)

    fun selectChip(chip: ChipItem) = if (chip.label == "All" || chip.token == null) load(null) else load(chip)

    private fun load(chip: ChipItem?) {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = runCatching {
                val page = if (chip == null) repository.feed("FEwhat_to_watch") else repository.feed(null, chip.token)
                if (chip == null && page.chips.isNotEmpty()) chips = listOf(ChipItem("All", null, true)) + page.chips.filter { it.label != "All" }
                if (chips.isEmpty()) chips = listOf(ChipItem("All", null, true))
                UiState.Success(HomeUi(page.entries, chips, chip?.label ?: "All", page.continuation))
            }.getOrElse { UiState.Error(it.message ?: "Failed to load home", it) }
            if (chip == null) ensureShortsRow()
        }
    }

    /** If YouTube sent no Shorts shelf, build one from the Shorts feed and place it after a few videos. */
    private suspend fun ensureShortsRow() {
        val cur = (_state.value as? UiState.Success)?.data ?: return
        if (cur.entries.any { it is FeedEntry.ShortsRow }) return
        val shorts = runCatching { repository.shorts() }.getOrNull().orEmpty().take(15)
        if (shorts.size < 3) return
        val at = minOf(4, cur.entries.size)
        val list = cur.entries.toMutableList().apply { add(at, FeedEntry.ShortsRow(shorts)) }
        _state.value = UiState.Success(cur.copy(entries = list))
    }

    fun loadMore() {
        val cur = (_state.value as? UiState.Success)?.data ?: return
        val token = cur.continuation ?: return
        if (cur.loadingMore) return
        _state.value = UiState.Success(cur.copy(loadingMore = true))
        viewModelScope.launch {
            val page = runCatching { repository.feed(null, token) }.getOrNull()
            val latest = (_state.value as? UiState.Success)?.data ?: return@launch
            if (page == null) { _state.value = UiState.Success(latest.copy(loadingMore = false, continuation = null)); return@launch }
            val have = latest.entries.filterIsInstance<FeedEntry.Video>().map { it.item.id }.toHashSet()
            val fresh = page.entries.filter { it !is FeedEntry.Video || have.add(it.item.id) }
            _state.value = UiState.Success(latest.copy(entries = latest.entries + fresh, continuation = page.continuation, loadingMore = false))
        }
    }

    fun setShortsQueue(list: List<VideoItem>) = repository.setShortsQueue(list)
}
