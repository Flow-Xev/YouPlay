package app.notube.ui.theme

import androidx.compose.ui.graphics.Color

val NoTubeRedDim = Color(0xFFB20710)
val NoTubeBlack = Color(0xFF0A0A0A)
val NoTubeSurface = Color(0xFF141414)
val NoTubeSurfaceElevated = Color(0xFF1C1C1C)
val NoTubeOutline = Color(0xFF2A2A2A)
val NoTubeOnDark = Color(0xFFF5F5F5)
val NoTubeMuted = Color(0xFFA3A3A3)
val NoTubeAccentSoft = Color(0x33E50914)
