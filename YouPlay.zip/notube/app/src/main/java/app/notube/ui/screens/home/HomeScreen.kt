package app.notube.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.domain.FeedEntry
import app.notube.ui.components.BrandBar
import app.notube.ui.components.FeedSkeleton
import app.notube.ui.components.PillChips
import app.notube.ui.components.ShortsRowSection
import app.notube.ui.components.StateScaffold
import app.notube.ui.components.VideoCard
import app.notube.ui.theme.NoTubeRed
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    onOpenVideo: (String) -> Unit,
    onOpenShort: (String) -> Unit,
    onSearch: () -> Unit = {},
    viewModel: HomeViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val showShorts by viewModel.showShorts.collectAsStateWithLifecycle()
    val resume by viewModel.continueWatching.collectAsStateWithLifecycle()
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { BrandBar(onSearch = onSearch) }) { padding ->
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = { scope.launch { refreshing = true; viewModel.refresh(); refreshing = false } },
            modifier = Modifier.fillMaxSize().padding(padding),
        ) {
            StateScaffold(state = state, onRetry = viewModel::refresh, loading = { FeedSkeleton() }) { ui ->
                val listState = rememberLazyListState()
                val shown = if (showShorts) ui.entries else ui.entries.filterNot { it is FeedEntry.ShortsRow }
                LaunchedEffect(listState, ui.entries.size) {
                    snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
                        .collect { last -> if (last >= ui.entries.size - 3) viewModel.loadMore() }
                }
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    if (ui.chips.size > 1) stickyHeader(key = "chips") {
                        PillChips(
                            labels = ui.chips.map { it.label }, selected = ui.selected,
                            onSelect = { viewModel.selectChip(ui.chips[it]) },
                        )
                    }
                    if (resume.isNotEmpty() && ui.selected == "All") item(key = "continue") {
                        Text("Continue watching", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp))
                        androidx.compose.foundation.lazy.LazyRow(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(bottom = 12.dp),
                        ) {
                            items(resume, key = { it.videoId }) { h ->
                                app.notube.ui.components.VideoMiniCard(
                                    title = h.title, subtitle = h.channelName, thumbnailUrl = h.thumbnailUrl,
                                    badge = "Resume " + app.notube.ui.player.formatTime(h.progressMs),
                                    onClick = { onOpenVideo(h.videoId) },
                                )
                            }
                        }
                    }
                    itemsIndexed(
                        shown,
                        key = { i, e -> when (e) { is FeedEntry.Video -> "v" + e.item.id; is FeedEntry.ShortsRow -> "s$i" } },
                    ) { _, entry ->
                        when (entry) {
                            is FeedEntry.Video -> VideoCard(
                                video = entry.item,
                                onClick = { onOpenVideo(entry.item.id) },
                                modifier = Modifier.padding(horizontal = 16.dp),
                            )
                            is FeedEntry.ShortsRow -> ShortsRowSection(
                                shorts = entry.shorts,
                                onClick = { v -> viewModel.setShortsQueue(entry.shorts); onOpenShort(v.id) },
                            )
                        }
                    }
                    if (ui.loadingMore) item(key = "more") {
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = NoTubeRed)
                        }
                    }
                }
            }
        }
    }
}
