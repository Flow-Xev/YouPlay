package app.notube.ui.screens.shorts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.notube.data.repository.VideoRepository
import app.notube.domain.UiState
import app.notube.domain.VideoItem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class ShortsViewModel @Inject constructor(
    savedStateHandle: androidx.lifecycle.SavedStateHandle,
    private val repository: VideoRepository,
) : ViewModel() {
    private val _state = MutableStateFlow<UiState<List<VideoItem>>>(UiState.Loading)
    val state: StateFlow<UiState<List<VideoItem>>> = _state.asStateFlow()

    private val startId: String? = savedStateHandle["videoId"]

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = runCatching {
                if (startId == null) UiState.Success(repository.shorts())
                else {
                    val q = repository.shortsQueue()
                    val head = q.dropWhile { it.id != startId }.ifEmpty { listOf(VideoItem(startId, "Short", isShort = true)) }
                    val rest = runCatching { repository.shorts() }.getOrDefault(emptyList())
                    UiState.Success((head + rest).distinctBy { it.id })
                }
            }
                .getOrElse { UiState.Error(it.message ?: "Failed to load Shorts", it) }
        }
    }
}
