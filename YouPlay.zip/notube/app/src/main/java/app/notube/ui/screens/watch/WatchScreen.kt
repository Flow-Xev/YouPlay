package app.notube.ui.screens.watch

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.notube.ui.components.StateScaffold
import app.notube.ui.components.VideoCard
import app.notube.ui.player.PlayerMenuAction
import app.notube.ui.player.WatchPlayer

private fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

@Composable
fun WatchScreen(
    onBack: () -> Unit,
    onOpenVideo: (String) -> Unit,
    onOpenComments: (String) -> Unit,
    onOpenChannel: (String) -> Unit,
    viewModel: WatchViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val liked by viewModel.liked.collectAsStateWithLifecycle()
    val subscribed by viewModel.subscribed.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val controller = viewModel.controller
    val dl by viewModel.download.collectAsStateWithLifecycle()
    val disliked by viewModel.disliked.collectAsStateWithLifecycle()
    val votes by viewModel.votes.collectAsStateWithLifecycle()
    androidx.compose.runtime.DisposableEffect(Unit) {
        viewModel.controller.watchVisible = true
        onDispose { viewModel.controller.watchVisible = false }
    }
    val speed by controller.speed.collectAsState()
    val current by controller.current.collectAsState()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val view = LocalView.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val snackbar = remember { SnackbarHostState() }
    var expanded by remember { mutableStateOf(false) }
    var saveMenu by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); viewModel.messageShown() }
    }

    // Landscape = immersive fullscreen
    DisposableEffect(landscape) {
        val window = activity?.window
        val ctl = window?.let { WindowCompat.getInsetsController(it, view) }
        if (landscape) {
            ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl?.hide(WindowInsetsCompat.Type.systemBars())
        } else ctl?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { ctl?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    val toggleFullscreen = {
        activity?.requestedOrientation =
            if (landscape) ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }
    BackHandler(enabled = landscape) { toggleFullscreen() }

    val title = current?.title.orEmpty()
    val autoplay by viewModel.autoplay.collectAsStateWithLifecycle()
    val nextId = (state as? app.notube.domain.UiState.Success)?.data?.extras?.related?.firstOrNull()?.id
    DisposableEffect(autoplay, nextId) {
        controller.onEnded = { if (autoplay && nextId != null && !controller.loop.value) onOpenVideo(nextId) }
        onDispose { controller.onEnded = null }
    }
    val shareAction = PlayerMenuAction("Share", Icons.Filled.Share) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "https://youtu.be/${viewModel.videoId}")
        context.startActivity(Intent.createChooser(send, "Share"))
    }
    val dlLabel = when {
        dl == null || dl?.status == app.notube.data.local.DOWNLOAD_FAILED -> "Download"
        dl?.status == app.notube.data.local.DOWNLOAD_DONE -> "Downloaded"
        else -> "Downloading ${dl?.progress ?: 0}%"
    }
    val downloadAction = PlayerMenuAction(
        dlLabel, if (dl?.status == app.notube.data.local.DOWNLOAD_DONE) Icons.Filled.DownloadDone else Icons.Filled.Download,
    ) { (state as? app.notube.domain.UiState.Success)?.data?.stream?.let(viewModel::toggleDownload) }
    val player: @Composable (Boolean) -> Unit = { full ->
        WatchPlayer(
            controller = controller, fullscreen = full, title = title,
            onToggleFullscreen = toggleFullscreen, onMinimize = onBack,
            onQuality = viewModel::setQuality, extraActions = listOf(downloadAction, shareAction),
        )
    }

    if (landscape) {
        Box(Modifier.fillMaxSize().background(Color.Black)) { player(true) }
        return
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            var dy by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
            Box(
                Modifier
                    .offset { androidx.compose.ui.unit.IntOffset(0, dy.toInt()) }
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragEnd = { if (dy > 160f) onBack(); dy = 0f },
                            onDragCancel = { dy = 0f },
                        ) { c, d -> c.consume(); dy = (dy + d).coerceAtLeast(0f) }
                    },
            ) { player(false) }
            StateScaffold(state, viewModel::load, Modifier.fillMaxSize()) { page ->
                val s = page.stream
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Column(Modifier.padding(16.dp)) {
                            Text(s.title, style = MaterialTheme.typography.titleLarge)
                            val meta = listOfNotNull(page.extras.views, page.extras.published).joinToString(" · ")
                            if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { s.channelId?.let(onOpenChannel) }, enabled = s.channelId != null, modifier = Modifier.weight(1f)) {
                                    Text(s.channelName.ifBlank { "Channel" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (s.channelId != null) {
                                    if (subscribed) OutlinedButton(onClick = { viewModel.toggleSubscribe(s) }) { Text("Subscribed") }
                                    else Button(onClick = { viewModel.toggleSubscribe(s) }) { Text("Subscribe") }
                                }
                            }
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(onClick = { viewModel.toggleLike(s) }) {
                                    Icon(if (liked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp, null)
                                    Spacer(Modifier.width(6.dp)); Text(votes?.let { compactCount(it.likes + if (liked) 1 else 0) } ?: if (liked) "Liked" else "Like")
                                }
                                FilledTonalButton(onClick = { viewModel.toggleDownload(s) }) {
                                    Icon(if (dl?.status == app.notube.data.local.DOWNLOAD_DONE) Icons.Filled.DownloadDone else Icons.Filled.Download, null)
                                    Spacer(Modifier.width(6.dp)); Text(dlLabel)
                                }
                                FilledTonalButton(onClick = viewModel::toggleDislike) {
                                    Icon(if (disliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown, null)
                                    votes?.let { Spacer(Modifier.width(6.dp)); Text(compactCount(it.dislikes + if (disliked) 1 else 0)) }
                                }
                                FilledTonalButton(onClick = shareAction.onClick) { Icon(Icons.Filled.Share, null); Spacer(Modifier.width(6.dp)); Text("Share") }
                                Box {
                                    FilledTonalButton(onClick = { viewModel.loadPlaylists(); saveMenu = true }) {
                                        Icon(Icons.Filled.PlaylistAdd, null); Spacer(Modifier.width(6.dp)); Text("Save")
                                    }
                                    DropdownMenu(expanded = saveMenu, onDismissRequest = { saveMenu = false }) {
                                        playlists.forEach { p ->
                                            DropdownMenuItem(text = { Text(p.title) }, onClick = { saveMenu = false; viewModel.saveTo(p) })
                                        }
                                    }
                                }
                                FilledTonalButton(onClick = { onOpenComments(s.videoId) }) {
                                    Icon(Icons.Filled.Forum, null); Spacer(Modifier.width(6.dp)); Text("Comments")
                                }
                            }
                            page.extras.description?.takeIf { it.isNotBlank() }?.let { d ->
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    d, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.clickable { expanded = !expanded },
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("Up next", style = MaterialTheme.typography.headlineMedium)
                        }
                    }
                    items(page.extras.related, key = { it.id }) { v ->
                        VideoCard(v, { onOpenVideo(v.id) }, Modifier.padding(horizontal = 16.dp))
                    }
                }
            }
        }
    }
}

private fun compactCount(n: Long): String = when {
    n >= 1_000_000_000 -> "%.1fB".format(n / 1e9)
    n >= 1_000_000 -> "%.1fM".format(n / 1e6)
    n >= 10_000 -> "${n / 1000}K"
    n >= 1_000 -> "%.1fK".format(n / 1e3)
    else -> n.toString()
}
