package app.notube.ui.navigation

import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Subscriptions
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.Column
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.layout.Box
import app.notube.ui.player.FloatingMiniPlayer
import app.notube.ui.player.PlayerHostViewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.notube.ui.screens.downloads.DownloadsScreen
import app.notube.ui.screens.you.YouScreen
import app.notube.ui.screens.channel.ChannelPageScreen
import app.notube.ui.screens.channels.ChannelsScreen
import app.notube.ui.screens.comments.CommentsScreen
import app.notube.ui.screens.home.HomeScreen
import app.notube.ui.screens.playlist.PlaylistScreen
import app.notube.ui.screens.subscriptions.SubscriptionsScreen
import app.notube.ui.screens.login.LoginScreen
import app.notube.ui.screens.search.SearchScreen
import app.notube.ui.screens.settings.SettingsScreen
import app.notube.ui.screens.shorts.ShortsScreen
import app.notube.ui.screens.watch.WatchScreen

private data class BottomItem(
    val route: Route,
    val label: String,
    val selected: ImageVector,
    val unselected: ImageVector,
)

@Composable
fun NoTubeNavHost() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val bottomItems = listOf(
        BottomItem(Route.Home, "Home", Icons.Filled.Home, Icons.Outlined.Home),
        BottomItem(Route.Shorts, "Shorts", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
        BottomItem(Route.Subscriptions, "Subs", Icons.Filled.Subscriptions, Icons.Outlined.Subscriptions),
        BottomItem(Route.Library, "You", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle),
    )

    val showBottomBar = bottomItems.any { it.route.path == currentRoute }
    val controller = hiltViewModel<PlayerHostViewModel>().controller
    val playing by controller.current.collectAsState()
    val inShorts = currentRoute == Route.Shorts.path || currentRoute == Route.ShortsPlayer.path
    val showMini = playing != null && currentRoute != Route.Watch.path && !inShorts
    LaunchedEffect(inShorts) { if (inShorts) controller.pause() }

    Scaffold(
        bottomBar = {
          Column {
            if (showBottomBar) {
                NavigationBar {
                    bottomItems.forEach { item ->
                        val selected = currentRoute == item.route.path
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route.path) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (selected) item.selected else item.unselected,
                                    contentDescription = item.label,
                                )
                            },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
          }
        },
    ) { padding ->
      Box(Modifier.padding(padding)) {
        NavHost(
            navController = navController,
            startDestination = Route.Home.path,
            modifier = Modifier,
        ) {
            composable(Route.Home.path) {
                HomeScreen(
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenShort = { navController.navigate(Route.ShortsPlayer.create(it)) },
                    onSearch = { navController.navigate(Route.Search.path) },
                )
            }
            composable(Route.Shorts.path) {
                ShortsScreen(onOpenComments = { navController.navigate(Route.Comments.create(it)) })
            }
            composable(Route.Search.path) {
                SearchScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenChannel = { navController.navigate(Route.ChannelDetail.create(it)) },
                    onOpenShort = { navController.navigate(Route.ShortsPlayer.create(it)) },
                    onOpenPlaylist = { navController.navigate(Route.Playlist.create(it)) },
                )
            }
            composable(Route.Subscriptions.path) {
                SubscriptionsScreen(
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenShort = { navController.navigate(Route.ShortsPlayer.create(it)) },
                    onOpenChannel = { navController.navigate(Route.ChannelDetail.create(it)) },
                    onOpenChannels = { navController.navigate(Route.Channels.path) },
                    onSignIn = { navController.navigate(Route.Login.path) },
                    onSearch = { navController.navigate(Route.Search.path) },
                )
            }
            composable(
                route = Route.Playlist.path,
                arguments = listOf(navArgument("playlistId") { type = NavType.StringType }),
            ) {
                PlaylistScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                )
            }
            composable(Route.Library.path) {
                YouScreen(
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenChannel = { navController.navigate(Route.ChannelDetail.create(it)) },
                    onOpenPlaylist = { navController.navigate(Route.Playlist.create(it)) },
                    onOpenDownloads = { navController.navigate(Route.Downloads.path) },
                    onOpenSettings = { navController.navigate(Route.Settings.path) },
                    onOpenChannels = { navController.navigate(Route.Channels.path) },
                    onSignIn = { navController.navigate(Route.Login.path) },
                    onSearch = { navController.navigate(Route.Search.path) },
                )
            }
            composable(Route.Downloads.path) {
                DownloadsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                )
            }
            composable(Route.Login.path) {
                LoginScreen(onDone = { navController.popBackStack() }, onBack = { navController.popBackStack() })
            }
            composable(
                route = Route.ShortsPlayer.path,
                arguments = listOf(navArgument("videoId") { type = NavType.StringType }),
            ) {
                ShortsScreen(
                    onOpenComments = { navController.navigate(Route.Comments.create(it)) },
                    onBack = { navController.popBackStack() },
                )
            }
            composable(Route.Settings.path) {
                SettingsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenDownloads = { navController.navigate(Route.Downloads.path) },
                )
            }
            composable(Route.Channels.path) {
                ChannelsScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenChannel = { navController.navigate(Route.ChannelDetail.create(it)) },
                )
            }
            composable(
                route = Route.ChannelDetail.path,
                arguments = listOf(navArgument("channelId") { type = NavType.StringType }),
            ) {
                ChannelPageScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { navController.navigate(Route.Watch.create(it)) },
                    onOpenShort = { navController.navigate(Route.ShortsPlayer.create(it)) },
                    onOpenPlaylist = { navController.navigate(Route.Playlist.create(it)) },
                )
            }
            composable(
                route = Route.Watch.path,
                arguments = listOf(navArgument("videoId") { type = NavType.StringType }),
            ) {
                WatchScreen(
                    onBack = { navController.popBackStack() },
                    onOpenVideo = { id ->
                        navController.navigate(Route.Watch.create(id)) {
                            popUpTo(Route.Watch.path) { inclusive = true }
                        }
                    },
                    onOpenComments = { navController.navigate(Route.Comments.create(it)) },
                    onOpenChannel = { navController.navigate(Route.ChannelDetail.create(it)) },
                )
            }
            composable(
                route = Route.Comments.path,
                arguments = listOf(navArgument("videoId") { type = NavType.StringType }),
            ) {
                CommentsScreen(onBack = { navController.popBackStack() })
            }
        }
        if (showMini) FloatingMiniPlayer(controller, onExpand = { navController.navigate(Route.Watch.create(it)) })
      }
    }
}
