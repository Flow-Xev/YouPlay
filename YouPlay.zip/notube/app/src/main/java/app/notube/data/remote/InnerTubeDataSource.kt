package app.notube.data.remote

import app.notube.domain.ChannelItem
import app.notube.domain.CommentItem
import app.notube.domain.SearchFilter
import app.notube.domain.SearchPage
import app.notube.domain.SearchType
import app.notube.domain.WatchExtras
import app.notube.domain.FeedEntry
import app.notube.domain.FeedPage
import app.notube.domain.PlaylistItem
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import app.notube.domain.HomeFeed
import app.notube.domain.HomeSection
import app.notube.domain.StreamInfo
import app.notube.domain.VideoItem
import app.notube.util.JsonWalk
import com.metrolist.innertubex.InnerTube
import com.metrolist.innertubex.extraction.AudioQuality
import com.metrolist.innertubex.extraction.ContentHints
import com.metrolist.innertubex.extraction.InnerTubeExtractor
import com.metrolist.innertubex.extraction.StreamResolveException
import com.metrolist.innertubex.models.YouTubeClient
import com.metrolist.innertubex.models.YouTubeLocale
import com.metrolist.innertubex.models.response.PlayerResponse
import io.ktor.client.call.body
import io.ktor.client.statement.bodyAsText
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import io.ktor.client.request.get
import io.ktor.client.request.parameter

@Singleton
class InnerTubeDataSource @Inject constructor(
    private val innerTube: InnerTube,
    private val extractor: InnerTubeExtractor,
    private val http: io.ktor.client.HttpClient,
) {
    suspend fun configureLocale(hl: String, gl: String) = withContext(Dispatchers.IO) {
        innerTube.locale = YouTubeLocale(gl = gl, hl = hl)
    }


    /**
     * Generic feed loader (Home, Subscriptions, History, Liked, ...). Pass either a browseId
     * or a continuation token (chip tap / infinite scroll). Logged-in sessions are used
     * automatically because the session has useLoginForBrowse = true.
     */
    suspend fun feed(browseId: String?, continuation: String? = null, params: String? = null): FeedPage =
        withContext(Dispatchers.IO) {
            val text = innerTube.browse(
                YouTubeClient.WEB, browseId = browseId, params = params,
                continuation = continuation, setLogin = true,
            ).bodyAsText()
            parseFeed(JsonWalk.parseObject(text))
        }

    fun parseFeed(root: JsonObject): FeedPage {
        val entries = ArrayList<FeedEntry>()
        val seen = HashSet<String>()
        val looseShorts = ArrayList<VideoItem>()
        fun addVideo(v: VideoItem) {
            if (!seen.add(v.id)) return
            if (v.isShort) looseShorts += v else entries += FeedEntry.Video(v)
        }
        for (arr in itemArrays(root)) {
            for (el in arr) {
                val o = el as? JsonObject ?: continue
                val rich = o["richSectionRenderer"]
                if (rich != null) {
                    val shorts = JsonWalk.extractShortsShelves(rich).firstOrNull()
                    if (shorts != null) {
                        entries += FeedEntry.ShortsRow(shorts.filter { seen.add(it.id) })
                    } else JsonWalk.extractVideos(rich).forEach(::addVideo)
                } else JsonWalk.extractVideos(o).forEach(::addVideo)
            }
        }
        if (entries.isEmpty()) JsonWalk.extractVideos(root).forEach(::addVideo)
        if (looseShorts.size >= 3) entries += FeedEntry.ShortsRow(looseShorts.toList())
        return FeedPage(entries, JsonWalk.extractChips(root).distinctBy { it.label }, JsonWalk.extractContinuation(root))
    }

    private fun itemArrays(root: JsonElement): List<JsonArray> {
        val out = ArrayList<JsonArray>()
        fun rec(e: JsonElement, parentKey: String?) {
            when (e) {
                is JsonObject -> e.forEach { (k, v) ->
                    if (v is JsonArray && (k == "continuationItems" || (k == "contents" && parentKey == "richGridRenderer"))) out += v
                    else rec(v, k)
                }
                is JsonArray -> e.forEach { rec(it, parentKey) }
                else -> Unit
            }
        }
        rec(root, null)
        // fall back to section/list renderers (subscriptions, history, playlists)
        if (out.isEmpty()) {
            fun rec2(e: JsonElement) {
                when (e) {
                    is JsonObject -> e.forEach { (k, v) ->
                        if (v is JsonArray && k == "contents") out += v else rec2(v)
                    }
                    is JsonArray -> e.forEach { rec2(it) }
                    else -> Unit
                }
            }
            rec2(root)
        }
        return out
    }

    suspend fun playlists(browseId: String): List<PlaylistItem> = withContext(Dispatchers.IO) {
        val text = innerTube.browse(YouTubeClient.WEB, browseId = browseId, setLogin = true).bodyAsText()
        JsonWalk.extractPlaylists(JsonWalk.parseObject(text))
    }

    suspend fun playlistVideos(playlistId: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val id = if (playlistId.startsWith("VL")) playlistId else "VL$playlistId"
        val text = innerTube.browse(YouTubeClient.WEB, browseId = id, setLogin = true).bodyAsText()
        JsonWalk.extractVideos(JsonWalk.parseObject(text))
    }

    suspend fun subscribedChannels(): List<ChannelItem> = withContext(Dispatchers.IO) {
        val text = innerTube.browse(YouTubeClient.WEB, browseId = "FEchannels", setLogin = true).bodyAsText()
        JsonWalk.extractChannels(JsonWalk.parseObject(text))
    }

    suspend fun like(videoId: String, like: Boolean) = withContext(Dispatchers.IO) {
        if (like) innerTube.likeVideo(YouTubeClient.WEB, videoId) else innerTube.unlikeVideo(YouTubeClient.WEB, videoId)
    }

    /** Tells YouTube a video was watched so it lands in the account history + recommendations. */
    suspend fun reportPlayback(url: String, cpn: String) = withContext(Dispatchers.IO) {
        innerTube.registerPlayback(YouTubeClient.WEB, url, cpn)
    }

    suspend fun searchPage(query: String, filter: SearchFilter, continuation: String?): SearchPage =
        withContext(Dispatchers.IO) {
            val q = if (filter.type == SearchType.SHORTS) "$query #shorts" else query
            val text = innerTube.search(
                YouTubeClient.WEB,
                query = if (continuation == null) q else null,
                params = if (continuation == null) filter.toParams() else null,
                continuation = continuation,
                setLogin = true,
            ).bodyAsText()
            val root = JsonWalk.parseObject(text)
            val shelves = JsonWalk.extractShortsShelves(root)
            val shelfIds = shelves.flatten().map { it.id }.toSet()
            val videos = JsonWalk.extractVideos(root).filter { it.id !in shelfIds }
            val channels = JsonWalk.extractChannels(root)
            val playlists = JsonWalk.extractPlaylists(root)
            val cont = JsonWalk.extractContinuation(root)
            if (filter.type == SearchType.SHORTS) {
                val shorts = (videos + shelves.flatten()).filter { it.isShort || isLikelyShort(it) }
                    .distinctBy { it.id }.map { it.copy(isShort = true) }
                SearchPage(emptyList(), emptyList(), emptyList(), shorts, cont)
            } else {
                val entries = videos.map { FeedEntry.Video(it) as FeedEntry }.toMutableList()
                shelves.firstOrNull()?.let { entries.add(minOf(3, entries.size), FeedEntry.ShortsRow(it)) }
                SearchPage(entries, channels, playlists, emptyList(), cont)
            }
        }

    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            val t = http.get("https://suggestqueries.google.com/complete/search") {
                parameter("client", "firefox"); parameter("ds", "yt"); parameter("q", q)
            }.bodyAsText()
            JsonWalk.parseElement(t).jsonArray[1].jsonArray.map { it.jsonPrimitive.content }
        }.getOrDefault(emptyList())
    }

    suspend fun channelTab(browseId: String, params: String): Pair<FeedPage, List<PlaylistItem>> =
        withContext(Dispatchers.IO) {
            val text = innerTube.browse(YouTubeClient.WEB, browseId = browseId, params = params, setLogin = true).bodyAsText()
            val root = JsonWalk.parseObject(text)
            parseFeed(root) to JsonWalk.extractPlaylists(root)
        }

    suspend fun addToPlaylist(playlistId: String, videoId: String) = withContext(Dispatchers.IO) {
        innerTube.addToPlaylist(YouTubeClient.WEB, playlistId, videoId)
    }

    suspend fun watchExtras(videoId: String): Pair<WatchExtras, List<CommentItem>> = withContext(Dispatchers.IO) {
        val root = JsonWalk.parseObject(innerTube.next(YouTubeClient.WEB, videoId = videoId).bodyAsText())
        val (d, v, p) = JsonWalk.extractWatchMeta(root)
        WatchExtras(JsonWalk.extractVideos(root).filter { it.id != videoId }, d, v, p) to JsonWalk.extractComments(root)
    }

    suspend fun dislike(videoId: String) = withContext(Dispatchers.IO) { innerTube.dislikeVideo(YouTubeClient.WEB, videoId) }

    suspend fun subscribe(channelId: String, subscribe: Boolean) = withContext(Dispatchers.IO) {
        if (subscribe) innerTube.subscribeChannel(YouTubeClient.WEB, channelId)
        else innerTube.unsubscribeChannel(YouTubeClient.WEB, channelId)
    }

    suspend fun homeFeed(): HomeFeed = withContext(Dispatchers.IO) {
        val text = innerTube.browse(YouTubeClient.WEB, browseId = "FEwhat_to_watch").bodyAsText()
        val root = JsonWalk.parseObject(text)
        val videos = JsonWalk.extractVideos(root)
        HomeFeed(
            sections = listOf(
                HomeSection("Trending for you", videos.take(24)),
                HomeSection("More videos", videos.drop(24).ifEmpty { videos }),
            ).filter { it.videos.isNotEmpty() }.ifEmpty {
                listOf(HomeSection("Home", emptyList()))
            },
        )
    }

    suspend fun search(query: String): List<VideoItem> = withContext(Dispatchers.IO) {
        val text = innerTube.search(YouTubeClient.WEB, query = query, setLogin = false).bodyAsText()
        JsonWalk.extractVideos(JsonWalk.parseObject(text))
    }

    suspend fun searchChannels(query: String): List<ChannelItem> = withContext(Dispatchers.IO) {
        val text = innerTube.search(YouTubeClient.WEB, query = query, setLogin = false).bodyAsText()
        JsonWalk.extractChannels(JsonWalk.parseObject(text))
    }

    suspend fun shorts(): List<VideoItem> = withContext(Dispatchers.IO) {
        val attempts = listOf("FEshorts", "UC", "FEwhat_to_watch")
        val collected = LinkedHashMap<String, VideoItem>()
        for (browseId in attempts) {
            runCatching {
                val text = innerTube.browse(YouTubeClient.WEB, browseId = browseId).bodyAsText()
                JsonWalk.extractVideos(JsonWalk.parseObject(text))
                    .filter { it.isShort || it.durationText == null || isLikelyShort(it) }
                    .forEach { collected.putIfAbsent(it.id, it.copy(isShort = true)) }
            }
            if (collected.size >= 12) break
        }
        if (collected.isEmpty()) {
            // Fall back to search-based Shorts discovery
            search("shorts").map { it.copy(isShort = true) }.forEach { collected.putIfAbsent(it.id, it) }
        }
        collected.values.toList()
    }

    suspend fun channel(browseId: String): Pair<ChannelItem?, List<VideoItem>> = withContext(Dispatchers.IO) {
        val text = innerTube.browse(YouTubeClient.WEB, browseId = browseId).bodyAsText()
        val root = JsonWalk.parseObject(text)
        val channels = JsonWalk.extractChannels(root)
        val header = parseChannelHeader(root)
        header to JsonWalk.extractVideos(root).ifEmpty {
            // try videos tab via params often embedded; fall back empty
            emptyList()
        }.also {
            // prefer header channel
        }.let { videos ->
            (header ?: channels.firstOrNull()) to videos
        }
    }

    /** Channel Home with the creator's own shelves. */
    suspend fun channelHome(browseId: String): Triple<ChannelItem?, List<VideoItem>, List<app.notube.domain.ChannelShelf>> =
        withContext(Dispatchers.IO) {
            val root = JsonWalk.parseObject(innerTube.browse(YouTubeClient.WEB, browseId = browseId).bodyAsText())
            val header = parseChannelHeader(root) ?: JsonWalk.extractChannels(root).firstOrNull()
            Triple(header, JsonWalk.extractVideos(root), JsonWalk.extractShelves(root))
        }

    suspend fun relatedAndComments(videoId: String): Pair<List<VideoItem>, List<CommentItem>> =
        withContext(Dispatchers.IO) {
            val text = innerTube.next(YouTubeClient.WEB, videoId = videoId).bodyAsText()
            val root = JsonWalk.parseObject(text)
            JsonWalk.extractVideos(root) to JsonWalk.extractComments(root)
        }

    suspend fun comments(videoId: String): List<CommentItem> = relatedAndComments(videoId).second

    /** One page of comments. First call (continuation == null) finds the comment section via the watch response. */
    suspend fun commentsPage(videoId: String, continuation: String?): app.notube.domain.CommentsPage = withContext(Dispatchers.IO) {
        val token = continuation ?: JsonWalk.commentsToken(
            JsonWalk.parseObject(innerTube.next(YouTubeClient.WEB, videoId = videoId).bodyAsText()),
        ) ?: return@withContext app.notube.domain.CommentsPage(emptyList(), null, null)
        JsonWalk.parseCommentsPage(JsonWalk.parseObject(innerTube.next(YouTubeClient.WEB, continuation = token).bodyAsText()))
    }

    suspend fun resolveStream(videoId: String, maxHeight: Int = 1080): StreamInfo = withContext(Dispatchers.IO) {
        // Prefer InnerTubeX extractor (cipher + client selection)
        val extracted = runCatching {
            extractor.extract(
                videoId = videoId,
                hints = ContentHints(wantVideo = true, maxVideoHeight = maxHeight),
                audioQuality = AudioQuality.AUTO,
            )
        }.getOrNull()

        if (extracted != null) {
            val meta = extracted.mediaMetadata
            return@withContext StreamInfo(
                videoId = videoId,
                title = meta?.title ?: "Video",
                channelName = meta?.author.orEmpty(),
                channelId = meta?.channelId,
                thumbnailUrl = meta?.thumbnails?.firstOrNull()?.url,
                description = null,
                videoUrl = extracted.videoUrl,
                audioUrl = extracted.audioUrl,
                mimeType = extracted.videoMimeType ?: extracted.mimeType,
                playbackUrl = extracted.playbackTracking?.playbackUrl,
                cpn = extracted.playbackTracking?.clientPlaybackNonce,
            )
        }

        // Fallback: direct player response with progressive / HLS URLs
        resolveViaPlayer(videoId, maxHeight)
    }

    private suspend fun resolveViaPlayer(videoId: String, maxHeight: Int = 1080): StreamInfo {
        val clients = listOf(
            YouTubeClient.ANDROID,
            YouTubeClient.IOS,
            YouTubeClient.TVHTML5_SIMPLY_EMBEDDED_PLAYER,
            YouTubeClient.WEB,
        )
        var lastError: Throwable? = null
        for (client in clients) {
            try {
                val response: PlayerResponse = innerTube.player(client, videoId).body()
                if (response.playabilityStatus.status != "OK") {
                    lastError = IllegalStateException(response.playabilityStatus.reason ?: response.playabilityStatus.status)
                    continue
                }
                val streaming = response.streamingData ?: continue
                val details = response.videoDetails
                val progressive = streaming.formats?.firstOrNull { !it.url.isNullOrBlank() }
                val videoAdaptive = streaming.adaptiveFormats
                    .filter { it.url != null && it.mimeType.startsWith("video/") && (it.height ?: 0) <= maxHeight }
                    .maxByOrNull { it.height ?: 0 }
                val audioAdaptive = streaming.adaptiveFormats
                    .filter { it.url != null && it.mimeType.startsWith("audio/") }
                    .maxByOrNull { it.bitrate }
                return StreamInfo(
                    videoId = videoId,
                    title = details?.title ?: "Video",
                    channelName = details?.author.orEmpty(),
                    channelId = details?.channelId,
                    thumbnailUrl = details?.thumbnail?.thumbnails?.lastOrNull()?.url,
                    description = null,
                    videoUrl = progressive?.url ?: videoAdaptive?.url,
                    audioUrl = audioAdaptive?.url ?: progressive?.url,
                    hlsUrl = streaming.hlsManifestUrl,
                    mimeType = progressive?.mimeType ?: videoAdaptive?.mimeType,
                )
            } catch (t: Throwable) {
                if (t is StreamResolveException) throw t
                lastError = t
            }
        }
        throw lastError ?: IllegalStateException("Unable to resolve stream for $videoId")
    }

    private fun isLikelyShort(item: VideoItem): Boolean {
        val d = item.durationText ?: return false
        val parts = d.split(":").mapNotNull { it.toIntOrNull() }
        val seconds = when (parts.size) {
            1 -> parts[0]
            2 -> parts[0] * 60 + parts[1]
            3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            else -> return false
        }
        return seconds in 1..60
    }

    private fun parseChannelHeader(root: JsonObject): ChannelItem? {
        var found: ChannelItem? = null
        JsonWalk.walk(root) { key, obj ->
            if (found != null) return@walk
            if (key == "c4TabbedHeaderRenderer" || key == "pageHeaderRenderer" || key == "channelMetadataRenderer") {
                val id = obj["channelId"]?.toString()?.trim('"')
                    ?: obj["externalId"]?.toString()?.trim('"')
                    ?: return@walk
                val title = JsonWalk.textRuns(obj["title"]?.jsonObject)
                    ?: obj["title"]?.toString()?.trim('"')
                    ?: return@walk
                found = ChannelItem(
                    id = id,
                    title = title,
                    thumbnailUrl = JsonWalk.bestThumb(obj["avatar"]?.jsonObject ?: obj["thumbnail"]?.jsonObject),
                    subscriberCountText = JsonWalk.textRuns(obj["subscriberCountText"]?.jsonObject),
                    description = obj["description"]?.toString()?.trim('"'),
                )
            }
        }
        return found
    }
}
