package app.notube.util

import app.notube.domain.ChannelItem
import app.notube.domain.ChipItem
import app.notube.domain.CommentItem
import app.notube.domain.CommentsPage
import app.notube.domain.PlaylistItem
import app.notube.domain.VideoItem
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

object JsonWalk {
    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
        explicitNulls = false
    }

    fun parseElement(text: String): JsonElement = json.parseToJsonElement(text)

    fun parseObject(text: String): JsonObject =
        json.parseToJsonElement(text).jsonObject

    fun walk(element: JsonElement?, visitor: (String, JsonObject) -> Unit) {
        when (element) {
            is JsonObject -> {
                element.forEach { (key, value) ->
                    if (value is JsonObject) visitor(key, value)
                    walk(value, visitor)
                }
            }
            is JsonArray -> element.forEach { walk(it, visitor) }
            else -> Unit
        }
    }

    fun textRuns(obj: JsonObject?): String? {
        if (obj == null) return null
        obj["simpleText"]?.jsonPrimitive?.contentOrNull?.let { return it }
        (obj["content"] as? JsonPrimitive)?.contentOrNull?.let { return it }
        val runs = obj["runs"]?.jsonArray ?: return null
        return runs.mapNotNull { it.jsonObject["text"]?.jsonPrimitive?.contentOrNull }.joinToString("")
    }

    fun bestThumb(obj: JsonObject?): String? {
        val thumbs = obj?.get("thumbnails")?.jsonArray ?: return null
        return thumbs.mapNotNull { it.jsonObject["url"]?.jsonPrimitive?.contentOrNull }
            .maxByOrNull { it.length }
            ?.let { if (it.startsWith("//")) "https:$it" else it }
    }

    fun extractVideos(root: JsonElement): List<VideoItem> {
        val out = LinkedHashMap<String, VideoItem>()
        walk(root) { key, obj ->
            when (key) {
                "videoRenderer", "gridVideoRenderer", "compactVideoRenderer", "playlistVideoRenderer" -> {
                    parseVideoRenderer(obj)?.let { out.putIfAbsent(it.id, it) }
                }
                "reelItemRenderer", "shortsLockupViewModel" -> {
                    parseShort(obj)?.let { out.putIfAbsent(it.id, it) }
                }
                "lockupViewModel" -> parseLockup(obj)?.let { out.putIfAbsent(it.id, it) }
            }
        }
        return out.values.toList()
    }

    fun extractChannels(root: JsonElement): List<ChannelItem> {
        val out = LinkedHashMap<String, ChannelItem>()
        walk(root) { key, obj ->
            if (key == "channelRenderer" || key == "gridChannelRenderer") {
                parseChannel(obj)?.let { out.putIfAbsent(it.id, it) }
            }
        }
        return out.values.toList()
    }

    fun extractComments(root: JsonElement): List<CommentItem> {
        val out = LinkedHashMap<String, CommentItem>()
        walk(root) { key, obj ->
            if (key == "commentRenderer" || key == "commentEntityPayload" || key == "commentViewModel") {
                parseComment(obj)?.let { out.putIfAbsent(it.id, it) }
            }
        }
        return out.values.toList()
    }


    private fun JsonObject.obj(k: String) = this[k] as? JsonObject
    private fun JsonObject.str(k: String) = (this[k] as? JsonPrimitive)?.contentOrNull

    fun profile(root: JsonElement): app.notube.domain.AccountState? {
        var res: app.notube.domain.AccountState? = null
        walk(root) { key, obj ->
            if (key == "activeAccountHeaderRenderer" && res == null) {
                res = app.notube.domain.AccountState(
                    signedIn = true,
                    name = textRuns(obj.obj("accountName")),
                    email = textRuns(obj.obj("email")),
                    handle = textRuns(obj.obj("channelHandle")),
                    avatarUrl = bestThumb(obj.obj("accountPhoto")),
                )
            }
        }
        return res
    }

    /** description / views / date from a `next` (watch) response. */
    fun extractWatchMeta(root: JsonElement): Triple<String?, String?, String?> {
        var desc: String? = null; var views: String? = null; var date: String? = null
        walk(root) { key, obj ->
            when (key) {
                "attributedDescription" -> if (desc == null) desc = obj.str("content")
                "videoSecondaryInfoRenderer" -> if (desc == null) desc = textRuns(obj.obj("description"))
                "videoPrimaryInfoRenderer" -> {
                    views = textRuns(obj.obj("viewCount")?.obj("videoViewCountRenderer")?.obj("viewCount"))
                    date = textRuns(obj.obj("dateText"))
                }
            }
        }
        return Triple(desc, views, date)
    }

    fun parseLockup(obj: JsonObject): VideoItem? {
        val type = obj.str("contentType").orEmpty()
        if (type.isNotEmpty() && !type.endsWith("VIDEO")) return null
        val id = obj.str("contentId") ?: return null
        val meta = obj.obj("metadata")?.obj("lockupMetadataViewModel")
        val title = textRuns(meta?.obj("title")) ?: "Video"
        val rows = meta?.obj("metadata")?.obj("contentMetadataViewModel")
            ?.get("metadataRows") as? JsonArray
        val parts = rows?.flatMap { r ->
            (r.jsonObject["metadataParts"] as? JsonArray)?.mapNotNull { textRuns(it.jsonObject.obj("text")) }.orEmpty()
        }.orEmpty()
        val thumbVm = obj.obj("contentImage")?.obj("thumbnailViewModel")
        var duration: String? = null
        (thumbVm?.get("overlays") as? JsonArray)?.forEach { ov ->
            val badges = ov.jsonObject.obj("thumbnailBottomOverlayViewModel")?.get("badges") as? JsonArray
            badges?.forEach { b ->
                val t = textRuns(b.jsonObject.obj("thumbnailBadgeViewModel")?.let { JsonObject(mapOf("content" to (it["text"] ?: JsonPrimitive("")))) })
                if (duration == null && t != null && t.any { it.isDigit() }) duration = t
            }
        }
        val channelId = meta?.obj("image")?.obj("decoratedAvatarViewModel")?.obj("rendererContext")
            ?.obj("commandContext")?.obj("onTap")?.obj("innertubeCommand")?.obj("browseEndpoint")?.str("browseId")
        return VideoItem(
            id = id, title = title,
            channelName = parts.getOrNull(0).orEmpty(),
            channelId = channelId,
            viewCountText = parts.getOrNull(1),
            publishedText = parts.getOrNull(2),
            thumbnailUrl = bestThumb(thumbVm?.obj("image")),
            durationText = duration,
        )
    }

    /** Playlist cards (lockupViewModel with PLAYLIST type, or playlistRenderer). */
    fun extractPlaylists(root: JsonElement): List<PlaylistItem> {
        val out = LinkedHashMap<String, PlaylistItem>()
        walk(root) { key, obj ->
            when (key) {
                "lockupViewModel" -> if (obj.str("contentType")?.endsWith("PLAYLIST") == true) {
                    val id = obj.str("contentId") ?: return@walk
                    val meta = obj.obj("metadata")?.obj("lockupMetadataViewModel")
                    out.putIfAbsent(id, PlaylistItem(
                        id = id,
                        title = textRuns(meta?.obj("title")) ?: "Playlist",
                        thumbnailUrl = bestThumb(obj.obj("contentImage")?.let { it.obj("collectionThumbnailViewModel") ?: it }
                            ?.let { it.obj("primaryThumbnail") ?: it }?.obj("thumbnailViewModel")?.obj("image")),
                        subtitle = ((meta?.obj("metadata")?.obj("contentMetadataViewModel")?.get("metadataRows") as? JsonArray)
                            ?.firstOrNull()?.jsonObject?.get("metadataParts") as? JsonArray)
                            ?.firstOrNull()?.jsonObject?.obj("text")?.let { textRuns(it) },
                    ))
                }
                "playlistRenderer", "gridPlaylistRenderer" -> {
                    val id = obj.str("playlistId") ?: return@walk
                    out.putIfAbsent(id, PlaylistItem(
                        id, textRuns(obj.obj("title")) ?: "Playlist",
                        bestThumb((obj["thumbnails"] as? JsonArray)?.firstOrNull()?.jsonObject)
                            ?: bestThumb(obj.obj("thumbnail")),
                        obj.str("videoCount")?.let { "$it videos" },
                    ))
                }
            }
        }
        return out.values.toList()
    }

    /** The shelves a creator arranged on their channel Home, in order (featured video first). */
    fun extractShelves(root: JsonElement): List<app.notube.domain.ChannelShelf> {
        val out = ArrayList<app.notube.domain.ChannelShelf>()
        walk(root) { key, obj ->
            if (key == "channelVideoPlayerRenderer") {
                val id = obj.str("videoId") ?: return@walk
                out += app.notube.domain.ChannelShelf(
                    "Featured",
                    listOf(VideoItem(
                        id = id, title = textRuns(obj.obj("title")) ?: "Video",
                        viewCountText = textRuns(obj.obj("viewCountText")),
                        publishedText = textRuns(obj.obj("publishedTimeText")),
                        description = textRuns(obj.obj("description")),
                    )),
                    featured = true,
                )
            } else if (key == "itemSectionRenderer") {
                val shelf = findObj(obj, "shelfRenderer") ?: findObj(obj, "richShelfRenderer") ?: findObj(obj, "reelShelfRenderer")
                    ?: return@walk
                val isShorts = shelf.toString().contains("shortsLockupViewModel") || shelf.toString().contains("reelItemRenderer")
                val title = textRuns(shelf.obj("title")) ?: if (isShorts) "Shorts" else return@walk
                val vl = findStr(shelf.obj("title"), "browseId") ?: findStr(shelf.obj("endpoint"), "browseId")
                val playlists = extractPlaylists(shelf)
                val videos = extractVideos(shelf).let { l -> if (isShorts) l.map { it.copy(isShort = true) } else l }
                if (videos.isEmpty() && playlists.isEmpty()) return@walk
                out += app.notube.domain.ChannelShelf(
                    title = title, videos = videos, playlists = playlists, isShorts = isShorts,
                    playlistId = vl?.takeIf { it.startsWith("VL") }?.drop(2),
                )
            }
        }
        return out
    }

    /** Filter chips on Home / Search: label + continuation token. */
    fun extractChips(root: JsonElement): List<ChipItem> {
        val out = ArrayList<ChipItem>()
        walk(root) { key, obj ->
            if (key == "chipCloudChipRenderer") {
                val label = textRuns(obj.obj("text")) ?: return@walk
                val token = obj.obj("navigationEndpoint")?.obj("continuationCommand")?.str("token")
                    ?: obj.obj("navigationEndpoint")?.obj("browseEndpoint")?.str("params")
                out += ChipItem(label, token, obj["isSelected"]?.jsonPrimitive?.contentOrNull == "true")
            }
        }
        return out
    }

    /** Continuation token for infinite scroll (last one wins = bottom of the list). */
    fun extractContinuation(root: JsonElement): String? {
        var token: String? = null
        walk(root) { key, obj ->
            if (key == "continuationItemRenderer") {
                obj.obj("continuationEndpoint")?.obj("continuationCommand")?.str("token")?.let { token = it }
            }
        }
        return token
    }

    /** Shorts shelves (reelShelfRenderer / richShelfRenderer with shorts) found in a response. */
    fun extractShortsShelves(root: JsonElement): List<List<VideoItem>> {
        val shelves = ArrayList<List<VideoItem>>()
        walk(root) { key, obj ->
            if (key == "reelShelfRenderer" || (key == "richShelfRenderer" && obj.toString().contains("shortsLockupViewModel"))) {
                val list = extractVideos(obj).map { it.copy(isShort = true) }
                if (list.size >= 3) shelves += list
            }
        }
        return shelves
    }

    private fun parseVideoRenderer(obj: JsonObject): VideoItem? {
        val id = obj["videoId"]?.jsonPrimitive?.contentOrNull ?: return null
        val title = textRuns(obj["title"]?.jsonObject) ?: return null
        val channel = textRuns(
            obj["ownerText"]?.jsonObject
                ?: obj["shortBylineText"]?.jsonObject
                ?: obj["longBylineText"]?.jsonObject,
        ).orEmpty()
        val channelId = obj["ownerText"]?.jsonObject
            ?.get("runs")?.jsonArray?.firstOrNull()?.jsonObject
            ?.get("navigationEndpoint")?.jsonObject
            ?.get("browseEndpoint")?.jsonObject
            ?.get("browseId")?.jsonPrimitive?.contentOrNull
            ?: obj["channelId"]?.jsonPrimitive?.contentOrNull
        val length = textRuns(obj["lengthText"]?.jsonObject)
            ?: obj["thumbnailOverlays"]?.jsonArray
                ?.firstOrNull()
                ?.jsonObject?.get("thumbnailOverlayTimeStatusRenderer")
                ?.jsonObject?.get("text")?.jsonObject?.let { textRuns(it) }
        val views = textRuns(obj["viewCountText"]?.jsonObject ?: obj["shortViewCountText"]?.jsonObject)
        val published = textRuns(obj["publishedTimeText"]?.jsonObject)
        return VideoItem(
            id = id,
            title = title,
            channelName = channel,
            channelId = channelId,
            thumbnailUrl = bestThumb(obj["thumbnail"]?.jsonObject),
            durationText = length,
            viewCountText = views,
            publishedText = published,
            description = textRuns(obj["descriptionSnippet"]?.jsonObject),
            isShort = false,
        )
    }

    private fun parseShort(obj: JsonObject): VideoItem? {
        val id = obj["videoId"]?.jsonPrimitive?.contentOrNull
            ?: obj["onTap"]?.jsonObject?.get("innertubeCommand")?.jsonObject
                ?.get("reelWatchEndpoint")?.jsonObject
                ?.get("videoId")?.jsonPrimitive?.contentOrNull
            ?: obj["entityId"]?.jsonPrimitive?.contentOrNull?.substringAfter("shorts-shelf-item-")
            ?: return null
        val title = textRuns(obj["headline"]?.jsonObject)
            ?: textRuns(obj["overlayMetadata"]?.jsonObject?.get("primaryText")?.jsonObject)
            ?: obj["accessibilityText"]?.jsonPrimitive?.contentOrNull
            ?: "Short"
        return VideoItem(
            id = id,
            title = title,
            thumbnailUrl = bestThumb(obj["thumbnail"]?.jsonObject)
                ?: bestThumb(
                    obj["thumbnailViewModel"]?.jsonObject?.get("image")?.jsonObject,
                ),
            isShort = true,
        )
    }

    private fun parseChannel(obj: JsonObject): ChannelItem? {
        val id = obj["channelId"]?.jsonPrimitive?.contentOrNull ?: return null
        val title = textRuns(obj["title"]?.jsonObject) ?: return null
        return ChannelItem(
            id = id,
            title = title,
            thumbnailUrl = bestThumb(obj["thumbnail"]?.jsonObject),
            subscriberCountText = textRuns(obj["subscriberCountText"]?.jsonObject),
            videoCountText = textRuns(obj["videoCountText"]?.jsonObject),
            description = textRuns(obj["descriptionSnippet"]?.jsonObject),
        )
    }

    private fun parseComment(obj: JsonObject): CommentItem? {
        val id = obj["commentId"]?.jsonPrimitive?.contentOrNull
            ?: obj["properties"]?.jsonObject?.get("commentId")?.jsonPrimitive?.contentOrNull
            ?: return null
        val author = textRuns(obj["authorText"]?.jsonObject)
            ?: obj["author"]?.jsonObject?.get("displayName")?.jsonPrimitive?.contentOrNull
            ?: "User"
        val text = textRuns(obj["contentText"]?.jsonObject)
            ?: obj["properties"]?.jsonObject?.get("content")?.jsonObject?.let { textRuns(it) }
            ?: obj["content"]?.jsonPrimitive?.contentOrNull
            ?: return null
        val author2 = obj["author"]?.jsonObject
        val toolbar = obj["toolbar"]?.jsonObject
        return CommentItem(
            id = id,
            author = author,
            authorThumbUrl = bestThumb(obj["authorThumbnail"]?.jsonObject)
                ?: author2?.get("avatarThumbnailUrl")?.jsonPrimitive?.contentOrNull,
            text = text,
            likeCountText = obj["voteCount"]?.jsonObject?.let { textRuns(it) }
                ?: obj["likeCountNotliked"]?.jsonPrimitive?.contentOrNull
                ?: toolbar?.get("likeCountNotliked")?.jsonPrimitive?.contentOrNull,
            publishedText = textRuns(obj["publishedTimeText"]?.jsonObject)
                ?: obj["properties"]?.jsonObject?.get("publishedTime")?.jsonPrimitive?.contentOrNull,
            replyCount = obj["replyCount"]?.jsonPrimitive?.contentOrNull?.toIntOrNull()
                ?: toolbar?.get("replyCount")?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 0,
        )
    }

    // ---- comments (paging + per-comment action tokens) ----

    private fun findObj(el: JsonElement?, key: String): JsonObject? {
        when (el) {
            is JsonObject -> {
                (el[key] as? JsonObject)?.let { return it }
                for ((_, v) in el) findObj(v, key)?.let { return it }
            }
            is JsonArray -> for (x in el) findObj(x, key)?.let { return it }
            else -> Unit
        }
        return null
    }

    private fun findStr(el: JsonElement?, key: String): String? {
        when (el) {
            is JsonObject -> {
                (el[key] as? JsonPrimitive)?.contentOrNull?.let { return it }
                for ((_, v) in el) findStr(v, key)?.let { return it }
            }
            is JsonArray -> for (x in el) findStr(x, key)?.let { return it }
            else -> Unit
        }
        return null
    }

    private fun actionOf(el: JsonElement?): String? = findObj(el, "performCommentActionEndpoint")?.let { findStr(it, "action") }

    /** Token that loads the comment section, found in a watch (`next`) response. */
    fun commentsToken(root: JsonElement): String? {
        var t: String? = null
        walk(root) { key, obj ->
            if (t == null && key == "itemSectionRenderer") {
                val id = (obj["sectionIdentifier"] as? JsonPrimitive)?.contentOrNull ?: (obj["targetId"] as? JsonPrimitive)?.contentOrNull
                if (id != null && id.contains("comment", ignoreCase = true)) t = findStr(obj, "token")
            }
        }
        return t
    }

    /** Parses comments, their action tokens (delete / like / reply), the "post comment" params and the next-page token. */
    fun parseCommentsPage(root: JsonElement): CommentsPage {
        val byId = LinkedHashMap<String, CommentItem>()
        walk(root) { key, obj ->
            if (key == "commentEntityPayload" || key == "commentRenderer") parseComment(obj)?.let { byId.putIfAbsent(it.id, it) }
        }
        val ordered = ArrayList<CommentItem>()
        walk(root) { key, obj ->
            if (key == "commentThreadRenderer") {
                val id = findStr(obj, "commentId")
                val base = id?.let { byId[it] }
                if (base != null && ordered.none { it.id == base.id }) {
                    val like = findObj(obj, "likeButton")
                    ordered += base.copy(
                        deleteToken = actionOf(findObj(obj, "confirmDialogRenderer")),
                        likeToken = like?.let { findObj(it, "defaultServiceEndpoint") }?.let(::actionOf),
                        unlikeToken = like?.let { findObj(it, "toggledServiceEndpoint") }?.let(::actionOf),
                        replyParams = findStr(obj, "createReplyParams"),
                    )
                }
            }
        }
        var cont: String? = null
        fun scan(el: JsonElement?) {
            when (el) {
                is JsonObject -> {
                    (el["continuationItems"] as? JsonArray)?.lastOrNull()?.let { last ->
                        findStr((last as? JsonObject)?.get("continuationItemRenderer"), "token")?.let { cont = it }
                    }
                    el.values.forEach(::scan)
                }
                is JsonArray -> el.forEach(::scan)
                else -> Unit
            }
        }
        scan(root)
        return CommentsPage(
            comments = ordered.ifEmpty { byId.values.toList() },
            continuation = cont,
            createParams = findStr(root, "createCommentParams"),
        )
    }
}
